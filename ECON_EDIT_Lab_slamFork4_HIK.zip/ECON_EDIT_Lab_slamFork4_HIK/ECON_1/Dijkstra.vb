Module Dijkstra
    Public Structure Dijkstra_ary
        Dim name As String
        Dim CarType As String
        Dim ary(,) As Integer

    End Structure
 
    'Function Dijkstra_fn(ByVal L1(,) As Integer, ByVal idx() As Integer, ByVal start As Integer, ByVal Dest As Integer, ByVal blocking_ID As String)


    '    Dim L1_lenght As Integer = idx.Length
    '    Dim start_idx As Integer = Array.IndexOf(idx, start) '�নIDX
    '    Dim Dest_idx As Integer = Array.IndexOf(idx, Dest) '�নIDX 
    '    Dim blocking_idx As Integer = -1
    '    Dim isLabel(L1_lenght - 1) As Boolean
    '    Dim i As Integer = 0
    '    Dim block_list() As String = blocking_ID.Split(",")
    '    Dim OK_FLAG As Boolean = False

    '    For Each val As String In block_list
    '        Try
    '            If IsNumeric(val) Then
    '                blocking_idx = Array.IndexOf(idx, CInt(val)) '�নIDX
    '                isLabel(blocking_idx) = True
    '            End If
    '        Catch ex As Exception

    '        End Try
    '    Next
    '    Dim path As String = (start_idx + 1).ToString.PadLeft(4, "0") + "-"
    '    Dim shorter_path As String = ""
    '    Dim count As Integer = 0
    '    Dim N(L1_lenght) As Integer
    '    Dim Distance(L1_lenght - 1) As Integer
    '    Dim Distance_Path(L1_lenght - 1) As String
    '    Dim index As Integer = start_idx
    '    Dim presentShortest As Integer = 0 '���e�{�ɳ̵u�Z�� 
    '    Dim presentShortest_path As String = "" '���e�{�ɳ̵u�Z�� 
    '    Try
    '        For i = 0 To L1_lenght - 1
    '            '��l��
    '            'path(i) = (start + 1).ToString '�_�I���]START
    '            Distance(i) = L1(start_idx, i) '�_�l�Z���A���۾F���I �Z����9999
    '            Distance_Path(i) = ""
    '        Next
    '    Catch ex As Exception
    '        Return ""
    '    End Try
    '    N(count) = index
    '    isLabel(index) = True
    '    While (count < L1_lenght)
    '        'count=0 ������̪��I
    '        Dim min As Integer = 9999999

    '        For i = 0 To Distance.Length - 1
    '            If (Not isLabel(i) And Not i = index) Then
    '                If (Distance(i) < min) Then
    '                    min = Distance(i)
    '                    index = i
    '                End If
    '            End If
    '        Next
    '        isLabel(index) = True            '
    '        count += 1
    '        N(count) = index '�N�ҿ�쪺�I�ƤJ�U�����~�W��
    '        '�U�@��STEP�}�l
    '        If L1(N(count - 1), index) > 9990 Or presentShortest + L1(N(count - 1), index) > Distance(index) Then
    '            ' �p�G�Щw���I�M���e�@�ӼЩw���I�����S�������۳s�A�Ϊ̳o����I�����|�j��̵u���|
    '            presentShortest = Distance(index)
    '            presentShortest_path = Distance_Path(index)
    '        Else
    '            presentShortest += L1(N(count - 1), index) '�q�}�C���X��
    '            presentShortest_path += idx(N(count - 1)).ToString + ","
    '        End If
    '        If (index = Dest_idx) Then
    '            OK_FLAG = True
    '            Exit While

    '        End If
    '        '�ĤG�B�G�NDistance�����Z���[�Jvi
    '        For i = 0 To Distance.Length - 1
    '            '�p�Gvi�쨺���I����A�hv0��᭱�I���Z���[
    '            If (presentShortest + L1(index, i) < Distance(i)) Then
    '                '�p�G�H�e�i�F�A���{�b�����|��H�e��u�A�h�󴫦���u�����|
    '                Distance(i) = presentShortest + L1(index, i)
    '                Distance_Path(i) = presentShortest_path + idx(index).ToString + ","
    '                If (i = Dest_idx) Then
    '                    '�u�����ت��a�����
    '                    path += shorter_path
    '                    shorter_path = ""
    '                End If

    '            End If
    '        Next
    '    End While
    '    Try

    '        If OK_FLAG = False Then
    '            Return ""
    '        ElseIf (Distance(Dest_idx) < 99999) Then
    '            If Not Distance_Path(Dest_idx).StartsWith(idx(start_idx).ToString + ",") Then
    '                path = idx(start_idx).ToString + "," + Distance_Path(Dest_idx) + idx(Dest_idx).ToString
    '            Else
    '                path = Distance_Path(Dest_idx) + idx(Dest_idx).ToString
    '            End If
    '            Return path
    '        Else
    '            Return ""
    '        End If
    '    Catch ex As Exception
    '        Return ""
    '    End Try
    'End Function

    'Function Dijkstra_fn_fork(ByVal L1_start(,) As Integer, ByVal idx_start() As Integer, ByVal start As Integer, ByVal Dest_list As String, ByVal Rotate_list As String, ByVal blocking_ID As String)
    '    Dim start_len As Integer = idx_start.Length

    '    Dim L1(start_len * 2 - 1, start_len * 2 - 1) As Integer
    '    Dim idx(start_len * 2 - 1) As Integer
    '    ' Rote_list = "41,37,62,52"
    '    Dim R_list() As String = Rotate_list.Split(",")
    '    Dim Rote(R_list.Length - 1) As Integer
    '    Dim block_path(3, 1) As Integer

    '    Dim Dest_list_str() As String = Dest_list.Split(",")
    '    Dim Dest(Dest_list_str.Length - 1) As Integer
    '    Dim Dest_idx(Dest.Length - 1) As Integer

    '    For i As Integer = 0 To Dest.Length - 1
    '        If IsNumeric(Dest_list_str(i)) Then
    '            Dest(i) = CInt(Dest_list_str(i))
    '        End If
    '    Next
    '    If (Array.IndexOf(Dest, start) > -1) Then
    '        Return start.ToString
    '    End If
    '    ' Dim blocking_ID As String = "8000,8002,18001,18003"
    '    For ii As Integer = 0 To R_list.Length - 1
    '        Rote(ii) = CInt(R_list(ii))
    '    Next
    '    For ii As Integer = 0 To start_len - 1
    '        idx(ii) = idx_start(ii)
    '        idx(ii + start_len) = idx(ii) + 10000
    '        For jj As Integer = 0 To start_len - 1
    '            L1(ii, jj) = L1_start(ii, jj) '���a�� ���e�}�C
    '            L1(jj + start_len, ii + start_len) = L1_start(ii, jj) '�f��}�C

    '            If Array.IndexOf(Rote, idx_start(ii)) >= 0 And ii = jj Then
    '                L1(ii + start_len, jj) = 0
    '                L1(ii, jj + start_len) = 0
    '            Else
    '                L1(ii + start_len, jj) = 99999
    '                L1(ii, jj + start_len) = 99999
    '            End If

    '        Next
    '    Next

    '    Dim L1_lenght As Integer = idx.Length
    '    Dim start_idx As Integer = Array.IndexOf(idx, start) '�নIDX

    '    Dim blocking_idx As Integer = -1
    '    Dim isLabel(L1_lenght - 1) As Boolean

    '    Dim block_list() As String = blocking_ID.Split(",")
    '    Dim OK_FLAG As Boolean = False

    '    For Each val As String In block_list
    '        Try
    '            If IsNumeric(val) Then
    '                blocking_idx = Array.IndexOf(idx, CInt(val)) '�নIDX
    '                isLabel(blocking_idx) = True
    '            End If
    '        Catch ex As Exception

    '        End Try
    '    Next

    '    Dim path As String = (start_idx + 1).ToString.PadLeft(4, "0") + "-"
    '    Dim shorter_path As String = ""
    '    Dim count As Integer = 0
    '    Dim N(L1_lenght) As Integer
    '    Dim Distance(L1_lenght - 1) As Integer
    '    Dim Distance_Path(L1_lenght - 1) As String
    '    Dim index As Integer = start_idx
    '    Dim presentShortest As Integer = 0 '���e�{�ɳ̵u�Z�� 
    '    Dim presentShortest_path As String = "" '���e�{�ɳ̵u�Z�� 
    '    For i As Integer = 0 To Dest.Length - 1
    '        Dest_idx(i) = Array.IndexOf(idx, Dest(i)) '�নIDX
    '    Next
    '    Try
    '        For i As Integer = 0 To L1_lenght - 1
    '            '��l��
    '            'path(i) = (start + 1).ToString '�_�I���]START
    '            Distance(i) = L1(start_idx, i) '�_�l�Z���A���۾F���I �Z����9999
    '            Distance_Path(i) = ""
    '        Next
    '    Catch ex As Exception
    '        Return ""
    '    End Try
    '    N(count) = index
    '    isLabel(index) = True

    '    While (count < L1_lenght)
    '        'count=0 ������̪��I
    '        Dim min As Integer = 9999999

    '        For i As Integer = 0 To Distance.Length - 1
    '            If (Not isLabel(i) And Not i = index) Then
    '                If (Distance(i) < min) Then
    '                    min = Distance(i)
    '                    index = i
    '                End If
    '            End If
    '        Next
    '        isLabel(index) = True            '
    '        count += 1
    '        N(count) = index '�N�ҿ�쪺�I�ƤJ�U�����~�W��
    '        'MsgBox(idx(index))
    '        '�U�@��STEP�}�l
    '        If L1(N(count - 1), index) > 9990 Or presentShortest + L1(N(count - 1), index) > Distance(index) Then
    '            ' �p�G�Щw���I�M���e�@�ӼЩw���I�����S�������۳s�A�Ϊ̳o����I�����|�j��̵u���|
    '            presentShortest = Distance(index)
    '            presentShortest_path = Distance_Path(index)
    '        Else
    '            presentShortest += L1(N(count - 1), index) '�q�}�C���X��
    '            presentShortest_path += idx(N(count - 1)).ToString + ","
    '        End If
    '        If Array.IndexOf(Dest_idx, index) > -1 Then
    '            OK_FLAG = True
    '            Exit While

    '        End If
    '        '�ĤG�B�G�NDistance�����Z���[�Jvi
    '        For i As Integer = 0 To Distance.Length - 1
    '            '�p�Gvi�쨺���I����A�hv0��᭱�I���Z���[
    '            If (presentShortest + L1(index, i) < Distance(i)) Then
    '                '�p�G�H�e�i�F�A���{�b�����|��H�e��u�A�h�󴫦���u�����|
    '                Distance(i) = presentShortest + L1(index, i)
    '                Distance_Path(i) = presentShortest_path + idx(index).ToString + ","

    '                If Array.IndexOf(Dest_idx, i) > -1 Then
    '                    '�u�����ت��a�����
    '                    path += shorter_path
    '                    shorter_path = ""
    '                    'MsgBox(path)
    '                End If

    '            End If
    '        Next
    '    End While

    '    Try
    '        If OK_FLAG = False Then
    '            Return ""
    '        Else

    '            For i As Integer = 0 To Dest_idx.Length - 1
    '                If (Distance(Dest_idx(i)) < 99999) Then
    '                    If Not Distance_Path(Dest_idx(i)).StartsWith(idx(start_idx).ToString + ",") Then
    '                        path = idx(start_idx).ToString + "," + Distance_Path(Dest_idx(i)) + idx(Dest_idx(i)).ToString
    '                    Else
    '                        path = Distance_Path(Dest_idx(i)) + idx(Dest_idx(i)).ToString
    '                    End If
    '                    Return path

    '                End If
    '            Next

    '            Return ""
    '        End If
    '    Catch ex As Exception
    '        Return ""
    '    End Try
    'End Function


    
    Function Dijkstra_fn_ary(ByVal List1(,) As Integer, ByVal idx() As Integer, ByVal start As Integer, ByVal Dest_list As String, Optional ByVal blocking_ID As String = "", Optional ByVal blocking_Path As String = "")


        Dim L1_lenght As Integer = idx.Length
        Dim start_idx As Integer = Array.IndexOf(idx, start) '�নIDX
        Dim Dest_list_str() As String = Dest_list.Split(",")
        Dim Dest(Dest_list_str.Length - 1) As Integer
        Dim i As Integer
        Dim Dest_idx(Dest.Length - 1) As Integer
        Dim OK_flag As Boolean = False
        Dim OK_idx As Integer = 0
        'blocking_Path = "3003,14001;9001,9002"
        Dim L1(,) As Integer = List1.Clone
        Dim blocking_Path_list() As String = blocking_Path.Split(";")
        Dim blocking_Path_list_idx(blocking_Path_list.Length - 1, 1) As Integer
        '������|
        For i = 0 To blocking_Path_list.Length - 1
            Dim temp() As String = blocking_Path_list(i).Split(",")
            If temp.Length = 2 Then
                blocking_Path_list_idx(i, 0) = Array.IndexOf(idx, CInt(temp(0))) '�নIDX
                blocking_Path_list_idx(i, 1) = Array.IndexOf(idx, CInt(temp(1))) '�নIDX
                If blocking_Path_list_idx(i, 0) > -1 And blocking_Path_list_idx(i, 1) Then
                    L1(blocking_Path_list_idx(i, 0), blocking_Path_list_idx(i, 1)) = 99999
                    L1(blocking_Path_list_idx(i, 1), blocking_Path_list_idx(i, 0)) = 99999
                End If
            End If
        Next


        For i = 0 To Dest.Length - 1
            If IsNumeric(Dest_list_str(i)) Then
                Dest(i) = CInt(Dest_list_str(i))
            End If
        Next

        If (Array.IndexOf(Dest, start) > -1) Then
            Return start.ToString
        End If
        Dim blocking_idx As Integer = -1
        Dim isLabel(L1_lenght - 1) As Boolean
        Dim block_list() As String = blocking_ID.Split(",")
        For Each val As String In block_list
            If IsNumeric(val) Then
                Try
                    blocking_idx = Array.IndexOf(idx, CInt(val)) '�নIDX
                    isLabel(blocking_idx) = True
                Catch ex As Exception

                End Try

            End If
        Next
        'If start_idx = -1 Or Dest_idx = -1 Then
        '    Return ""
        'End If

        Dim path As String = (start_idx + 1).ToString.PadLeft(4, "0") + "-"
        Dim shorter_path As String = ""

        Dim count As Integer = 0


        Dim N(L1_lenght) As Integer
        Dim Distance(L1_lenght - 1) As Integer
        Dim Distance_Path(L1_lenght - 1) As String
        Dim index As Integer = start_idx
        Dim presentShortest As Integer = 0 '���e�{�ɳ̵u�Z�� 
        Dim presentShortest_path As String = "" '���e�{�ɳ̵u�Z�� 
        For i = 0 To Dest.Length - 1
            Dest_idx(i) = Array.IndexOf(idx, Dest(i)) '�নIDX
        Next

        Try

            For i = 0 To L1_lenght - 1
                '��l��
                'path(i) = (start + 1).ToString '�_�I���]START
                Distance(i) = L1(start_idx, i) '�_�l�Z���A���۾F���I �Z����9999
                Distance_Path(i) = ""
            Next
        Catch ex As Exception
            Return ""
        End Try
        N(count) = index
        isLabel(index) = True
        While (count < L1_lenght)
            'count=0 ������̪��I
            Dim min As Integer = 9999999

            For i = 0 To Distance.Length - 1
                If (Not isLabel(i) And Not i = index) Then
                    If (Distance(i) < min) Then
                        min = Distance(i)
                        index = i
                    End If
                End If
            Next
            isLabel(index) = True            '
            count += 1
            N(count) = index '�N�ҿ�쪺�I�ƤJ�U�����~�W��
            '�U�@��STEP�}�l
            If L1(N(count - 1), index) > 9990 Or presentShortest + L1(N(count - 1), index) > Distance(index) Then
                ' �p�G�Щw���I�M���e�@�ӼЩw���I�����S�������۳s�A�Ϊ̳o����I�����|�j��̵u���|
                presentShortest = Distance(index)
                presentShortest_path = Distance_Path(index)
            Else
                presentShortest += L1(N(count - 1), index) '�q�}�C���X��
                presentShortest_path += idx(N(count - 1)).ToString + ","
            End If
            If Array.IndexOf(Dest_idx, index) > -1 Then
                OK_flag = True
                OK_idx = index
                Exit While
            End If
            '�ĤG�B�G�NDistance�����Z���[�Jvi
            For i = 0 To Distance.Length - 1
                '�p�Gvi�쨺���I����A�hv0��᭱�I���Z���[
                If (presentShortest + L1(index, i) < Distance(i)) Then
                    '�p�G�H�e�i�F�A���{�b�����|��H�e��u�A�h�󴫦���u�����|
                    Distance(i) = presentShortest + L1(index, i)
                    Distance_Path(i) = presentShortest_path + idx(index).ToString + ","
                    If Array.IndexOf(Dest_idx, i) > -1 Then
                        '�u�����ت��a�����
                        path += shorter_path
                        shorter_path = ""
                    End If

                End If
            Next
        End While
        Try
            If OK_flag = False Then
                Return ""
            Else

                For i = 0 To Dest_idx.Length - 1
                    If (Distance(Dest_idx(i)) < 99999) And OK_idx = Dest_idx(i) Then
                        If Not Distance_Path(Dest_idx(i)).StartsWith(idx(start_idx).ToString + ",") Then
                            path = idx(start_idx).ToString + "," + Distance_Path(Dest_idx(i)) + idx(Dest_idx(i)).ToString
                        Else
                            path = Distance_Path(Dest_idx(i)) + idx(Dest_idx(i)).ToString
                        End If
                        Return path

                    End If
                Next

                Return ""
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Function in_array(ByVal N() As Integer, ByVal X As Integer)
        Dim i As Integer

        For i = 0 To N.Length - 1
            If N(i) = X Then
                Return True
            End If
        Next

        Return False

    End Function

End Module
