﻿Imports System.Net.Sockets
Imports System.Threading
Module Door
    Public Structure Door_point
        Dim flag As Boolean
        Dim Connect_flag As Boolean
        Dim control_flag As Integer
        Dim EQ_ID As String
        Dim ReadOK As Boolean
        Dim tagid As Integer
        Dim ipadress As String
        Dim port As Integer
        Dim tcp_client As TcpClient
        Dim TCPstream As NetworkStream
        Dim startDO As Integer
        Dim startDI As Integer
        Dim write_stop As Integer
        Dim write_up As Integer
        Dim write_down As Integer
        Dim subcmd As String
        Dim stop_point As Integer
        Dim up_point As Integer
        Dim down_point As Integer
        ' Dim block_sensor As Integer
        Dim up_sensor As Integer
        Dim Pre_up_sensor As Integer
        ' Dim down_sensor As Integer
        Dim Door_type As String
        ' Dim Door_Pic As Label
        Dim retry As Integer
        Dim Top As Integer
        Dim Left As Integer
        Public Sub New(ByVal set_flag As Boolean)
            flag = set_flag
            EQ_ID = ""
            tagid = 0
            startDO = 0
            startDI = 0
            stop_point = 0
            up_point = 0
            down_point = 0
            ' block_sensor = 0
            up_sensor = 0
            ' down_sensor = 0
            write_stop = 0
            write_up = 0
            write_down = 0
            ipadress = "0.0.0.0"
            ReadOK = False
            subcmd = ""
            control_flag = -1
            port = 0
            Door_type = ""
            retry = 0
        End Sub
        Function connect() As Boolean
            connect = False
            Connect_flag = False
            retry = 0
            Try
                If (My.Computer.Network.Ping(ipadress)) Then
                    tcp_client = New TcpClient
                    tcp_client.Connect(ipadress, port)
                    If tcp_client.Connected Then
                        TCPstream = tcp_client.GetStream
                        TCPstream.WriteByte(80)
                        TCPstream.ReadTimeout = 1000
                        Connect_flag = True
                        connect = True
                    End If
                End If
            Catch ex As Exception

            End Try

        End Function
        Function Read_DI()
            Dim Wbyte(11) As Byte
            Dim Rbyte(100) As Byte
            Dim cnt As Integer = 0
            subcmd = tagid.ToString
            Read_DI = False
            If Connect_flag Then
                Try
                    If Door_type = "Iron_door" Then
                        Wbyte(0) = 0
                        Wbyte(1) = 0
                        Wbyte(2) = 0
                        Wbyte(3) = 0
                        Wbyte(4) = 0
                        Wbyte(5) = 6
                        Wbyte(6) = 1
                        Wbyte(7) = 2
                        Wbyte(8) = 0
                        Wbyte(9) = startDI
                        Wbyte(10) = 0
                        Wbyte(11) = 3
                        While TCPstream.DataAvailable
                            TCPstream.ReadByte()
                        End While
                        TCPstream.Write(Wbyte, 0, 12)
                        Thread.Sleep(100)
                        cnt = TCPstream.Read(Rbyte, 0, 100)
                        If cnt = 10 Then
                            If Rbyte(6) = 1 And Rbyte(7) = 2 Then
                                up_sensor = (Rbyte(9) >> 1) Mod 2
                                If up_sensor = 1 Then
                                    subcmd = ""
                                Else
                                    subcmd = tagid.ToString
                                End If
                                Read_DI = True
                                retry = 0
                            Else
                                Read_DI = False
                            End If
                     
                        End If
                    End If


                Catch ex As Exception
                    Read_DI = False
                    retry += 1
                End Try
            End If
        End Function
        Function Read_DO() As Integer
            Dim Wbyte(11) As Byte
            Dim Rbyte(100) As Byte
            Dim cnt As Integer = 0
            Read_DO = -1
            'Try
            If Connect_flag Then
                Try


                    If Door_type = "Iron_door" Then
                        Wbyte(0) = 0
                        Wbyte(1) = 0
                        Wbyte(2) = 0
                        Wbyte(3) = 0
                        Wbyte(4) = 0
                        Wbyte(5) = 6
                        Wbyte(6) = 1
                        Wbyte(7) = 1
                        Wbyte(8) = 0
                        Wbyte(9) = startDO
                        Wbyte(10) = 0
                        Wbyte(11) = 3
                        While TCPstream.DataAvailable
                            TCPstream.ReadByte()
                        End While
                        TCPstream.Write(Wbyte, 0, 12)
                        Thread.Sleep(100)
                        cnt = TCPstream.Read(Rbyte, 0, 100)
                        If cnt = 10 Then
                            If Rbyte(6) = 1 And Rbyte(7) = 1 Then
                                down_point = (Rbyte(9) >> 2) Mod 2
                                up_point = (Rbyte(9) >> 1) Mod 2
                                stop_point = Rbyte(9) Mod 2
                                ReadOK = True
                                retry = 0
                                Read_DO = Rbyte(9)
                            End If

                        End If
                    End If
                Catch ex As Exception
                    down_point = 0
                    up_point = 0
                    stop_point = 0
                    ReadOK = False
                    Read_DO = 0
                    retry += 1
                End Try
            End If

        End Function

        Sub DoorUp()
            write_stop = 0
            write_up = 0
            write_down = 0
            If up_sensor = 1 Then
                write_stop = 1
            Else
                write_up = 1
            End If
            Write_DO()
        End Sub
        Sub DoorDown()
            write_stop = 0
            write_up = 0
            write_down = 1
            Write_DO()
        End Sub

        Function Write_DO() As Integer
            Write_DO = -1
            If Door_type = "Iron_door" Then
                Try


                    Dim Wbyte(13) As Byte
                    Dim Rbyte(100) As Byte
                    Wbyte(0) = 0
                    Wbyte(1) = Now.Second Mod 256
                    Wbyte(2) = 0
                    Wbyte(3) = 0
                    Wbyte(4) = 0
                    Wbyte(5) = 8
                    Wbyte(6) = 1
                    Wbyte(7) = 15
                    Wbyte(8) = 0
                    Wbyte(9) = startDO
                    Wbyte(10) = 0
                    Wbyte(11) = 3 '個數
                    Wbyte(12) = 1 'byte 數
                    Wbyte(13) = (write_down << 2) + (write_up << 1) + write_stop

                    TCPstream.Write(Wbyte, 0, 14)

                    Do
                        Try
                            TCPstream.Read(Rbyte, 0, 100)
                        Catch ex As Exception
                            Exit Do
                        End Try
                    Loop While TCPstream.DataAvailable
                Catch ex As Exception
                    Write_DO = -1
                    retry += 1
                End Try
            End If

        End Function


        Function Write_OHT() As Integer
            Dim Rbyte(100) As Byte
            Dim status1 As String = ""
            Dim k As Integer = 0
            Dim set_val As Integer = 1 + write_up * 2 + write_stop * 4 + write_down * 8
            Dim val As Integer = 1 + up_point * 2 + stop_point * 4 + down_point * 8
            Dim cmd As String = "03FF000A44200000" + Hex(startDO).ToString.PadLeft(4, "0") + "0100" + Hex(set_val).ToString.PadLeft(4, "0")
            Write_OHT = -1
            If Not val = set_val Then

                TCPstream.Write(System.Text.Encoding.Default.GetBytes(cmd), 0, cmd.Length)
                Threading.Thread.Sleep(500)
                If TCPstream.DataAvailable Then
                    k = TCPstream.Read(Rbyte, 0, 100)
                    status1 = System.Text.Encoding.Default.GetString(Rbyte)
                    If status1.StartsWith("8300") And k = 4 Then
                        Write_OHT = 1

                    End If
                End If
            Else
                Write_OHT = 0
            End If

        End Function
        Sub release()
            write_down = 0
            write_up = 0
            write_stop = 0
            control_flag = -1
            Write_DO()
        End Sub
    End Structure


End Module
