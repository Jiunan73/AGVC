﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
Me.components = New System.ComponentModel.Container()
Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
Me.TabControl1 = New System.Windows.Forms.TabControl()
Me.TabPage1 = New System.Windows.Forms.TabPage()
Me.CheckBox3 = New System.Windows.Forms.CheckBox()
Me.LFT6 = New System.Windows.Forms.Label()
Me.LFT5 = New System.Windows.Forms.Label()
Me.LFT4 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic280 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic279 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic278 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic277 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic276 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic275 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic274 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic273 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic272 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic271 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic270 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic269 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic268 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic267 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic266 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic265 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic263 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic264 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic262 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic261 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic260 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic259 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic258 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic257 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic256 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic255 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic254 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic253 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic252 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic251 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic250 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic249 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic248 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic247 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic246 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic245 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic244 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic243 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic242 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic241 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic240 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic239 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic238 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic237 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic236 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic235 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic234 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic233 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic232 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic231 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic230 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic229 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic228 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic227 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic226 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic225 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic224 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic223 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic222 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic221 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic220 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic219 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic218 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic217 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic216 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic215 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic214 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic213 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic212 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic211 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic210 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic209 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic208 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic207 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic206 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic205 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic204 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic203 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic202 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic201 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic200 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic199 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic198 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic197 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic196 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic195 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic194 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic193 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic192 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic191 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic190 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic189 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic188 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic187 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic186 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic185 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic184 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic183 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic182 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic181 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic180 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic179 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic178 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic177 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic176 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic175 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic174 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic173 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic172 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic171 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic170 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic169 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic168 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic167 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic166 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic165 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic164 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic163 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic162 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic161 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic160 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic159 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic158 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic157 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic156 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic155 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic154 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic153 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic152 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic151 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic150 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic149 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic148 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic147 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic146 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic145 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic144 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic143 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic142 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic141 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic140 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic139 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic138 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic137 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic136 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic135 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic134 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic133 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic132 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic131 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic130 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic129 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic128 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic127 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic126 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic125 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic124 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic123 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic122 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic121 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic120 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic119 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic118 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic117 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic116 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic115 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic114 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic113 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic112 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic111 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic110 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic109 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic108 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic107 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic106 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic105 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic104 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic103 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic102 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic101 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic100 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic99 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic98 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic97 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic96 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic95 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic94 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic93 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic92 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic91 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic90 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic89 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic88 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic87 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic86 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic85 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic84 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic83 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic82 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic81 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic80 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic79 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic78 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic77 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic76 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic75 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic74 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic73 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic71 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic70 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic69 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic68 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic67 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic66 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic65 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic64 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic63 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic62 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic61 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic60 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic59 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic58 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic57 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic56 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic55 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic54 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic53 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic52 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic51 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic50 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic49 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic48 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic47 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic46 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic45 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic44 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic43 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic42 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic41 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic72 = New System.Windows.Forms.Label()
Me.LFT3 = New System.Windows.Forms.Label()
Me.LFT2 = New System.Windows.Forms.Label()
Me.LFT1 = New System.Windows.Forms.Label()
Me.LFT0 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic40 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic39 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic38 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic37 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic36 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic35 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic34 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic33 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic32 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic31 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic30 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic29 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic28 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic27 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic26 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic25 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic24 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic23 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic22 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic21 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic20 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic19 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic18 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic17 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic16 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic15 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic14 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic13 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic12 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic11 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic10 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic9 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic8 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic7 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic6 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic5 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic4 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic3 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic2 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic1 = New System.Windows.Forms.Label()
Me.Shelf_Car_Pic0 = New System.Windows.Forms.Label()
Me.PictureBox1 = New System.Windows.Forms.PictureBox()
Me.TabPage2 = New System.Windows.Forms.TabPage()
Me.GroupBox5 = New System.Windows.Forms.GroupBox()
Me.Label56 = New System.Windows.Forms.Label()
Me.Label30 = New System.Windows.Forms.Label()
Me.MapY = New System.Windows.Forms.TextBox()
Me.MapX = New System.Windows.Forms.TextBox()
Me.BlockPoint = New System.Windows.Forms.TextBox()
Me.Button17 = New System.Windows.Forms.Button()
Me.Label101 = New System.Windows.Forms.Label()
Me.DebugMode = New System.Windows.Forms.CheckBox()
Me.Label88 = New System.Windows.Forms.Label()
Me.Label66 = New System.Windows.Forms.Label()
Me.SOCTxt = New System.Windows.Forms.TextBox()
Me.ALL_Loading_check = New System.Windows.Forms.CheckBox()
Me.Label47 = New System.Windows.Forms.Label()
Me.Label61 = New System.Windows.Forms.Label()
Me.Label100 = New System.Windows.Forms.Label()
Me.MyDB_txt = New System.Windows.Forms.TextBox()
Me.Label58 = New System.Windows.Forms.Label()
Me.Label57 = New System.Windows.Forms.Label()
Me.Loading_Check = New System.Windows.Forms.CheckBox()
Me.McsPortTxt = New System.Windows.Forms.TextBox()
Me.Label31 = New System.Windows.Forms.Label()
Me.LPort = New System.Windows.Forms.TextBox()
Me.Agvc_shelfcheck = New System.Windows.Forms.CheckBox()
Me.Label62 = New System.Windows.Forms.Label()
Me.ratio = New System.Windows.Forms.TextBox()
Me.IP = New System.Windows.Forms.TextBox()
Me.Label72 = New System.Windows.Forms.Label()
Me.Label46 = New System.Windows.Forms.Label()
Me.AgvTimeout = New System.Windows.Forms.TextBox()
Me.user_txt = New System.Windows.Forms.TextBox()
Me.Label65 = New System.Windows.Forms.Label()
Me.Label63 = New System.Windows.Forms.Label()
Me.DoorSetLenTxt = New System.Windows.Forms.TextBox()
Me.password_txt = New System.Windows.Forms.TextBox()
Me.Label67 = New System.Windows.Forms.Label()
Me.GroupBox2 = New System.Windows.Forms.GroupBox()
Me.RetreatPath = New System.Windows.Forms.TextBox()
Me.Label116 = New System.Windows.Forms.Label()
Me.SiteTxt = New System.Windows.Forms.TextBox()
Me.Label115 = New System.Windows.Forms.Label()
Me.Label114 = New System.Windows.Forms.Label()
Me.block_Path = New System.Windows.Forms.TextBox()
Me.RePath = New System.Windows.Forms.TextBox()
Me.Label106 = New System.Windows.Forms.Label()
Me.MaxPath = New System.Windows.Forms.TextBox()
Me.Label113 = New System.Windows.Forms.Label()
Me.Button30 = New System.Windows.Forms.Button()
Me.ReverseXY = New System.Windows.Forms.TextBox()
Me.Label112 = New System.Windows.Forms.Label()
Me.SetOffset_Y = New System.Windows.Forms.TextBox()
Me.Label111 = New System.Windows.Forms.Label()
Me.Recharge_volt = New System.Windows.Forms.TextBox()
Me.Label102 = New System.Windows.Forms.Label()
Me.AGV_SetNo = New System.Windows.Forms.ComboBox()
Me.SetOffset_X = New System.Windows.Forms.TextBox()
Me.Label110 = New System.Windows.Forms.Label()
Me.Label103 = New System.Windows.Forms.Label()
Me.Recharge_SOC = New System.Windows.Forms.TextBox()
Me.Setheight = New System.Windows.Forms.TextBox()
Me.Label109 = New System.Windows.Forms.Label()
Me.Label104 = New System.Windows.Forms.Label()
Me.Recharge_Point = New System.Windows.Forms.TextBox()
Me.Setwidth = New System.Windows.Forms.TextBox()
Me.Label108 = New System.Windows.Forms.Label()
Me.Label105 = New System.Windows.Forms.Label()
Me.wait_point = New System.Windows.Forms.TextBox()
Me.Label107 = New System.Windows.Forms.Label()
Me.block_point = New System.Windows.Forms.TextBox()
Me.GroupBox1 = New System.Windows.Forms.GroupBox()
Me.Label92 = New System.Windows.Forms.Label()
Me.Button35 = New System.Windows.Forms.Button()
Me.Err211 = New System.Windows.Forms.CheckBox()
Me.IR_check = New System.Windows.Forms.CheckBox()
Me.Label59 = New System.Windows.Forms.Label()
Me.TabPage3 = New System.Windows.Forms.TabPage()
Me.Button13 = New System.Windows.Forms.Button()
Me.Button11 = New System.Windows.Forms.Button()
Me.Label89 = New System.Windows.Forms.Label()
Me.Econ_49 = New System.Windows.Forms.TextBox()
Me.Label90 = New System.Windows.Forms.Label()
Me.Econ_48 = New System.Windows.Forms.TextBox()
Me.Label91 = New System.Windows.Forms.Label()
Me.Econ_47 = New System.Windows.Forms.TextBox()
Me.Label93 = New System.Windows.Forms.Label()
Me.Econ_46 = New System.Windows.Forms.TextBox()
Me.Label94 = New System.Windows.Forms.Label()
Me.Econ_45 = New System.Windows.Forms.TextBox()
Me.Label95 = New System.Windows.Forms.Label()
Me.Econ_44 = New System.Windows.Forms.TextBox()
Me.Label96 = New System.Windows.Forms.Label()
Me.Econ_43 = New System.Windows.Forms.TextBox()
Me.Label97 = New System.Windows.Forms.Label()
Me.Econ_42 = New System.Windows.Forms.TextBox()
Me.Label98 = New System.Windows.Forms.Label()
Me.Econ_41 = New System.Windows.Forms.TextBox()
Me.Label99 = New System.Windows.Forms.Label()
Me.Econ_40 = New System.Windows.Forms.TextBox()
Me.Label87 = New System.Windows.Forms.Label()
Me.Econ_39 = New System.Windows.Forms.TextBox()
Me.Label86 = New System.Windows.Forms.Label()
Me.Econ_38 = New System.Windows.Forms.TextBox()
Me.Label85 = New System.Windows.Forms.Label()
Me.Econ_37 = New System.Windows.Forms.TextBox()
Me.Label84 = New System.Windows.Forms.Label()
Me.Econ_36 = New System.Windows.Forms.TextBox()
Me.Label83 = New System.Windows.Forms.Label()
Me.Econ_35 = New System.Windows.Forms.TextBox()
Me.Label82 = New System.Windows.Forms.Label()
Me.Econ_34 = New System.Windows.Forms.TextBox()
Me.Label81 = New System.Windows.Forms.Label()
Me.Econ_33 = New System.Windows.Forms.TextBox()
Me.Label64 = New System.Windows.Forms.Label()
Me.Econ_32 = New System.Windows.Forms.TextBox()
Me.Label60 = New System.Windows.Forms.Label()
Me.Econ_31 = New System.Windows.Forms.TextBox()
Me.Label80 = New System.Windows.Forms.Label()
Me.CstID = New System.Windows.Forms.TextBox()
Me.Label69 = New System.Windows.Forms.Label()
Me.Label70 = New System.Windows.Forms.Label()
Me.Econ_30 = New System.Windows.Forms.TextBox()
Me.Econ_29 = New System.Windows.Forms.TextBox()
Me.Label71 = New System.Windows.Forms.Label()
Me.Econ_28 = New System.Windows.Forms.TextBox()
Me.Label73 = New System.Windows.Forms.Label()
Me.Label74 = New System.Windows.Forms.Label()
Me.Label75 = New System.Windows.Forms.Label()
Me.Label76 = New System.Windows.Forms.Label()
Me.Label77 = New System.Windows.Forms.Label()
Me.Label78 = New System.Windows.Forms.Label()
Me.Label79 = New System.Windows.Forms.Label()
Me.Econ_27 = New System.Windows.Forms.TextBox()
Me.Econ_26 = New System.Windows.Forms.TextBox()
Me.Econ_25 = New System.Windows.Forms.TextBox()
Me.Econ_24 = New System.Windows.Forms.TextBox()
Me.Econ_23 = New System.Windows.Forms.TextBox()
Me.Econ_22 = New System.Windows.Forms.TextBox()
Me.Econ_21 = New System.Windows.Forms.TextBox()
Me.Label55 = New System.Windows.Forms.Label()
Me.Label54 = New System.Windows.Forms.Label()
Me.Econ_19 = New System.Windows.Forms.TextBox()
Me.Econ_18 = New System.Windows.Forms.TextBox()
Me.Label52 = New System.Windows.Forms.Label()
Me.txtTemp_to = New System.Windows.Forms.TextBox()
Me.Label51 = New System.Windows.Forms.Label()
Me.strReserve_txt = New System.Windows.Forms.TextBox()
Me.Label50 = New System.Windows.Forms.Label()
Me.Label48 = New System.Windows.Forms.Label()
Me.Label49 = New System.Windows.Forms.Label()
Me.txtFrom = New System.Windows.Forms.TextBox()
Me.txtTo = New System.Windows.Forms.TextBox()
Me.txtToAGV20 = New System.Windows.Forms.TextBox()
Me.Label41 = New System.Windows.Forms.Label()
Me.Label42 = New System.Windows.Forms.Label()
Me.Label43 = New System.Windows.Forms.Label()
Me.Label44 = New System.Windows.Forms.Label()
Me.Label45 = New System.Windows.Forms.Label()
Me.Label36 = New System.Windows.Forms.Label()
Me.Label37 = New System.Windows.Forms.Label()
Me.Label38 = New System.Windows.Forms.Label()
Me.Label39 = New System.Windows.Forms.Label()
Me.Label40 = New System.Windows.Forms.Label()
Me.Label25 = New System.Windows.Forms.Label()
Me.Label26 = New System.Windows.Forms.Label()
Me.Label33 = New System.Windows.Forms.Label()
Me.Label34 = New System.Windows.Forms.Label()
Me.Label35 = New System.Windows.Forms.Label()
Me.txtToAGV18 = New System.Windows.Forms.TextBox()
Me.txtToAGV19 = New System.Windows.Forms.TextBox()
Me.txtToAGV17 = New System.Windows.Forms.TextBox()
Me.txtToAGV16 = New System.Windows.Forms.TextBox()
Me.txtToAGV15 = New System.Windows.Forms.TextBox()
Me.txtToAGV13 = New System.Windows.Forms.TextBox()
Me.txtToAGV14 = New System.Windows.Forms.TextBox()
Me.txtToAGV12 = New System.Windows.Forms.TextBox()
Me.txtToAGV11 = New System.Windows.Forms.TextBox()
Me.txtToAGV10 = New System.Windows.Forms.TextBox()
Me.txtToAGV9 = New System.Windows.Forms.TextBox()
Me.txtToAGV0 = New System.Windows.Forms.TextBox()
Me.txtToAGV8 = New System.Windows.Forms.TextBox()
Me.txtToAGV7 = New System.Windows.Forms.TextBox()
Me.txtToAGV6 = New System.Windows.Forms.TextBox()
Me.Label32 = New System.Windows.Forms.Label()
Me.Econ_17 = New System.Windows.Forms.TextBox()
Me.Label29 = New System.Windows.Forms.Label()
Me.WorkList = New System.Windows.Forms.TextBox()
Me.Label27 = New System.Windows.Forms.Label()
Me.Label28 = New System.Windows.Forms.Label()
Me.txtToAGV4 = New System.Windows.Forms.TextBox()
Me.txtToAGV5 = New System.Windows.Forms.TextBox()
Me.Label23 = New System.Windows.Forms.Label()
Me.Label22 = New System.Windows.Forms.Label()
Me.Label21 = New System.Windows.Forms.Label()
Me.txtToAGV3 = New System.Windows.Forms.TextBox()
Me.txtToAGV2 = New System.Windows.Forms.TextBox()
Me.txtToAGV1 = New System.Windows.Forms.TextBox()
Me.Label12 = New System.Windows.Forms.Label()
Me.Label11 = New System.Windows.Forms.Label()
Me.TextBox2 = New System.Windows.Forms.TextBox()
Me.TextBox1 = New System.Windows.Forms.TextBox()
Me.Label13 = New System.Windows.Forms.Label()
Me.Label14 = New System.Windows.Forms.Label()
Me.Label15 = New System.Windows.Forms.Label()
Me.Label16 = New System.Windows.Forms.Label()
Me.Label17 = New System.Windows.Forms.Label()
Me.Label18 = New System.Windows.Forms.Label()
Me.Label19 = New System.Windows.Forms.Label()
Me.Label20 = New System.Windows.Forms.Label()
Me.Econ_20 = New System.Windows.Forms.TextBox()
Me.Econ_16 = New System.Windows.Forms.TextBox()
Me.Econ_15 = New System.Windows.Forms.TextBox()
Me.Econ_14 = New System.Windows.Forms.TextBox()
Me.Econ_13 = New System.Windows.Forms.TextBox()
Me.Econ_12 = New System.Windows.Forms.TextBox()
Me.Econ_11 = New System.Windows.Forms.TextBox()
Me.Econ_10 = New System.Windows.Forms.TextBox()
Me.Label10 = New System.Windows.Forms.Label()
Me.Label9 = New System.Windows.Forms.Label()
Me.Label5 = New System.Windows.Forms.Label()
Me.Label6 = New System.Windows.Forms.Label()
Me.Label7 = New System.Windows.Forms.Label()
Me.Label8 = New System.Windows.Forms.Label()
Me.Label4 = New System.Windows.Forms.Label()
Me.Label3 = New System.Windows.Forms.Label()
Me.Label2 = New System.Windows.Forms.Label()
Me.Label1 = New System.Windows.Forms.Label()
Me.Econ_9 = New System.Windows.Forms.TextBox()
Me.Econ_8 = New System.Windows.Forms.TextBox()
Me.Econ_7 = New System.Windows.Forms.TextBox()
Me.Econ_6 = New System.Windows.Forms.TextBox()
Me.Econ_5 = New System.Windows.Forms.TextBox()
Me.Econ_4 = New System.Windows.Forms.TextBox()
Me.Econ_3 = New System.Windows.Forms.TextBox()
Me.Econ_2 = New System.Windows.Forms.TextBox()
Me.Econ_1 = New System.Windows.Forms.TextBox()
Me.Econ_0 = New System.Windows.Forms.TextBox()
Me.TabPage5 = New System.Windows.Forms.TabPage()
Me.Button15 = New System.Windows.Forms.Button()
Me.Button1 = New System.Windows.Forms.Button()
Me.Label53 = New System.Windows.Forms.Label()
Me.Door_Data_txt = New System.Windows.Forms.TextBox()
Me.Door_idx = New System.Windows.Forms.ComboBox()
Me.Button21 = New System.Windows.Forms.Button()
Me.Button3 = New System.Windows.Forms.Button()
Me.Button6 = New System.Windows.Forms.Button()
Me.TabPage4 = New System.Windows.Forms.TabPage()
Me.AGVIO4_15 = New System.Windows.Forms.Label()
Me.AGVIO4_14 = New System.Windows.Forms.Label()
Me.AGVIO4_13 = New System.Windows.Forms.Label()
Me.AGVIO4_12 = New System.Windows.Forms.Label()
Me.AGVIO4_11 = New System.Windows.Forms.Label()
Me.AGVIO4_10 = New System.Windows.Forms.Label()
Me.AGVIO4_09 = New System.Windows.Forms.Label()
Me.AGVIO4_08 = New System.Windows.Forms.Label()
Me.AGVIO4_07 = New System.Windows.Forms.Label()
Me.AGVIO4_06 = New System.Windows.Forms.Label()
Me.AGVIO4_05 = New System.Windows.Forms.Label()
Me.AGVIO4_04 = New System.Windows.Forms.Label()
Me.AGVIO4_03 = New System.Windows.Forms.Label()
Me.AGVIO4_02 = New System.Windows.Forms.Label()
Me.AGVIO4_01 = New System.Windows.Forms.Label()
Me.AGVIO4_00 = New System.Windows.Forms.Label()
Me.AGVIO3_15 = New System.Windows.Forms.Label()
Me.AGVIO3_14 = New System.Windows.Forms.Label()
Me.AGVIO3_13 = New System.Windows.Forms.Label()
Me.AGVIO3_12 = New System.Windows.Forms.Label()
Me.AGVIO3_11 = New System.Windows.Forms.Label()
Me.AGVIO3_10 = New System.Windows.Forms.Label()
Me.AGVIO3_09 = New System.Windows.Forms.Label()
Me.AGVIO3_08 = New System.Windows.Forms.Label()
Me.AGVIO3_07 = New System.Windows.Forms.Label()
Me.AGVIO3_06 = New System.Windows.Forms.Label()
Me.AGVIO3_05 = New System.Windows.Forms.Label()
Me.AGVIO3_04 = New System.Windows.Forms.Label()
Me.AGVIO3_03 = New System.Windows.Forms.Label()
Me.AGVIO3_02 = New System.Windows.Forms.Label()
Me.AGVIO3_01 = New System.Windows.Forms.Label()
Me.AGVIO3_00 = New System.Windows.Forms.Label()
Me.AGVIO2_15 = New System.Windows.Forms.Label()
Me.AGVIO2_14 = New System.Windows.Forms.Label()
Me.AGVIO2_13 = New System.Windows.Forms.Label()
Me.AGVIO2_12 = New System.Windows.Forms.Label()
Me.AGVIO2_11 = New System.Windows.Forms.Label()
Me.AGVIO2_10 = New System.Windows.Forms.Label()
Me.AGVIO2_09 = New System.Windows.Forms.Label()
Me.AGVIO2_08 = New System.Windows.Forms.Label()
Me.AGVIO2_07 = New System.Windows.Forms.Label()
Me.AGVIO2_06 = New System.Windows.Forms.Label()
Me.AGVIO2_05 = New System.Windows.Forms.Label()
Me.AGVIO2_04 = New System.Windows.Forms.Label()
Me.AGVIO2_03 = New System.Windows.Forms.Label()
Me.AGVIO2_02 = New System.Windows.Forms.Label()
Me.AGVIO2_01 = New System.Windows.Forms.Label()
Me.AGVIO2_00 = New System.Windows.Forms.Label()
Me.AGVIO1_15 = New System.Windows.Forms.Label()
Me.AGVIO1_10 = New System.Windows.Forms.Label()
Me.AGVIO1_14 = New System.Windows.Forms.Label()
Me.AGVIO1_13 = New System.Windows.Forms.Label()
Me.AGVIO1_12 = New System.Windows.Forms.Label()
Me.AGVIO1_11 = New System.Windows.Forms.Label()
Me.AGVIO1_09 = New System.Windows.Forms.Label()
Me.AGVIO1_08 = New System.Windows.Forms.Label()
Me.AGVIO1_07 = New System.Windows.Forms.Label()
Me.AGVIO1_06 = New System.Windows.Forms.Label()
Me.AGVIO1_05 = New System.Windows.Forms.Label()
Me.AGVIO1_04 = New System.Windows.Forms.Label()
Me.AGVIO1_03 = New System.Windows.Forms.Label()
Me.AGVIO1_02 = New System.Windows.Forms.Label()
Me.AGVIO1_01 = New System.Windows.Forms.Label()
Me.AGVIO1_00 = New System.Windows.Forms.Label()
Me.LFT_name = New System.Windows.Forms.Label()
Me.Car_text = New System.Windows.Forms.Label()
Me.step_text = New System.Windows.Forms.Label()
Me.opendata = New System.Windows.Forms.Label()
Me.Button23 = New System.Windows.Forms.Button()
Me.Button22 = New System.Windows.Forms.Button()
Me.LFT_idx = New System.Windows.Forms.ComboBox()
Me.LFT_W15 = New System.Windows.Forms.Label()
Me.LFT_W14 = New System.Windows.Forms.Label()
Me.LFT_W13 = New System.Windows.Forms.Label()
Me.LFT_W12 = New System.Windows.Forms.Label()
Me.LFT_W11 = New System.Windows.Forms.Label()
Me.LFT_W10 = New System.Windows.Forms.Label()
Me.LFT_W9 = New System.Windows.Forms.Label()
Me.LFT_W8 = New System.Windows.Forms.Label()
Me.LFT_W7 = New System.Windows.Forms.Label()
Me.LFT_W6 = New System.Windows.Forms.Label()
Me.LFT_W5 = New System.Windows.Forms.Label()
Me.LFT_W4 = New System.Windows.Forms.Label()
Me.LFT_W3 = New System.Windows.Forms.Label()
Me.LFT_W2 = New System.Windows.Forms.Label()
Me.LFT_W1 = New System.Windows.Forms.Label()
Me.LFT_W0 = New System.Windows.Forms.Label()
Me.LFT_FLOOR = New System.Windows.Forms.Label()
Me.LFT_R15 = New System.Windows.Forms.Label()
Me.LFT_R14 = New System.Windows.Forms.Label()
Me.LFT_R13 = New System.Windows.Forms.Label()
Me.LFT_R12 = New System.Windows.Forms.Label()
Me.LFT_R11 = New System.Windows.Forms.Label()
Me.LFT_R10 = New System.Windows.Forms.Label()
Me.LFT_R9 = New System.Windows.Forms.Label()
Me.LFT_R8 = New System.Windows.Forms.Label()
Me.LFT_R7 = New System.Windows.Forms.Label()
Me.LFT_R6 = New System.Windows.Forms.Label()
Me.LFT_R5 = New System.Windows.Forms.Label()
Me.LFT_R4 = New System.Windows.Forms.Label()
Me.LFT_R3 = New System.Windows.Forms.Label()
Me.LFT_R2 = New System.Windows.Forms.Label()
Me.LFT_R1 = New System.Windows.Forms.Label()
Me.LFT_R0 = New System.Windows.Forms.Label()
Me.TabPage6 = New System.Windows.Forms.TabPage()
Me.Group_path_text = New System.Windows.Forms.TextBox()
Me.TabPage7 = New System.Windows.Forms.TabPage()
Me.VerLog = New System.Windows.Forms.TextBox()
Me.TabPage9 = New System.Windows.Forms.TabPage()
Me.Button5 = New System.Windows.Forms.Button()
Me.Button4 = New System.Windows.Forms.Button()
Me.car_info = New System.Windows.Forms.Label()
Me.Button9 = New System.Windows.Forms.Button()
Me.Button7 = New System.Windows.Forms.Button()
Me.TextBox3 = New System.Windows.Forms.TextBox()
Me.Button19 = New System.Windows.Forms.Button()
Me.Button18 = New System.Windows.Forms.Button()
Me.Button2 = New System.Windows.Forms.Button()
Me.car_type = New System.Windows.Forms.ComboBox()
Me.Button8 = New System.Windows.Forms.Button()
Me.TabPage10 = New System.Windows.Forms.TabPage()
Me.Button10 = New System.Windows.Forms.Button()
Me.Label117 = New System.Windows.Forms.Label()
Me.TextBox11 = New System.Windows.Forms.TextBox()
Me.lbl_SC_Stats = New System.Windows.Forms.Label()
Me.Button26 = New System.Windows.Forms.Button()
Me.Button27 = New System.Windows.Forms.Button()
Me.btn_OnlineLocal = New System.Windows.Forms.Button()
Me.btn_OnLineRemote = New System.Windows.Forms.Button()
Me.btn_Offline = New System.Windows.Forms.Button()
Me.btn_OnLine = New System.Windows.Forms.Button()
Me.ToLocList = New System.Windows.Forms.ComboBox()
Me.CSTList = New System.Windows.Forms.ComboBox()
Me.Button24 = New System.Windows.Forms.Button()
Me.CommTxt = New System.Windows.Forms.TextBox()
Me.txtCar = New System.Windows.Forms.ComboBox()
Me.SendBtn = New System.Windows.Forms.Button()
Me.To_cb = New System.Windows.Forms.ComboBox()
Me.From_cb = New System.Windows.Forms.ComboBox()
Me.MainBG_timer = New System.Windows.Forms.Timer(Me.components)
Me.cmd_timer = New System.Windows.Forms.Timer(Me.components)
Me.Log_txt = New System.Windows.Forms.TextBox()
Me.Button12 = New System.Windows.Forms.Button()
Me.ListView1 = New System.Windows.Forms.ListView()
Me.Cmdkey = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.AGVNo = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CmdFrom = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CmdTo = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Pri_Wt = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CMD_Status = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.RequestTime = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Requestor = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Shelf_Car_No = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Shelf_Car_type = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Shelf_Car_Size = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.RollData = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ext_cmd = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.McsCmdKey = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
Me.Label24 = New System.Windows.Forms.Label()
Me.Err_lb = New System.Windows.Forms.Label()
Me.door_check = New System.ComponentModel.BackgroundWorker()
Me.door_check_timer = New System.Windows.Forms.Timer(Me.components)
Me.LFT_timer = New System.Windows.Forms.Timer(Me.components)
Me.LFT_bgwork = New System.ComponentModel.BackgroundWorker()
Me.lbl_SECSConnectState = New System.Windows.Forms.Label()
Me.GroupBox3 = New System.Windows.Forms.GroupBox()
Me.GroupBox4 = New System.Windows.Forms.GroupBox()
Me.Label68 = New System.Windows.Forms.Label()
Me.lbl_CcontrolStats = New System.Windows.Forms.Label()
Me.GroupBox9 = New System.Windows.Forms.GroupBox()
Me.MCS = New System.Windows.Forms.Timer(Me.components)
Me.EQ_BG = New System.ComponentModel.BackgroundWorker()
Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
Me.SystemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.SCStateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.QueryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.TransferToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.CarrierToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.畫面縮小ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.ZoomOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.agv_info = New System.Windows.Forms.PictureBox()
Me.pic_close = New System.Windows.Forms.Button()
Me.rolldateTxt = New System.Windows.Forms.TextBox()
Me.Button16 = New System.Windows.Forms.Button()
Me.TabControl2 = New System.Windows.Forms.TabControl()
Me.TabPage11 = New System.Windows.Forms.TabPage()
Me.TabPage12 = New System.Windows.Forms.TabPage()
Me.alarm_list = New System.Windows.Forms.ListView()
Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.TabPage13 = New System.Windows.Forms.TabPage()
Me.ListView2 = New System.Windows.Forms.ListView()
Me.CarrierID = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CmdId = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.Pwt = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CurZone = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.CurLoc = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ToZone = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.State = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.soure = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(),System.Windows.Forms.ColumnHeader)
Me.TabPage14 = New System.Windows.Forms.TabPage()
Me.ContextMenuStrip3 = New System.Windows.Forms.ContextMenuStrip(Me.components)
Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.AddpwtToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
Me.BG_Update = New System.ComponentModel.BackgroundWorker()
Me.Hik_Car = New System.Windows.Forms.Timer(Me.components)
Me.HIK_BG = New System.ComponentModel.BackgroundWorker()
Me.TabControl1.SuspendLayout
Me.TabPage1.SuspendLayout
CType(Me.PictureBox1,System.ComponentModel.ISupportInitialize).BeginInit
Me.TabPage2.SuspendLayout
Me.GroupBox5.SuspendLayout
Me.GroupBox2.SuspendLayout
Me.GroupBox1.SuspendLayout
Me.TabPage3.SuspendLayout
Me.TabPage5.SuspendLayout
Me.TabPage4.SuspendLayout
Me.TabPage6.SuspendLayout
Me.TabPage7.SuspendLayout
Me.TabPage9.SuspendLayout
Me.TabPage10.SuspendLayout
Me.ContextMenuStrip1.SuspendLayout
Me.ContextMenuStrip2.SuspendLayout
Me.GroupBox3.SuspendLayout
Me.GroupBox4.SuspendLayout
Me.GroupBox9.SuspendLayout
Me.MenuStrip1.SuspendLayout
CType(Me.agv_info,System.ComponentModel.ISupportInitialize).BeginInit
Me.TabControl2.SuspendLayout
Me.TabPage11.SuspendLayout
Me.TabPage12.SuspendLayout
Me.TabPage13.SuspendLayout
Me.TabPage14.SuspendLayout
Me.ContextMenuStrip3.SuspendLayout
Me.SuspendLayout
'
'TabControl1
'
Me.TabControl1.Controls.Add(Me.TabPage1)
Me.TabControl1.Controls.Add(Me.TabPage2)
Me.TabControl1.Controls.Add(Me.TabPage3)
Me.TabControl1.Controls.Add(Me.TabPage5)
Me.TabControl1.Controls.Add(Me.TabPage4)
Me.TabControl1.Controls.Add(Me.TabPage6)
Me.TabControl1.Controls.Add(Me.TabPage7)
Me.TabControl1.Controls.Add(Me.TabPage9)
Me.TabControl1.Controls.Add(Me.TabPage10)
Me.TabControl1.Location = New System.Drawing.Point(0, 23)
Me.TabControl1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabControl1.Name = "TabControl1"
Me.TabControl1.SelectedIndex = 0
Me.TabControl1.Size = New System.Drawing.Size(1614, 760)
Me.TabControl1.TabIndex = 0
'
'TabPage1
'
Me.TabPage1.Controls.Add(Me.CheckBox3)
Me.TabPage1.Controls.Add(Me.LFT6)
Me.TabPage1.Controls.Add(Me.LFT5)
Me.TabPage1.Controls.Add(Me.LFT4)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic280)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic279)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic278)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic277)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic276)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic275)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic274)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic273)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic272)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic271)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic270)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic269)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic268)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic267)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic266)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic265)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic263)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic264)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic262)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic261)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic260)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic259)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic258)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic257)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic256)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic255)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic254)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic253)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic252)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic251)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic250)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic249)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic248)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic247)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic246)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic245)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic244)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic243)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic242)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic241)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic240)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic239)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic238)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic237)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic236)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic235)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic234)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic233)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic232)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic231)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic230)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic229)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic228)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic227)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic226)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic225)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic224)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic223)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic222)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic221)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic220)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic219)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic218)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic217)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic216)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic215)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic214)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic213)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic212)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic211)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic210)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic209)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic208)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic207)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic206)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic205)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic204)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic203)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic202)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic201)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic200)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic199)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic198)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic197)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic196)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic195)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic194)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic193)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic192)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic191)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic190)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic189)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic188)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic187)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic186)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic185)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic184)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic183)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic182)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic181)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic180)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic179)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic178)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic177)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic176)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic175)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic174)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic173)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic172)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic171)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic170)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic169)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic168)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic167)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic166)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic165)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic164)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic163)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic162)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic161)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic160)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic159)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic158)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic157)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic156)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic155)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic154)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic153)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic152)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic151)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic150)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic149)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic148)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic147)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic146)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic145)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic144)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic143)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic142)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic141)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic140)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic139)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic138)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic137)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic136)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic135)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic134)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic133)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic132)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic131)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic130)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic129)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic128)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic127)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic126)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic125)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic124)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic123)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic122)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic121)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic120)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic119)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic118)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic117)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic116)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic115)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic114)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic113)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic112)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic111)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic110)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic109)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic108)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic107)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic106)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic105)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic104)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic103)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic102)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic101)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic100)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic99)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic98)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic97)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic96)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic95)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic94)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic93)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic92)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic91)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic90)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic89)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic88)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic87)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic86)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic85)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic84)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic83)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic82)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic81)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic80)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic79)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic78)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic77)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic76)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic75)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic74)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic73)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic71)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic70)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic69)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic68)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic67)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic66)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic65)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic64)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic63)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic62)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic61)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic60)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic59)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic58)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic57)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic56)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic55)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic54)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic53)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic52)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic51)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic50)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic49)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic48)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic47)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic46)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic45)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic44)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic43)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic42)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic41)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic72)
Me.TabPage1.Controls.Add(Me.LFT3)
Me.TabPage1.Controls.Add(Me.LFT2)
Me.TabPage1.Controls.Add(Me.LFT1)
Me.TabPage1.Controls.Add(Me.LFT0)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic40)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic39)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic38)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic37)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic36)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic35)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic34)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic33)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic32)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic31)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic30)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic29)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic28)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic27)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic26)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic25)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic24)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic23)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic22)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic21)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic20)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic19)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic18)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic17)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic16)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic15)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic14)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic13)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic12)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic11)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic10)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic9)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic8)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic7)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic6)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic5)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic4)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic3)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic2)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic1)
Me.TabPage1.Controls.Add(Me.Shelf_Car_Pic0)
Me.TabPage1.Controls.Add(Me.PictureBox1)
Me.TabPage1.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage1.Location = New System.Drawing.Point(4, 24)
Me.TabPage1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage1.Name = "TabPage1"
Me.TabPage1.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage1.Size = New System.Drawing.Size(1606, 732)
Me.TabPage1.TabIndex = 0
Me.TabPage1.Text = "Controller"
Me.TabPage1.UseVisualStyleBackColor = true
'
'CheckBox3
'
Me.CheckBox3.AutoSize = true
Me.CheckBox3.Checked = true
Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
Me.CheckBox3.Location = New System.Drawing.Point(1112, 799)
Me.CheckBox3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.CheckBox3.Name = "CheckBox3"
Me.CheckBox3.Size = New System.Drawing.Size(75, 20)
Me.CheckBox3.TabIndex = 3
Me.CheckBox3.Text = "地圖切換"
Me.CheckBox3.UseVisualStyleBackColor = true
'
'LFT6
'
Me.LFT6.BackColor = System.Drawing.Color.Red
Me.LFT6.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT6.Location = New System.Drawing.Point(861, 60)
Me.LFT6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT6.Name = "LFT6"
Me.LFT6.Size = New System.Drawing.Size(47, 18)
Me.LFT6.TabIndex = 331
Me.LFT6.Text = "LFT6"
Me.LFT6.Visible = false
'
'LFT5
'
Me.LFT5.BackColor = System.Drawing.Color.Red
Me.LFT5.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT5.Location = New System.Drawing.Point(861, 36)
Me.LFT5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT5.Name = "LFT5"
Me.LFT5.Size = New System.Drawing.Size(47, 18)
Me.LFT5.TabIndex = 330
Me.LFT5.Text = "LFT5"
Me.LFT5.Visible = false
'
'LFT4
'
Me.LFT4.BackColor = System.Drawing.Color.Red
Me.LFT4.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT4.Location = New System.Drawing.Point(861, 14)
Me.LFT4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT4.Name = "LFT4"
Me.LFT4.Size = New System.Drawing.Size(47, 18)
Me.LFT4.TabIndex = 329
Me.LFT4.Text = "LFT4"
Me.LFT4.Visible = false
'
'Shelf_Car_Pic280
'
Me.Shelf_Car_Pic280.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic280.Location = New System.Drawing.Point(471, 680)
Me.Shelf_Car_Pic280.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic280.Name = "Shelf_Car_Pic280"
Me.Shelf_Car_Pic280.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic280.TabIndex = 313
Me.Shelf_Car_Pic280.Text = "6001"
Me.Shelf_Car_Pic280.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic280.Visible = false
'
'Shelf_Car_Pic279
'
Me.Shelf_Car_Pic279.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic279.Location = New System.Drawing.Point(471, 658)
Me.Shelf_Car_Pic279.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic279.Name = "Shelf_Car_Pic279"
Me.Shelf_Car_Pic279.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic279.TabIndex = 312
Me.Shelf_Car_Pic279.Text = "6001"
Me.Shelf_Car_Pic279.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic279.Visible = false
'
'Shelf_Car_Pic278
'
Me.Shelf_Car_Pic278.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic278.Location = New System.Drawing.Point(471, 634)
Me.Shelf_Car_Pic278.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic278.Name = "Shelf_Car_Pic278"
Me.Shelf_Car_Pic278.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic278.TabIndex = 311
Me.Shelf_Car_Pic278.Text = "6001"
Me.Shelf_Car_Pic278.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic278.Visible = false
'
'Shelf_Car_Pic277
'
Me.Shelf_Car_Pic277.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic277.Location = New System.Drawing.Point(471, 613)
Me.Shelf_Car_Pic277.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic277.Name = "Shelf_Car_Pic277"
Me.Shelf_Car_Pic277.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic277.TabIndex = 310
Me.Shelf_Car_Pic277.Text = "6001"
Me.Shelf_Car_Pic277.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic277.Visible = false
'
'Shelf_Car_Pic276
'
Me.Shelf_Car_Pic276.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic276.Location = New System.Drawing.Point(471, 590)
Me.Shelf_Car_Pic276.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic276.Name = "Shelf_Car_Pic276"
Me.Shelf_Car_Pic276.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic276.TabIndex = 309
Me.Shelf_Car_Pic276.Text = "6001"
Me.Shelf_Car_Pic276.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic276.Visible = false
'
'Shelf_Car_Pic275
'
Me.Shelf_Car_Pic275.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic275.Location = New System.Drawing.Point(471, 562)
Me.Shelf_Car_Pic275.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic275.Name = "Shelf_Car_Pic275"
Me.Shelf_Car_Pic275.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic275.TabIndex = 308
Me.Shelf_Car_Pic275.Text = "6001"
Me.Shelf_Car_Pic275.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic275.Visible = false
'
'Shelf_Car_Pic274
'
Me.Shelf_Car_Pic274.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic274.Location = New System.Drawing.Point(471, 540)
Me.Shelf_Car_Pic274.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic274.Name = "Shelf_Car_Pic274"
Me.Shelf_Car_Pic274.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic274.TabIndex = 307
Me.Shelf_Car_Pic274.Text = "6001"
Me.Shelf_Car_Pic274.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic274.Visible = false
'
'Shelf_Car_Pic273
'
Me.Shelf_Car_Pic273.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic273.Location = New System.Drawing.Point(471, 518)
Me.Shelf_Car_Pic273.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic273.Name = "Shelf_Car_Pic273"
Me.Shelf_Car_Pic273.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic273.TabIndex = 306
Me.Shelf_Car_Pic273.Text = "6001"
Me.Shelf_Car_Pic273.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic273.Visible = false
'
'Shelf_Car_Pic272
'
Me.Shelf_Car_Pic272.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic272.Location = New System.Drawing.Point(471, 496)
Me.Shelf_Car_Pic272.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic272.Name = "Shelf_Car_Pic272"
Me.Shelf_Car_Pic272.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic272.TabIndex = 305
Me.Shelf_Car_Pic272.Text = "6001"
Me.Shelf_Car_Pic272.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic272.Visible = false
'
'Shelf_Car_Pic271
'
Me.Shelf_Car_Pic271.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic271.Location = New System.Drawing.Point(471, 474)
Me.Shelf_Car_Pic271.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic271.Name = "Shelf_Car_Pic271"
Me.Shelf_Car_Pic271.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic271.TabIndex = 304
Me.Shelf_Car_Pic271.Text = "6001"
Me.Shelf_Car_Pic271.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic271.Visible = false
'
'Shelf_Car_Pic270
'
Me.Shelf_Car_Pic270.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic270.Location = New System.Drawing.Point(471, 450)
Me.Shelf_Car_Pic270.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic270.Name = "Shelf_Car_Pic270"
Me.Shelf_Car_Pic270.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic270.TabIndex = 303
Me.Shelf_Car_Pic270.Text = "6001"
Me.Shelf_Car_Pic270.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic270.Visible = false
'
'Shelf_Car_Pic269
'
Me.Shelf_Car_Pic269.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic269.Location = New System.Drawing.Point(471, 428)
Me.Shelf_Car_Pic269.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic269.Name = "Shelf_Car_Pic269"
Me.Shelf_Car_Pic269.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic269.TabIndex = 302
Me.Shelf_Car_Pic269.Text = "6001"
Me.Shelf_Car_Pic269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic269.Visible = false
'
'Shelf_Car_Pic268
'
Me.Shelf_Car_Pic268.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic268.Location = New System.Drawing.Point(471, 406)
Me.Shelf_Car_Pic268.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic268.Name = "Shelf_Car_Pic268"
Me.Shelf_Car_Pic268.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic268.TabIndex = 301
Me.Shelf_Car_Pic268.Text = "6001"
Me.Shelf_Car_Pic268.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic268.Visible = false
'
'Shelf_Car_Pic267
'
Me.Shelf_Car_Pic267.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic267.Location = New System.Drawing.Point(471, 384)
Me.Shelf_Car_Pic267.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic267.Name = "Shelf_Car_Pic267"
Me.Shelf_Car_Pic267.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic267.TabIndex = 300
Me.Shelf_Car_Pic267.Text = "6001"
Me.Shelf_Car_Pic267.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic267.Visible = false
'
'Shelf_Car_Pic266
'
Me.Shelf_Car_Pic266.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic266.Location = New System.Drawing.Point(471, 361)
Me.Shelf_Car_Pic266.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic266.Name = "Shelf_Car_Pic266"
Me.Shelf_Car_Pic266.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic266.TabIndex = 299
Me.Shelf_Car_Pic266.Text = "6001"
Me.Shelf_Car_Pic266.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic266.Visible = false
'
'Shelf_Car_Pic265
'
Me.Shelf_Car_Pic265.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic265.Location = New System.Drawing.Point(471, 334)
Me.Shelf_Car_Pic265.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic265.Name = "Shelf_Car_Pic265"
Me.Shelf_Car_Pic265.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic265.TabIndex = 298
Me.Shelf_Car_Pic265.Text = "6001"
Me.Shelf_Car_Pic265.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic265.Visible = false
'
'Shelf_Car_Pic263
'
Me.Shelf_Car_Pic263.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic263.Location = New System.Drawing.Point(471, 310)
Me.Shelf_Car_Pic263.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic263.Name = "Shelf_Car_Pic263"
Me.Shelf_Car_Pic263.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic263.TabIndex = 297
Me.Shelf_Car_Pic263.Text = "6001"
Me.Shelf_Car_Pic263.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic263.Visible = false
'
'Shelf_Car_Pic264
'
Me.Shelf_Car_Pic264.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic264.Location = New System.Drawing.Point(471, 288)
Me.Shelf_Car_Pic264.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic264.Name = "Shelf_Car_Pic264"
Me.Shelf_Car_Pic264.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic264.TabIndex = 296
Me.Shelf_Car_Pic264.Text = "6001"
Me.Shelf_Car_Pic264.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic264.Visible = false
'
'Shelf_Car_Pic262
'
Me.Shelf_Car_Pic262.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic262.Location = New System.Drawing.Point(471, 266)
Me.Shelf_Car_Pic262.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic262.Name = "Shelf_Car_Pic262"
Me.Shelf_Car_Pic262.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic262.TabIndex = 295
Me.Shelf_Car_Pic262.Text = "6001"
Me.Shelf_Car_Pic262.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic262.Visible = false
'
'Shelf_Car_Pic261
'
Me.Shelf_Car_Pic261.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic261.Location = New System.Drawing.Point(471, 244)
Me.Shelf_Car_Pic261.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic261.Name = "Shelf_Car_Pic261"
Me.Shelf_Car_Pic261.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic261.TabIndex = 294
Me.Shelf_Car_Pic261.Text = "6001"
Me.Shelf_Car_Pic261.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic261.Visible = false
'
'Shelf_Car_Pic260
'
Me.Shelf_Car_Pic260.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic260.Location = New System.Drawing.Point(471, 215)
Me.Shelf_Car_Pic260.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic260.Name = "Shelf_Car_Pic260"
Me.Shelf_Car_Pic260.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic260.TabIndex = 293
Me.Shelf_Car_Pic260.Text = "6001"
Me.Shelf_Car_Pic260.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic260.Visible = false
'
'Shelf_Car_Pic259
'
Me.Shelf_Car_Pic259.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic259.Location = New System.Drawing.Point(471, 192)
Me.Shelf_Car_Pic259.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic259.Name = "Shelf_Car_Pic259"
Me.Shelf_Car_Pic259.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic259.TabIndex = 292
Me.Shelf_Car_Pic259.Text = "6001"
Me.Shelf_Car_Pic259.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic259.Visible = false
'
'Shelf_Car_Pic258
'
Me.Shelf_Car_Pic258.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic258.Location = New System.Drawing.Point(471, 170)
Me.Shelf_Car_Pic258.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic258.Name = "Shelf_Car_Pic258"
Me.Shelf_Car_Pic258.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic258.TabIndex = 291
Me.Shelf_Car_Pic258.Text = "6001"
Me.Shelf_Car_Pic258.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic258.Visible = false
'
'Shelf_Car_Pic257
'
Me.Shelf_Car_Pic257.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic257.Location = New System.Drawing.Point(471, 148)
Me.Shelf_Car_Pic257.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic257.Name = "Shelf_Car_Pic257"
Me.Shelf_Car_Pic257.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic257.TabIndex = 290
Me.Shelf_Car_Pic257.Text = "6001"
Me.Shelf_Car_Pic257.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic257.Visible = false
'
'Shelf_Car_Pic256
'
Me.Shelf_Car_Pic256.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic256.Location = New System.Drawing.Point(471, 126)
Me.Shelf_Car_Pic256.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic256.Name = "Shelf_Car_Pic256"
Me.Shelf_Car_Pic256.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic256.TabIndex = 289
Me.Shelf_Car_Pic256.Text = "6001"
Me.Shelf_Car_Pic256.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic256.Visible = false
'
'Shelf_Car_Pic255
'
Me.Shelf_Car_Pic255.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic255.Location = New System.Drawing.Point(471, 98)
Me.Shelf_Car_Pic255.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic255.Name = "Shelf_Car_Pic255"
Me.Shelf_Car_Pic255.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic255.TabIndex = 288
Me.Shelf_Car_Pic255.Text = "6001"
Me.Shelf_Car_Pic255.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic255.Visible = false
'
'Shelf_Car_Pic254
'
Me.Shelf_Car_Pic254.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic254.Location = New System.Drawing.Point(471, 73)
Me.Shelf_Car_Pic254.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic254.Name = "Shelf_Car_Pic254"
Me.Shelf_Car_Pic254.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic254.TabIndex = 287
Me.Shelf_Car_Pic254.Text = "6001"
Me.Shelf_Car_Pic254.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic254.Visible = false
'
'Shelf_Car_Pic253
'
Me.Shelf_Car_Pic253.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic253.Location = New System.Drawing.Point(471, 53)
Me.Shelf_Car_Pic253.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic253.Name = "Shelf_Car_Pic253"
Me.Shelf_Car_Pic253.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic253.TabIndex = 286
Me.Shelf_Car_Pic253.Text = "6001"
Me.Shelf_Car_Pic253.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic253.Visible = false
'
'Shelf_Car_Pic252
'
Me.Shelf_Car_Pic252.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic252.Location = New System.Drawing.Point(471, 32)
Me.Shelf_Car_Pic252.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic252.Name = "Shelf_Car_Pic252"
Me.Shelf_Car_Pic252.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic252.TabIndex = 285
Me.Shelf_Car_Pic252.Text = "6001"
Me.Shelf_Car_Pic252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic252.Visible = false
'
'Shelf_Car_Pic251
'
Me.Shelf_Car_Pic251.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic251.Location = New System.Drawing.Point(471, 10)
Me.Shelf_Car_Pic251.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic251.Name = "Shelf_Car_Pic251"
Me.Shelf_Car_Pic251.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic251.TabIndex = 284
Me.Shelf_Car_Pic251.Text = "6001"
Me.Shelf_Car_Pic251.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic251.Visible = false
'
'Shelf_Car_Pic250
'
Me.Shelf_Car_Pic250.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic250.Location = New System.Drawing.Point(427, 680)
Me.Shelf_Car_Pic250.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic250.Name = "Shelf_Car_Pic250"
Me.Shelf_Car_Pic250.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic250.TabIndex = 283
Me.Shelf_Car_Pic250.Text = "6001"
Me.Shelf_Car_Pic250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic250.Visible = false
'
'Shelf_Car_Pic249
'
Me.Shelf_Car_Pic249.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic249.Location = New System.Drawing.Point(427, 658)
Me.Shelf_Car_Pic249.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic249.Name = "Shelf_Car_Pic249"
Me.Shelf_Car_Pic249.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic249.TabIndex = 282
Me.Shelf_Car_Pic249.Text = "6001"
Me.Shelf_Car_Pic249.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic249.Visible = false
'
'Shelf_Car_Pic248
'
Me.Shelf_Car_Pic248.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic248.Location = New System.Drawing.Point(427, 634)
Me.Shelf_Car_Pic248.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic248.Name = "Shelf_Car_Pic248"
Me.Shelf_Car_Pic248.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic248.TabIndex = 281
Me.Shelf_Car_Pic248.Text = "6001"
Me.Shelf_Car_Pic248.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic248.Visible = false
'
'Shelf_Car_Pic247
'
Me.Shelf_Car_Pic247.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic247.Location = New System.Drawing.Point(427, 613)
Me.Shelf_Car_Pic247.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic247.Name = "Shelf_Car_Pic247"
Me.Shelf_Car_Pic247.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic247.TabIndex = 280
Me.Shelf_Car_Pic247.Text = "6001"
Me.Shelf_Car_Pic247.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic247.Visible = false
'
'Shelf_Car_Pic246
'
Me.Shelf_Car_Pic246.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic246.Location = New System.Drawing.Point(427, 590)
Me.Shelf_Car_Pic246.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic246.Name = "Shelf_Car_Pic246"
Me.Shelf_Car_Pic246.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic246.TabIndex = 279
Me.Shelf_Car_Pic246.Text = "6001"
Me.Shelf_Car_Pic246.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic246.Visible = false
'
'Shelf_Car_Pic245
'
Me.Shelf_Car_Pic245.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic245.Location = New System.Drawing.Point(427, 562)
Me.Shelf_Car_Pic245.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic245.Name = "Shelf_Car_Pic245"
Me.Shelf_Car_Pic245.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic245.TabIndex = 278
Me.Shelf_Car_Pic245.Text = "6001"
Me.Shelf_Car_Pic245.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic245.Visible = false
'
'Shelf_Car_Pic244
'
Me.Shelf_Car_Pic244.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic244.Location = New System.Drawing.Point(427, 540)
Me.Shelf_Car_Pic244.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic244.Name = "Shelf_Car_Pic244"
Me.Shelf_Car_Pic244.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic244.TabIndex = 277
Me.Shelf_Car_Pic244.Text = "6001"
Me.Shelf_Car_Pic244.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic244.Visible = false
'
'Shelf_Car_Pic243
'
Me.Shelf_Car_Pic243.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic243.Location = New System.Drawing.Point(427, 518)
Me.Shelf_Car_Pic243.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic243.Name = "Shelf_Car_Pic243"
Me.Shelf_Car_Pic243.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic243.TabIndex = 276
Me.Shelf_Car_Pic243.Text = "6001"
Me.Shelf_Car_Pic243.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic243.Visible = false
'
'Shelf_Car_Pic242
'
Me.Shelf_Car_Pic242.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic242.Location = New System.Drawing.Point(427, 496)
Me.Shelf_Car_Pic242.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic242.Name = "Shelf_Car_Pic242"
Me.Shelf_Car_Pic242.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic242.TabIndex = 275
Me.Shelf_Car_Pic242.Text = "6001"
Me.Shelf_Car_Pic242.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic242.Visible = false
'
'Shelf_Car_Pic241
'
Me.Shelf_Car_Pic241.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic241.Location = New System.Drawing.Point(427, 474)
Me.Shelf_Car_Pic241.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic241.Name = "Shelf_Car_Pic241"
Me.Shelf_Car_Pic241.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic241.TabIndex = 274
Me.Shelf_Car_Pic241.Text = "6001"
Me.Shelf_Car_Pic241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic241.Visible = false
'
'Shelf_Car_Pic240
'
Me.Shelf_Car_Pic240.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic240.Location = New System.Drawing.Point(427, 450)
Me.Shelf_Car_Pic240.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic240.Name = "Shelf_Car_Pic240"
Me.Shelf_Car_Pic240.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic240.TabIndex = 273
Me.Shelf_Car_Pic240.Text = "6001"
Me.Shelf_Car_Pic240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic240.Visible = false
'
'Shelf_Car_Pic239
'
Me.Shelf_Car_Pic239.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic239.Location = New System.Drawing.Point(427, 428)
Me.Shelf_Car_Pic239.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic239.Name = "Shelf_Car_Pic239"
Me.Shelf_Car_Pic239.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic239.TabIndex = 272
Me.Shelf_Car_Pic239.Text = "6001"
Me.Shelf_Car_Pic239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic239.Visible = false
'
'Shelf_Car_Pic238
'
Me.Shelf_Car_Pic238.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic238.Location = New System.Drawing.Point(427, 406)
Me.Shelf_Car_Pic238.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic238.Name = "Shelf_Car_Pic238"
Me.Shelf_Car_Pic238.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic238.TabIndex = 271
Me.Shelf_Car_Pic238.Text = "6001"
Me.Shelf_Car_Pic238.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic238.Visible = false
'
'Shelf_Car_Pic237
'
Me.Shelf_Car_Pic237.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic237.Location = New System.Drawing.Point(427, 384)
Me.Shelf_Car_Pic237.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic237.Name = "Shelf_Car_Pic237"
Me.Shelf_Car_Pic237.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic237.TabIndex = 270
Me.Shelf_Car_Pic237.Text = "6001"
Me.Shelf_Car_Pic237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic237.Visible = false
'
'Shelf_Car_Pic236
'
Me.Shelf_Car_Pic236.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic236.Location = New System.Drawing.Point(427, 361)
Me.Shelf_Car_Pic236.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic236.Name = "Shelf_Car_Pic236"
Me.Shelf_Car_Pic236.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic236.TabIndex = 269
Me.Shelf_Car_Pic236.Text = "6001"
Me.Shelf_Car_Pic236.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic236.Visible = false
'
'Shelf_Car_Pic235
'
Me.Shelf_Car_Pic235.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic235.Location = New System.Drawing.Point(427, 334)
Me.Shelf_Car_Pic235.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic235.Name = "Shelf_Car_Pic235"
Me.Shelf_Car_Pic235.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic235.TabIndex = 268
Me.Shelf_Car_Pic235.Text = "6001"
Me.Shelf_Car_Pic235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic235.Visible = false
'
'Shelf_Car_Pic234
'
Me.Shelf_Car_Pic234.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic234.Location = New System.Drawing.Point(427, 310)
Me.Shelf_Car_Pic234.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic234.Name = "Shelf_Car_Pic234"
Me.Shelf_Car_Pic234.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic234.TabIndex = 267
Me.Shelf_Car_Pic234.Text = "6001"
Me.Shelf_Car_Pic234.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic234.Visible = false
'
'Shelf_Car_Pic233
'
Me.Shelf_Car_Pic233.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic233.Location = New System.Drawing.Point(427, 288)
Me.Shelf_Car_Pic233.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic233.Name = "Shelf_Car_Pic233"
Me.Shelf_Car_Pic233.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic233.TabIndex = 266
Me.Shelf_Car_Pic233.Text = "6001"
Me.Shelf_Car_Pic233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic233.Visible = false
'
'Shelf_Car_Pic232
'
Me.Shelf_Car_Pic232.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic232.Location = New System.Drawing.Point(427, 266)
Me.Shelf_Car_Pic232.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic232.Name = "Shelf_Car_Pic232"
Me.Shelf_Car_Pic232.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic232.TabIndex = 265
Me.Shelf_Car_Pic232.Text = "6001"
Me.Shelf_Car_Pic232.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic232.Visible = false
'
'Shelf_Car_Pic231
'
Me.Shelf_Car_Pic231.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic231.Location = New System.Drawing.Point(427, 244)
Me.Shelf_Car_Pic231.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic231.Name = "Shelf_Car_Pic231"
Me.Shelf_Car_Pic231.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic231.TabIndex = 264
Me.Shelf_Car_Pic231.Text = "6001"
Me.Shelf_Car_Pic231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic231.Visible = false
'
'Shelf_Car_Pic230
'
Me.Shelf_Car_Pic230.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic230.Location = New System.Drawing.Point(427, 215)
Me.Shelf_Car_Pic230.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic230.Name = "Shelf_Car_Pic230"
Me.Shelf_Car_Pic230.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic230.TabIndex = 263
Me.Shelf_Car_Pic230.Text = "6001"
Me.Shelf_Car_Pic230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic230.Visible = false
'
'Shelf_Car_Pic229
'
Me.Shelf_Car_Pic229.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic229.Location = New System.Drawing.Point(427, 192)
Me.Shelf_Car_Pic229.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic229.Name = "Shelf_Car_Pic229"
Me.Shelf_Car_Pic229.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic229.TabIndex = 262
Me.Shelf_Car_Pic229.Text = "6001"
Me.Shelf_Car_Pic229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic229.Visible = false
'
'Shelf_Car_Pic228
'
Me.Shelf_Car_Pic228.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic228.Location = New System.Drawing.Point(427, 170)
Me.Shelf_Car_Pic228.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic228.Name = "Shelf_Car_Pic228"
Me.Shelf_Car_Pic228.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic228.TabIndex = 261
Me.Shelf_Car_Pic228.Text = "6001"
Me.Shelf_Car_Pic228.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic228.Visible = false
'
'Shelf_Car_Pic227
'
Me.Shelf_Car_Pic227.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic227.Location = New System.Drawing.Point(427, 148)
Me.Shelf_Car_Pic227.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic227.Name = "Shelf_Car_Pic227"
Me.Shelf_Car_Pic227.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic227.TabIndex = 260
Me.Shelf_Car_Pic227.Text = "6001"
Me.Shelf_Car_Pic227.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic227.Visible = false
'
'Shelf_Car_Pic226
'
Me.Shelf_Car_Pic226.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic226.Location = New System.Drawing.Point(427, 126)
Me.Shelf_Car_Pic226.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic226.Name = "Shelf_Car_Pic226"
Me.Shelf_Car_Pic226.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic226.TabIndex = 259
Me.Shelf_Car_Pic226.Text = "6001"
Me.Shelf_Car_Pic226.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic226.Visible = false
'
'Shelf_Car_Pic225
'
Me.Shelf_Car_Pic225.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic225.Location = New System.Drawing.Point(427, 98)
Me.Shelf_Car_Pic225.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic225.Name = "Shelf_Car_Pic225"
Me.Shelf_Car_Pic225.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic225.TabIndex = 258
Me.Shelf_Car_Pic225.Text = "6001"
Me.Shelf_Car_Pic225.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic225.Visible = false
'
'Shelf_Car_Pic224
'
Me.Shelf_Car_Pic224.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic224.Location = New System.Drawing.Point(427, 73)
Me.Shelf_Car_Pic224.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic224.Name = "Shelf_Car_Pic224"
Me.Shelf_Car_Pic224.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic224.TabIndex = 257
Me.Shelf_Car_Pic224.Text = "6001"
Me.Shelf_Car_Pic224.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic224.Visible = false
'
'Shelf_Car_Pic223
'
Me.Shelf_Car_Pic223.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic223.Location = New System.Drawing.Point(427, 53)
Me.Shelf_Car_Pic223.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic223.Name = "Shelf_Car_Pic223"
Me.Shelf_Car_Pic223.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic223.TabIndex = 256
Me.Shelf_Car_Pic223.Text = "6001"
Me.Shelf_Car_Pic223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic223.Visible = false
'
'Shelf_Car_Pic222
'
Me.Shelf_Car_Pic222.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic222.Location = New System.Drawing.Point(427, 32)
Me.Shelf_Car_Pic222.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic222.Name = "Shelf_Car_Pic222"
Me.Shelf_Car_Pic222.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic222.TabIndex = 255
Me.Shelf_Car_Pic222.Text = "6001"
Me.Shelf_Car_Pic222.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic222.Visible = false
'
'Shelf_Car_Pic221
'
Me.Shelf_Car_Pic221.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic221.Location = New System.Drawing.Point(427, 10)
Me.Shelf_Car_Pic221.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic221.Name = "Shelf_Car_Pic221"
Me.Shelf_Car_Pic221.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic221.TabIndex = 254
Me.Shelf_Car_Pic221.Text = "6001"
Me.Shelf_Car_Pic221.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic221.Visible = false
'
'Shelf_Car_Pic220
'
Me.Shelf_Car_Pic220.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic220.Location = New System.Drawing.Point(385, 680)
Me.Shelf_Car_Pic220.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic220.Name = "Shelf_Car_Pic220"
Me.Shelf_Car_Pic220.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic220.TabIndex = 253
Me.Shelf_Car_Pic220.Text = "6001"
Me.Shelf_Car_Pic220.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic220.Visible = false
'
'Shelf_Car_Pic219
'
Me.Shelf_Car_Pic219.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic219.Location = New System.Drawing.Point(385, 658)
Me.Shelf_Car_Pic219.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic219.Name = "Shelf_Car_Pic219"
Me.Shelf_Car_Pic219.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic219.TabIndex = 252
Me.Shelf_Car_Pic219.Text = "6001"
Me.Shelf_Car_Pic219.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic219.Visible = false
'
'Shelf_Car_Pic218
'
Me.Shelf_Car_Pic218.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic218.Location = New System.Drawing.Point(385, 634)
Me.Shelf_Car_Pic218.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic218.Name = "Shelf_Car_Pic218"
Me.Shelf_Car_Pic218.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic218.TabIndex = 251
Me.Shelf_Car_Pic218.Text = "6001"
Me.Shelf_Car_Pic218.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic218.Visible = false
'
'Shelf_Car_Pic217
'
Me.Shelf_Car_Pic217.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic217.Location = New System.Drawing.Point(385, 613)
Me.Shelf_Car_Pic217.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic217.Name = "Shelf_Car_Pic217"
Me.Shelf_Car_Pic217.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic217.TabIndex = 250
Me.Shelf_Car_Pic217.Text = "6001"
Me.Shelf_Car_Pic217.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic217.Visible = false
'
'Shelf_Car_Pic216
'
Me.Shelf_Car_Pic216.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic216.Location = New System.Drawing.Point(385, 590)
Me.Shelf_Car_Pic216.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic216.Name = "Shelf_Car_Pic216"
Me.Shelf_Car_Pic216.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic216.TabIndex = 249
Me.Shelf_Car_Pic216.Text = "6001"
Me.Shelf_Car_Pic216.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic216.Visible = false
'
'Shelf_Car_Pic215
'
Me.Shelf_Car_Pic215.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic215.Location = New System.Drawing.Point(385, 562)
Me.Shelf_Car_Pic215.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic215.Name = "Shelf_Car_Pic215"
Me.Shelf_Car_Pic215.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic215.TabIndex = 248
Me.Shelf_Car_Pic215.Text = "6001"
Me.Shelf_Car_Pic215.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic215.Visible = false
'
'Shelf_Car_Pic214
'
Me.Shelf_Car_Pic214.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic214.Location = New System.Drawing.Point(385, 540)
Me.Shelf_Car_Pic214.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic214.Name = "Shelf_Car_Pic214"
Me.Shelf_Car_Pic214.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic214.TabIndex = 247
Me.Shelf_Car_Pic214.Text = "6001"
Me.Shelf_Car_Pic214.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic214.Visible = false
'
'Shelf_Car_Pic213
'
Me.Shelf_Car_Pic213.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic213.Location = New System.Drawing.Point(385, 518)
Me.Shelf_Car_Pic213.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic213.Name = "Shelf_Car_Pic213"
Me.Shelf_Car_Pic213.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic213.TabIndex = 246
Me.Shelf_Car_Pic213.Text = "6001"
Me.Shelf_Car_Pic213.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic213.Visible = false
'
'Shelf_Car_Pic212
'
Me.Shelf_Car_Pic212.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic212.Location = New System.Drawing.Point(385, 496)
Me.Shelf_Car_Pic212.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic212.Name = "Shelf_Car_Pic212"
Me.Shelf_Car_Pic212.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic212.TabIndex = 245
Me.Shelf_Car_Pic212.Text = "6001"
Me.Shelf_Car_Pic212.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic212.Visible = false
'
'Shelf_Car_Pic211
'
Me.Shelf_Car_Pic211.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic211.Location = New System.Drawing.Point(385, 474)
Me.Shelf_Car_Pic211.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic211.Name = "Shelf_Car_Pic211"
Me.Shelf_Car_Pic211.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic211.TabIndex = 244
Me.Shelf_Car_Pic211.Text = "6001"
Me.Shelf_Car_Pic211.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic211.Visible = false
'
'Shelf_Car_Pic210
'
Me.Shelf_Car_Pic210.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic210.Location = New System.Drawing.Point(385, 450)
Me.Shelf_Car_Pic210.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic210.Name = "Shelf_Car_Pic210"
Me.Shelf_Car_Pic210.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic210.TabIndex = 243
Me.Shelf_Car_Pic210.Text = "6001"
Me.Shelf_Car_Pic210.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic210.Visible = false
'
'Shelf_Car_Pic209
'
Me.Shelf_Car_Pic209.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic209.Location = New System.Drawing.Point(385, 428)
Me.Shelf_Car_Pic209.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic209.Name = "Shelf_Car_Pic209"
Me.Shelf_Car_Pic209.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic209.TabIndex = 242
Me.Shelf_Car_Pic209.Text = "6001"
Me.Shelf_Car_Pic209.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic209.Visible = false
'
'Shelf_Car_Pic208
'
Me.Shelf_Car_Pic208.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic208.Location = New System.Drawing.Point(385, 406)
Me.Shelf_Car_Pic208.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic208.Name = "Shelf_Car_Pic208"
Me.Shelf_Car_Pic208.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic208.TabIndex = 241
Me.Shelf_Car_Pic208.Text = "6001"
Me.Shelf_Car_Pic208.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic208.Visible = false
'
'Shelf_Car_Pic207
'
Me.Shelf_Car_Pic207.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic207.Location = New System.Drawing.Point(385, 384)
Me.Shelf_Car_Pic207.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic207.Name = "Shelf_Car_Pic207"
Me.Shelf_Car_Pic207.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic207.TabIndex = 240
Me.Shelf_Car_Pic207.Text = "6001"
Me.Shelf_Car_Pic207.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic207.Visible = false
'
'Shelf_Car_Pic206
'
Me.Shelf_Car_Pic206.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic206.Location = New System.Drawing.Point(385, 361)
Me.Shelf_Car_Pic206.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic206.Name = "Shelf_Car_Pic206"
Me.Shelf_Car_Pic206.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic206.TabIndex = 239
Me.Shelf_Car_Pic206.Text = "6001"
Me.Shelf_Car_Pic206.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic206.Visible = false
'
'Shelf_Car_Pic205
'
Me.Shelf_Car_Pic205.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic205.Location = New System.Drawing.Point(385, 334)
Me.Shelf_Car_Pic205.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic205.Name = "Shelf_Car_Pic205"
Me.Shelf_Car_Pic205.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic205.TabIndex = 238
Me.Shelf_Car_Pic205.Text = "6001"
Me.Shelf_Car_Pic205.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic205.Visible = false
'
'Shelf_Car_Pic204
'
Me.Shelf_Car_Pic204.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic204.Location = New System.Drawing.Point(385, 310)
Me.Shelf_Car_Pic204.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic204.Name = "Shelf_Car_Pic204"
Me.Shelf_Car_Pic204.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic204.TabIndex = 237
Me.Shelf_Car_Pic204.Text = "6001"
Me.Shelf_Car_Pic204.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic204.Visible = false
'
'Shelf_Car_Pic203
'
Me.Shelf_Car_Pic203.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic203.Location = New System.Drawing.Point(385, 288)
Me.Shelf_Car_Pic203.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic203.Name = "Shelf_Car_Pic203"
Me.Shelf_Car_Pic203.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic203.TabIndex = 236
Me.Shelf_Car_Pic203.Text = "6001"
Me.Shelf_Car_Pic203.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic203.Visible = false
'
'Shelf_Car_Pic202
'
Me.Shelf_Car_Pic202.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic202.Location = New System.Drawing.Point(385, 266)
Me.Shelf_Car_Pic202.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic202.Name = "Shelf_Car_Pic202"
Me.Shelf_Car_Pic202.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic202.TabIndex = 235
Me.Shelf_Car_Pic202.Text = "6001"
Me.Shelf_Car_Pic202.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic202.Visible = false
'
'Shelf_Car_Pic201
'
Me.Shelf_Car_Pic201.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic201.Location = New System.Drawing.Point(385, 244)
Me.Shelf_Car_Pic201.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic201.Name = "Shelf_Car_Pic201"
Me.Shelf_Car_Pic201.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic201.TabIndex = 234
Me.Shelf_Car_Pic201.Text = "6001"
Me.Shelf_Car_Pic201.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic201.Visible = false
'
'Shelf_Car_Pic200
'
Me.Shelf_Car_Pic200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic200.Location = New System.Drawing.Point(385, 215)
Me.Shelf_Car_Pic200.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic200.Name = "Shelf_Car_Pic200"
Me.Shelf_Car_Pic200.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic200.TabIndex = 233
Me.Shelf_Car_Pic200.Text = "6001"
Me.Shelf_Car_Pic200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic200.Visible = false
'
'Shelf_Car_Pic199
'
Me.Shelf_Car_Pic199.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic199.Location = New System.Drawing.Point(385, 192)
Me.Shelf_Car_Pic199.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic199.Name = "Shelf_Car_Pic199"
Me.Shelf_Car_Pic199.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic199.TabIndex = 232
Me.Shelf_Car_Pic199.Text = "6001"
Me.Shelf_Car_Pic199.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic199.Visible = false
'
'Shelf_Car_Pic198
'
Me.Shelf_Car_Pic198.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic198.Location = New System.Drawing.Point(385, 170)
Me.Shelf_Car_Pic198.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic198.Name = "Shelf_Car_Pic198"
Me.Shelf_Car_Pic198.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic198.TabIndex = 231
Me.Shelf_Car_Pic198.Text = "6001"
Me.Shelf_Car_Pic198.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic198.Visible = false
'
'Shelf_Car_Pic197
'
Me.Shelf_Car_Pic197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic197.Location = New System.Drawing.Point(385, 148)
Me.Shelf_Car_Pic197.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic197.Name = "Shelf_Car_Pic197"
Me.Shelf_Car_Pic197.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic197.TabIndex = 230
Me.Shelf_Car_Pic197.Text = "6001"
Me.Shelf_Car_Pic197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic197.Visible = false
'
'Shelf_Car_Pic196
'
Me.Shelf_Car_Pic196.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic196.Location = New System.Drawing.Point(385, 126)
Me.Shelf_Car_Pic196.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic196.Name = "Shelf_Car_Pic196"
Me.Shelf_Car_Pic196.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic196.TabIndex = 229
Me.Shelf_Car_Pic196.Text = "6001"
Me.Shelf_Car_Pic196.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic196.Visible = false
'
'Shelf_Car_Pic195
'
Me.Shelf_Car_Pic195.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic195.Location = New System.Drawing.Point(385, 98)
Me.Shelf_Car_Pic195.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic195.Name = "Shelf_Car_Pic195"
Me.Shelf_Car_Pic195.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic195.TabIndex = 228
Me.Shelf_Car_Pic195.Text = "6001"
Me.Shelf_Car_Pic195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic195.Visible = false
'
'Shelf_Car_Pic194
'
Me.Shelf_Car_Pic194.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic194.Location = New System.Drawing.Point(385, 73)
Me.Shelf_Car_Pic194.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic194.Name = "Shelf_Car_Pic194"
Me.Shelf_Car_Pic194.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic194.TabIndex = 227
Me.Shelf_Car_Pic194.Text = "6001"
Me.Shelf_Car_Pic194.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic194.Visible = false
'
'Shelf_Car_Pic193
'
Me.Shelf_Car_Pic193.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic193.Location = New System.Drawing.Point(385, 53)
Me.Shelf_Car_Pic193.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic193.Name = "Shelf_Car_Pic193"
Me.Shelf_Car_Pic193.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic193.TabIndex = 226
Me.Shelf_Car_Pic193.Text = "6001"
Me.Shelf_Car_Pic193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic193.Visible = false
'
'Shelf_Car_Pic192
'
Me.Shelf_Car_Pic192.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic192.Location = New System.Drawing.Point(385, 32)
Me.Shelf_Car_Pic192.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic192.Name = "Shelf_Car_Pic192"
Me.Shelf_Car_Pic192.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic192.TabIndex = 225
Me.Shelf_Car_Pic192.Text = "6001"
Me.Shelf_Car_Pic192.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic192.Visible = false
'
'Shelf_Car_Pic191
'
Me.Shelf_Car_Pic191.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic191.Location = New System.Drawing.Point(385, 10)
Me.Shelf_Car_Pic191.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic191.Name = "Shelf_Car_Pic191"
Me.Shelf_Car_Pic191.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic191.TabIndex = 224
Me.Shelf_Car_Pic191.Text = "6001"
Me.Shelf_Car_Pic191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic191.Visible = false
'
'Shelf_Car_Pic190
'
Me.Shelf_Car_Pic190.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic190.Location = New System.Drawing.Point(338, 680)
Me.Shelf_Car_Pic190.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic190.Name = "Shelf_Car_Pic190"
Me.Shelf_Car_Pic190.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic190.TabIndex = 223
Me.Shelf_Car_Pic190.Text = "6001"
Me.Shelf_Car_Pic190.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic190.Visible = false
'
'Shelf_Car_Pic189
'
Me.Shelf_Car_Pic189.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic189.Location = New System.Drawing.Point(338, 658)
Me.Shelf_Car_Pic189.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic189.Name = "Shelf_Car_Pic189"
Me.Shelf_Car_Pic189.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic189.TabIndex = 222
Me.Shelf_Car_Pic189.Text = "6001"
Me.Shelf_Car_Pic189.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic189.Visible = false
'
'Shelf_Car_Pic188
'
Me.Shelf_Car_Pic188.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic188.Location = New System.Drawing.Point(338, 634)
Me.Shelf_Car_Pic188.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic188.Name = "Shelf_Car_Pic188"
Me.Shelf_Car_Pic188.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic188.TabIndex = 221
Me.Shelf_Car_Pic188.Text = "6001"
Me.Shelf_Car_Pic188.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic188.Visible = false
'
'Shelf_Car_Pic187
'
Me.Shelf_Car_Pic187.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic187.Location = New System.Drawing.Point(338, 613)
Me.Shelf_Car_Pic187.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic187.Name = "Shelf_Car_Pic187"
Me.Shelf_Car_Pic187.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic187.TabIndex = 220
Me.Shelf_Car_Pic187.Text = "6001"
Me.Shelf_Car_Pic187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic187.Visible = false
'
'Shelf_Car_Pic186
'
Me.Shelf_Car_Pic186.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic186.Location = New System.Drawing.Point(338, 590)
Me.Shelf_Car_Pic186.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic186.Name = "Shelf_Car_Pic186"
Me.Shelf_Car_Pic186.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic186.TabIndex = 219
Me.Shelf_Car_Pic186.Text = "6001"
Me.Shelf_Car_Pic186.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic186.Visible = false
'
'Shelf_Car_Pic185
'
Me.Shelf_Car_Pic185.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic185.Location = New System.Drawing.Point(338, 562)
Me.Shelf_Car_Pic185.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic185.Name = "Shelf_Car_Pic185"
Me.Shelf_Car_Pic185.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic185.TabIndex = 218
Me.Shelf_Car_Pic185.Text = "6001"
Me.Shelf_Car_Pic185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic185.Visible = false
'
'Shelf_Car_Pic184
'
Me.Shelf_Car_Pic184.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic184.Location = New System.Drawing.Point(338, 540)
Me.Shelf_Car_Pic184.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic184.Name = "Shelf_Car_Pic184"
Me.Shelf_Car_Pic184.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic184.TabIndex = 217
Me.Shelf_Car_Pic184.Text = "6001"
Me.Shelf_Car_Pic184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic184.Visible = false
'
'Shelf_Car_Pic183
'
Me.Shelf_Car_Pic183.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic183.Location = New System.Drawing.Point(338, 518)
Me.Shelf_Car_Pic183.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic183.Name = "Shelf_Car_Pic183"
Me.Shelf_Car_Pic183.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic183.TabIndex = 216
Me.Shelf_Car_Pic183.Text = "6001"
Me.Shelf_Car_Pic183.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic183.Visible = false
'
'Shelf_Car_Pic182
'
Me.Shelf_Car_Pic182.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic182.Location = New System.Drawing.Point(338, 496)
Me.Shelf_Car_Pic182.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic182.Name = "Shelf_Car_Pic182"
Me.Shelf_Car_Pic182.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic182.TabIndex = 215
Me.Shelf_Car_Pic182.Text = "6001"
Me.Shelf_Car_Pic182.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic182.Visible = false
'
'Shelf_Car_Pic181
'
Me.Shelf_Car_Pic181.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic181.Location = New System.Drawing.Point(338, 474)
Me.Shelf_Car_Pic181.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic181.Name = "Shelf_Car_Pic181"
Me.Shelf_Car_Pic181.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic181.TabIndex = 214
Me.Shelf_Car_Pic181.Text = "6001"
Me.Shelf_Car_Pic181.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic181.Visible = false
'
'Shelf_Car_Pic180
'
Me.Shelf_Car_Pic180.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic180.Location = New System.Drawing.Point(338, 450)
Me.Shelf_Car_Pic180.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic180.Name = "Shelf_Car_Pic180"
Me.Shelf_Car_Pic180.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic180.TabIndex = 213
Me.Shelf_Car_Pic180.Text = "6001"
Me.Shelf_Car_Pic180.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic180.Visible = false
'
'Shelf_Car_Pic179
'
Me.Shelf_Car_Pic179.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic179.Location = New System.Drawing.Point(338, 428)
Me.Shelf_Car_Pic179.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic179.Name = "Shelf_Car_Pic179"
Me.Shelf_Car_Pic179.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic179.TabIndex = 212
Me.Shelf_Car_Pic179.Text = "6001"
Me.Shelf_Car_Pic179.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic179.Visible = false
'
'Shelf_Car_Pic178
'
Me.Shelf_Car_Pic178.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic178.Location = New System.Drawing.Point(338, 406)
Me.Shelf_Car_Pic178.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic178.Name = "Shelf_Car_Pic178"
Me.Shelf_Car_Pic178.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic178.TabIndex = 211
Me.Shelf_Car_Pic178.Text = "6001"
Me.Shelf_Car_Pic178.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic178.Visible = false
'
'Shelf_Car_Pic177
'
Me.Shelf_Car_Pic177.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic177.Location = New System.Drawing.Point(338, 384)
Me.Shelf_Car_Pic177.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic177.Name = "Shelf_Car_Pic177"
Me.Shelf_Car_Pic177.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic177.TabIndex = 210
Me.Shelf_Car_Pic177.Text = "6001"
Me.Shelf_Car_Pic177.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic177.Visible = false
'
'Shelf_Car_Pic176
'
Me.Shelf_Car_Pic176.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic176.Location = New System.Drawing.Point(338, 361)
Me.Shelf_Car_Pic176.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic176.Name = "Shelf_Car_Pic176"
Me.Shelf_Car_Pic176.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic176.TabIndex = 209
Me.Shelf_Car_Pic176.Text = "6001"
Me.Shelf_Car_Pic176.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic176.Visible = false
'
'Shelf_Car_Pic175
'
Me.Shelf_Car_Pic175.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic175.Location = New System.Drawing.Point(338, 334)
Me.Shelf_Car_Pic175.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic175.Name = "Shelf_Car_Pic175"
Me.Shelf_Car_Pic175.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic175.TabIndex = 208
Me.Shelf_Car_Pic175.Text = "6001"
Me.Shelf_Car_Pic175.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic175.Visible = false
'
'Shelf_Car_Pic174
'
Me.Shelf_Car_Pic174.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic174.Location = New System.Drawing.Point(338, 310)
Me.Shelf_Car_Pic174.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic174.Name = "Shelf_Car_Pic174"
Me.Shelf_Car_Pic174.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic174.TabIndex = 207
Me.Shelf_Car_Pic174.Text = "6001"
Me.Shelf_Car_Pic174.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic174.Visible = false
'
'Shelf_Car_Pic173
'
Me.Shelf_Car_Pic173.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic173.Location = New System.Drawing.Point(338, 288)
Me.Shelf_Car_Pic173.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic173.Name = "Shelf_Car_Pic173"
Me.Shelf_Car_Pic173.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic173.TabIndex = 206
Me.Shelf_Car_Pic173.Text = "6001"
Me.Shelf_Car_Pic173.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic173.Visible = false
'
'Shelf_Car_Pic172
'
Me.Shelf_Car_Pic172.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic172.Location = New System.Drawing.Point(338, 266)
Me.Shelf_Car_Pic172.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic172.Name = "Shelf_Car_Pic172"
Me.Shelf_Car_Pic172.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic172.TabIndex = 205
Me.Shelf_Car_Pic172.Text = "6001"
Me.Shelf_Car_Pic172.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic172.Visible = false
'
'Shelf_Car_Pic171
'
Me.Shelf_Car_Pic171.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic171.Location = New System.Drawing.Point(338, 244)
Me.Shelf_Car_Pic171.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic171.Name = "Shelf_Car_Pic171"
Me.Shelf_Car_Pic171.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic171.TabIndex = 204
Me.Shelf_Car_Pic171.Text = "6001"
Me.Shelf_Car_Pic171.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic171.Visible = false
'
'Shelf_Car_Pic170
'
Me.Shelf_Car_Pic170.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic170.Location = New System.Drawing.Point(338, 215)
Me.Shelf_Car_Pic170.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic170.Name = "Shelf_Car_Pic170"
Me.Shelf_Car_Pic170.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic170.TabIndex = 203
Me.Shelf_Car_Pic170.Text = "6001"
Me.Shelf_Car_Pic170.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic170.Visible = false
'
'Shelf_Car_Pic169
'
Me.Shelf_Car_Pic169.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic169.Location = New System.Drawing.Point(338, 192)
Me.Shelf_Car_Pic169.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic169.Name = "Shelf_Car_Pic169"
Me.Shelf_Car_Pic169.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic169.TabIndex = 202
Me.Shelf_Car_Pic169.Text = "6001"
Me.Shelf_Car_Pic169.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic169.Visible = false
'
'Shelf_Car_Pic168
'
Me.Shelf_Car_Pic168.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic168.Location = New System.Drawing.Point(338, 170)
Me.Shelf_Car_Pic168.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic168.Name = "Shelf_Car_Pic168"
Me.Shelf_Car_Pic168.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic168.TabIndex = 201
Me.Shelf_Car_Pic168.Text = "6001"
Me.Shelf_Car_Pic168.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic168.Visible = false
'
'Shelf_Car_Pic167
'
Me.Shelf_Car_Pic167.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic167.Location = New System.Drawing.Point(338, 148)
Me.Shelf_Car_Pic167.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic167.Name = "Shelf_Car_Pic167"
Me.Shelf_Car_Pic167.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic167.TabIndex = 200
Me.Shelf_Car_Pic167.Text = "6001"
Me.Shelf_Car_Pic167.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic167.Visible = false
'
'Shelf_Car_Pic166
'
Me.Shelf_Car_Pic166.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic166.Location = New System.Drawing.Point(338, 126)
Me.Shelf_Car_Pic166.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic166.Name = "Shelf_Car_Pic166"
Me.Shelf_Car_Pic166.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic166.TabIndex = 199
Me.Shelf_Car_Pic166.Text = "6001"
Me.Shelf_Car_Pic166.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic166.Visible = false
'
'Shelf_Car_Pic165
'
Me.Shelf_Car_Pic165.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic165.Location = New System.Drawing.Point(338, 98)
Me.Shelf_Car_Pic165.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic165.Name = "Shelf_Car_Pic165"
Me.Shelf_Car_Pic165.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic165.TabIndex = 198
Me.Shelf_Car_Pic165.Text = "6001"
Me.Shelf_Car_Pic165.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic165.Visible = false
'
'Shelf_Car_Pic164
'
Me.Shelf_Car_Pic164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic164.Location = New System.Drawing.Point(338, 73)
Me.Shelf_Car_Pic164.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic164.Name = "Shelf_Car_Pic164"
Me.Shelf_Car_Pic164.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic164.TabIndex = 197
Me.Shelf_Car_Pic164.Text = "6001"
Me.Shelf_Car_Pic164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic164.Visible = false
'
'Shelf_Car_Pic163
'
Me.Shelf_Car_Pic163.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic163.Location = New System.Drawing.Point(338, 53)
Me.Shelf_Car_Pic163.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic163.Name = "Shelf_Car_Pic163"
Me.Shelf_Car_Pic163.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic163.TabIndex = 196
Me.Shelf_Car_Pic163.Text = "6001"
Me.Shelf_Car_Pic163.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic163.Visible = false
'
'Shelf_Car_Pic162
'
Me.Shelf_Car_Pic162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic162.Location = New System.Drawing.Point(338, 32)
Me.Shelf_Car_Pic162.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic162.Name = "Shelf_Car_Pic162"
Me.Shelf_Car_Pic162.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic162.TabIndex = 195
Me.Shelf_Car_Pic162.Text = "6001"
Me.Shelf_Car_Pic162.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic162.Visible = false
'
'Shelf_Car_Pic161
'
Me.Shelf_Car_Pic161.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic161.Location = New System.Drawing.Point(338, 10)
Me.Shelf_Car_Pic161.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic161.Name = "Shelf_Car_Pic161"
Me.Shelf_Car_Pic161.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic161.TabIndex = 194
Me.Shelf_Car_Pic161.Text = "6001"
Me.Shelf_Car_Pic161.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic161.Visible = false
'
'Shelf_Car_Pic160
'
Me.Shelf_Car_Pic160.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic160.Location = New System.Drawing.Point(294, 678)
Me.Shelf_Car_Pic160.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic160.Name = "Shelf_Car_Pic160"
Me.Shelf_Car_Pic160.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic160.TabIndex = 193
Me.Shelf_Car_Pic160.Text = "6001"
Me.Shelf_Car_Pic160.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic160.Visible = false
'
'Shelf_Car_Pic159
'
Me.Shelf_Car_Pic159.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic159.Location = New System.Drawing.Point(294, 656)
Me.Shelf_Car_Pic159.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic159.Name = "Shelf_Car_Pic159"
Me.Shelf_Car_Pic159.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic159.TabIndex = 192
Me.Shelf_Car_Pic159.Text = "6001"
Me.Shelf_Car_Pic159.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic159.Visible = false
'
'Shelf_Car_Pic158
'
Me.Shelf_Car_Pic158.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic158.Location = New System.Drawing.Point(294, 634)
Me.Shelf_Car_Pic158.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic158.Name = "Shelf_Car_Pic158"
Me.Shelf_Car_Pic158.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic158.TabIndex = 191
Me.Shelf_Car_Pic158.Text = "6001"
Me.Shelf_Car_Pic158.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic158.Visible = false
'
'Shelf_Car_Pic157
'
Me.Shelf_Car_Pic157.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic157.Location = New System.Drawing.Point(294, 612)
Me.Shelf_Car_Pic157.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic157.Name = "Shelf_Car_Pic157"
Me.Shelf_Car_Pic157.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic157.TabIndex = 190
Me.Shelf_Car_Pic157.Text = "6001"
Me.Shelf_Car_Pic157.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic157.Visible = false
'
'Shelf_Car_Pic156
'
Me.Shelf_Car_Pic156.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic156.Location = New System.Drawing.Point(294, 590)
Me.Shelf_Car_Pic156.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic156.Name = "Shelf_Car_Pic156"
Me.Shelf_Car_Pic156.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic156.TabIndex = 189
Me.Shelf_Car_Pic156.Text = "6001"
Me.Shelf_Car_Pic156.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic156.Visible = false
'
'Shelf_Car_Pic155
'
Me.Shelf_Car_Pic155.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic155.Location = New System.Drawing.Point(294, 562)
Me.Shelf_Car_Pic155.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic155.Name = "Shelf_Car_Pic155"
Me.Shelf_Car_Pic155.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic155.TabIndex = 188
Me.Shelf_Car_Pic155.Text = "6001"
Me.Shelf_Car_Pic155.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic155.Visible = false
'
'Shelf_Car_Pic154
'
Me.Shelf_Car_Pic154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic154.Location = New System.Drawing.Point(294, 539)
Me.Shelf_Car_Pic154.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic154.Name = "Shelf_Car_Pic154"
Me.Shelf_Car_Pic154.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic154.TabIndex = 187
Me.Shelf_Car_Pic154.Text = "6001"
Me.Shelf_Car_Pic154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic154.Visible = false
'
'Shelf_Car_Pic153
'
Me.Shelf_Car_Pic153.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic153.Location = New System.Drawing.Point(294, 516)
Me.Shelf_Car_Pic153.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic153.Name = "Shelf_Car_Pic153"
Me.Shelf_Car_Pic153.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic153.TabIndex = 186
Me.Shelf_Car_Pic153.Text = "6001"
Me.Shelf_Car_Pic153.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic153.Visible = false
'
'Shelf_Car_Pic152
'
Me.Shelf_Car_Pic152.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic152.Location = New System.Drawing.Point(294, 494)
Me.Shelf_Car_Pic152.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic152.Name = "Shelf_Car_Pic152"
Me.Shelf_Car_Pic152.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic152.TabIndex = 185
Me.Shelf_Car_Pic152.Text = "6001"
Me.Shelf_Car_Pic152.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic152.Visible = false
'
'Shelf_Car_Pic151
'
Me.Shelf_Car_Pic151.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic151.Location = New System.Drawing.Point(294, 472)
Me.Shelf_Car_Pic151.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic151.Name = "Shelf_Car_Pic151"
Me.Shelf_Car_Pic151.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic151.TabIndex = 184
Me.Shelf_Car_Pic151.Text = "6001"
Me.Shelf_Car_Pic151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic151.Visible = false
'
'Shelf_Car_Pic150
'
Me.Shelf_Car_Pic150.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic150.Location = New System.Drawing.Point(294, 450)
Me.Shelf_Car_Pic150.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic150.Name = "Shelf_Car_Pic150"
Me.Shelf_Car_Pic150.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic150.TabIndex = 183
Me.Shelf_Car_Pic150.Text = "6001"
Me.Shelf_Car_Pic150.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic150.Visible = false
'
'Shelf_Car_Pic149
'
Me.Shelf_Car_Pic149.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic149.Location = New System.Drawing.Point(294, 428)
Me.Shelf_Car_Pic149.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic149.Name = "Shelf_Car_Pic149"
Me.Shelf_Car_Pic149.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic149.TabIndex = 182
Me.Shelf_Car_Pic149.Text = "6001"
Me.Shelf_Car_Pic149.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic149.Visible = false
'
'Shelf_Car_Pic148
'
Me.Shelf_Car_Pic148.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic148.Location = New System.Drawing.Point(294, 406)
Me.Shelf_Car_Pic148.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic148.Name = "Shelf_Car_Pic148"
Me.Shelf_Car_Pic148.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic148.TabIndex = 181
Me.Shelf_Car_Pic148.Text = "6001"
Me.Shelf_Car_Pic148.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic148.Visible = false
'
'Shelf_Car_Pic147
'
Me.Shelf_Car_Pic147.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic147.Location = New System.Drawing.Point(294, 384)
Me.Shelf_Car_Pic147.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic147.Name = "Shelf_Car_Pic147"
Me.Shelf_Car_Pic147.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic147.TabIndex = 180
Me.Shelf_Car_Pic147.Text = "6001"
Me.Shelf_Car_Pic147.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic147.Visible = false
'
'Shelf_Car_Pic146
'
Me.Shelf_Car_Pic146.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic146.Location = New System.Drawing.Point(294, 361)
Me.Shelf_Car_Pic146.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic146.Name = "Shelf_Car_Pic146"
Me.Shelf_Car_Pic146.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic146.TabIndex = 179
Me.Shelf_Car_Pic146.Text = "6001"
Me.Shelf_Car_Pic146.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic146.Visible = false
'
'Shelf_Car_Pic145
'
Me.Shelf_Car_Pic145.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic145.Location = New System.Drawing.Point(294, 334)
Me.Shelf_Car_Pic145.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic145.Name = "Shelf_Car_Pic145"
Me.Shelf_Car_Pic145.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic145.TabIndex = 178
Me.Shelf_Car_Pic145.Text = "6001"
Me.Shelf_Car_Pic145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic145.Visible = false
'
'Shelf_Car_Pic144
'
Me.Shelf_Car_Pic144.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic144.Location = New System.Drawing.Point(294, 310)
Me.Shelf_Car_Pic144.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic144.Name = "Shelf_Car_Pic144"
Me.Shelf_Car_Pic144.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic144.TabIndex = 177
Me.Shelf_Car_Pic144.Text = "6001"
Me.Shelf_Car_Pic144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic144.Visible = false
'
'Shelf_Car_Pic143
'
Me.Shelf_Car_Pic143.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic143.Location = New System.Drawing.Point(294, 288)
Me.Shelf_Car_Pic143.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic143.Name = "Shelf_Car_Pic143"
Me.Shelf_Car_Pic143.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic143.TabIndex = 176
Me.Shelf_Car_Pic143.Text = "6001"
Me.Shelf_Car_Pic143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic143.Visible = false
'
'Shelf_Car_Pic142
'
Me.Shelf_Car_Pic142.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic142.Location = New System.Drawing.Point(294, 266)
Me.Shelf_Car_Pic142.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic142.Name = "Shelf_Car_Pic142"
Me.Shelf_Car_Pic142.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic142.TabIndex = 175
Me.Shelf_Car_Pic142.Text = "6001"
Me.Shelf_Car_Pic142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic142.Visible = false
'
'Shelf_Car_Pic141
'
Me.Shelf_Car_Pic141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic141.Location = New System.Drawing.Point(294, 244)
Me.Shelf_Car_Pic141.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic141.Name = "Shelf_Car_Pic141"
Me.Shelf_Car_Pic141.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic141.TabIndex = 174
Me.Shelf_Car_Pic141.Text = "6001"
Me.Shelf_Car_Pic141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic141.Visible = false
'
'Shelf_Car_Pic140
'
Me.Shelf_Car_Pic140.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic140.Location = New System.Drawing.Point(294, 215)
Me.Shelf_Car_Pic140.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic140.Name = "Shelf_Car_Pic140"
Me.Shelf_Car_Pic140.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic140.TabIndex = 173
Me.Shelf_Car_Pic140.Text = "6001"
Me.Shelf_Car_Pic140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic140.Visible = false
'
'Shelf_Car_Pic139
'
Me.Shelf_Car_Pic139.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic139.Location = New System.Drawing.Point(294, 192)
Me.Shelf_Car_Pic139.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic139.Name = "Shelf_Car_Pic139"
Me.Shelf_Car_Pic139.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic139.TabIndex = 172
Me.Shelf_Car_Pic139.Text = "6001"
Me.Shelf_Car_Pic139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic139.Visible = false
'
'Shelf_Car_Pic138
'
Me.Shelf_Car_Pic138.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic138.Location = New System.Drawing.Point(294, 170)
Me.Shelf_Car_Pic138.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic138.Name = "Shelf_Car_Pic138"
Me.Shelf_Car_Pic138.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic138.TabIndex = 171
Me.Shelf_Car_Pic138.Text = "6001"
Me.Shelf_Car_Pic138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic138.Visible = false
'
'Shelf_Car_Pic137
'
Me.Shelf_Car_Pic137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic137.Location = New System.Drawing.Point(294, 148)
Me.Shelf_Car_Pic137.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic137.Name = "Shelf_Car_Pic137"
Me.Shelf_Car_Pic137.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic137.TabIndex = 170
Me.Shelf_Car_Pic137.Text = "6001"
Me.Shelf_Car_Pic137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic137.Visible = false
'
'Shelf_Car_Pic136
'
Me.Shelf_Car_Pic136.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic136.Location = New System.Drawing.Point(294, 126)
Me.Shelf_Car_Pic136.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic136.Name = "Shelf_Car_Pic136"
Me.Shelf_Car_Pic136.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic136.TabIndex = 169
Me.Shelf_Car_Pic136.Text = "6001"
Me.Shelf_Car_Pic136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic136.Visible = false
'
'Shelf_Car_Pic135
'
Me.Shelf_Car_Pic135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic135.Location = New System.Drawing.Point(294, 98)
Me.Shelf_Car_Pic135.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic135.Name = "Shelf_Car_Pic135"
Me.Shelf_Car_Pic135.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic135.TabIndex = 168
Me.Shelf_Car_Pic135.Text = "6001"
Me.Shelf_Car_Pic135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic135.Visible = false
'
'Shelf_Car_Pic134
'
Me.Shelf_Car_Pic134.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic134.Location = New System.Drawing.Point(294, 73)
Me.Shelf_Car_Pic134.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic134.Name = "Shelf_Car_Pic134"
Me.Shelf_Car_Pic134.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic134.TabIndex = 167
Me.Shelf_Car_Pic134.Text = "6001"
Me.Shelf_Car_Pic134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic134.Visible = false
'
'Shelf_Car_Pic133
'
Me.Shelf_Car_Pic133.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic133.Location = New System.Drawing.Point(294, 53)
Me.Shelf_Car_Pic133.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic133.Name = "Shelf_Car_Pic133"
Me.Shelf_Car_Pic133.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic133.TabIndex = 166
Me.Shelf_Car_Pic133.Text = "6001"
Me.Shelf_Car_Pic133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic133.Visible = false
'
'Shelf_Car_Pic132
'
Me.Shelf_Car_Pic132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic132.Location = New System.Drawing.Point(294, 32)
Me.Shelf_Car_Pic132.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic132.Name = "Shelf_Car_Pic132"
Me.Shelf_Car_Pic132.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic132.TabIndex = 165
Me.Shelf_Car_Pic132.Text = "6001"
Me.Shelf_Car_Pic132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic132.Visible = false
'
'Shelf_Car_Pic131
'
Me.Shelf_Car_Pic131.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic131.Location = New System.Drawing.Point(294, 10)
Me.Shelf_Car_Pic131.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic131.Name = "Shelf_Car_Pic131"
Me.Shelf_Car_Pic131.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic131.TabIndex = 164
Me.Shelf_Car_Pic131.Text = "6001"
Me.Shelf_Car_Pic131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic131.Visible = false
'
'Shelf_Car_Pic130
'
Me.Shelf_Car_Pic130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic130.Location = New System.Drawing.Point(252, 696)
Me.Shelf_Car_Pic130.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic130.Name = "Shelf_Car_Pic130"
Me.Shelf_Car_Pic130.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic130.TabIndex = 163
Me.Shelf_Car_Pic130.Text = "6001"
Me.Shelf_Car_Pic130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic130.Visible = false
'
'Shelf_Car_Pic129
'
Me.Shelf_Car_Pic129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic129.Location = New System.Drawing.Point(252, 674)
Me.Shelf_Car_Pic129.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic129.Name = "Shelf_Car_Pic129"
Me.Shelf_Car_Pic129.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic129.TabIndex = 162
Me.Shelf_Car_Pic129.Text = "6001"
Me.Shelf_Car_Pic129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic129.Visible = false
'
'Shelf_Car_Pic128
'
Me.Shelf_Car_Pic128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic128.Location = New System.Drawing.Point(252, 649)
Me.Shelf_Car_Pic128.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic128.Name = "Shelf_Car_Pic128"
Me.Shelf_Car_Pic128.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic128.TabIndex = 161
Me.Shelf_Car_Pic128.Text = "6001"
Me.Shelf_Car_Pic128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic128.Visible = false
'
'Shelf_Car_Pic127
'
Me.Shelf_Car_Pic127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic127.Location = New System.Drawing.Point(252, 630)
Me.Shelf_Car_Pic127.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic127.Name = "Shelf_Car_Pic127"
Me.Shelf_Car_Pic127.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic127.TabIndex = 160
Me.Shelf_Car_Pic127.Text = "6001"
Me.Shelf_Car_Pic127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic127.Visible = false
'
'Shelf_Car_Pic126
'
Me.Shelf_Car_Pic126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic126.Location = New System.Drawing.Point(252, 608)
Me.Shelf_Car_Pic126.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic126.Name = "Shelf_Car_Pic126"
Me.Shelf_Car_Pic126.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic126.TabIndex = 159
Me.Shelf_Car_Pic126.Text = "6001"
Me.Shelf_Car_Pic126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic126.Visible = false
'
'Shelf_Car_Pic125
'
Me.Shelf_Car_Pic125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic125.Location = New System.Drawing.Point(252, 577)
Me.Shelf_Car_Pic125.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic125.Name = "Shelf_Car_Pic125"
Me.Shelf_Car_Pic125.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic125.TabIndex = 158
Me.Shelf_Car_Pic125.Text = "6001"
Me.Shelf_Car_Pic125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic125.Visible = false
'
'Shelf_Car_Pic124
'
Me.Shelf_Car_Pic124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic124.Location = New System.Drawing.Point(252, 557)
Me.Shelf_Car_Pic124.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic124.Name = "Shelf_Car_Pic124"
Me.Shelf_Car_Pic124.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic124.TabIndex = 157
Me.Shelf_Car_Pic124.Text = "6001"
Me.Shelf_Car_Pic124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic124.Visible = false
'
'Shelf_Car_Pic123
'
Me.Shelf_Car_Pic123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic123.Location = New System.Drawing.Point(252, 534)
Me.Shelf_Car_Pic123.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic123.Name = "Shelf_Car_Pic123"
Me.Shelf_Car_Pic123.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic123.TabIndex = 156
Me.Shelf_Car_Pic123.Text = "6001"
Me.Shelf_Car_Pic123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic123.Visible = false
'
'Shelf_Car_Pic122
'
Me.Shelf_Car_Pic122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic122.Location = New System.Drawing.Point(252, 514)
Me.Shelf_Car_Pic122.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic122.Name = "Shelf_Car_Pic122"
Me.Shelf_Car_Pic122.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic122.TabIndex = 155
Me.Shelf_Car_Pic122.Text = "6001"
Me.Shelf_Car_Pic122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic122.Visible = false
'
'Shelf_Car_Pic121
'
Me.Shelf_Car_Pic121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic121.Location = New System.Drawing.Point(252, 490)
Me.Shelf_Car_Pic121.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic121.Name = "Shelf_Car_Pic121"
Me.Shelf_Car_Pic121.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic121.TabIndex = 154
Me.Shelf_Car_Pic121.Text = "6001"
Me.Shelf_Car_Pic121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic121.Visible = false
'
'Shelf_Car_Pic120
'
Me.Shelf_Car_Pic120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic120.Location = New System.Drawing.Point(252, 468)
Me.Shelf_Car_Pic120.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic120.Name = "Shelf_Car_Pic120"
Me.Shelf_Car_Pic120.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic120.TabIndex = 153
Me.Shelf_Car_Pic120.Text = "6001"
Me.Shelf_Car_Pic120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic120.Visible = false
'
'Shelf_Car_Pic119
'
Me.Shelf_Car_Pic119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic119.Location = New System.Drawing.Point(252, 446)
Me.Shelf_Car_Pic119.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic119.Name = "Shelf_Car_Pic119"
Me.Shelf_Car_Pic119.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic119.TabIndex = 152
Me.Shelf_Car_Pic119.Text = "6001"
Me.Shelf_Car_Pic119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic119.Visible = false
'
'Shelf_Car_Pic118
'
Me.Shelf_Car_Pic118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic118.Location = New System.Drawing.Point(252, 422)
Me.Shelf_Car_Pic118.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic118.Name = "Shelf_Car_Pic118"
Me.Shelf_Car_Pic118.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic118.TabIndex = 151
Me.Shelf_Car_Pic118.Text = "6001"
Me.Shelf_Car_Pic118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic118.Visible = false
'
'Shelf_Car_Pic117
'
Me.Shelf_Car_Pic117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic117.Location = New System.Drawing.Point(252, 402)
Me.Shelf_Car_Pic117.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic117.Name = "Shelf_Car_Pic117"
Me.Shelf_Car_Pic117.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic117.TabIndex = 150
Me.Shelf_Car_Pic117.Text = "6001"
Me.Shelf_Car_Pic117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic117.Visible = false
'
'Shelf_Car_Pic116
'
Me.Shelf_Car_Pic116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic116.Location = New System.Drawing.Point(252, 379)
Me.Shelf_Car_Pic116.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic116.Name = "Shelf_Car_Pic116"
Me.Shelf_Car_Pic116.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic116.TabIndex = 149
Me.Shelf_Car_Pic116.Text = "6001"
Me.Shelf_Car_Pic116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic116.Visible = false
'
'Shelf_Car_Pic115
'
Me.Shelf_Car_Pic115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic115.Location = New System.Drawing.Point(252, 350)
Me.Shelf_Car_Pic115.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic115.Name = "Shelf_Car_Pic115"
Me.Shelf_Car_Pic115.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic115.TabIndex = 148
Me.Shelf_Car_Pic115.Text = "6001"
Me.Shelf_Car_Pic115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic115.Visible = false
'
'Shelf_Car_Pic114
'
Me.Shelf_Car_Pic114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic114.Location = New System.Drawing.Point(252, 328)
Me.Shelf_Car_Pic114.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic114.Name = "Shelf_Car_Pic114"
Me.Shelf_Car_Pic114.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic114.TabIndex = 147
Me.Shelf_Car_Pic114.Text = "6001"
Me.Shelf_Car_Pic114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic114.Visible = false
'
'Shelf_Car_Pic113
'
Me.Shelf_Car_Pic113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic113.Location = New System.Drawing.Point(252, 306)
Me.Shelf_Car_Pic113.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic113.Name = "Shelf_Car_Pic113"
Me.Shelf_Car_Pic113.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic113.TabIndex = 146
Me.Shelf_Car_Pic113.Text = "6001"
Me.Shelf_Car_Pic113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic113.Visible = false
'
'Shelf_Car_Pic112
'
Me.Shelf_Car_Pic112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic112.Location = New System.Drawing.Point(252, 287)
Me.Shelf_Car_Pic112.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic112.Name = "Shelf_Car_Pic112"
Me.Shelf_Car_Pic112.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic112.TabIndex = 145
Me.Shelf_Car_Pic112.Text = "6001"
Me.Shelf_Car_Pic112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic112.Visible = false
'
'Shelf_Car_Pic111
'
Me.Shelf_Car_Pic111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic111.Location = New System.Drawing.Point(252, 262)
Me.Shelf_Car_Pic111.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic111.Name = "Shelf_Car_Pic111"
Me.Shelf_Car_Pic111.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic111.TabIndex = 144
Me.Shelf_Car_Pic111.Text = "6001"
Me.Shelf_Car_Pic111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic111.Visible = false
'
'Shelf_Car_Pic110
'
Me.Shelf_Car_Pic110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic110.Location = New System.Drawing.Point(252, 233)
Me.Shelf_Car_Pic110.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic110.Name = "Shelf_Car_Pic110"
Me.Shelf_Car_Pic110.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic110.TabIndex = 143
Me.Shelf_Car_Pic110.Text = "6001"
Me.Shelf_Car_Pic110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic110.Visible = false
'
'Shelf_Car_Pic109
'
Me.Shelf_Car_Pic109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic109.Location = New System.Drawing.Point(252, 210)
Me.Shelf_Car_Pic109.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic109.Name = "Shelf_Car_Pic109"
Me.Shelf_Car_Pic109.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic109.TabIndex = 142
Me.Shelf_Car_Pic109.Text = "6001"
Me.Shelf_Car_Pic109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic109.Visible = false
'
'Shelf_Car_Pic108
'
Me.Shelf_Car_Pic108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic108.Location = New System.Drawing.Point(252, 188)
Me.Shelf_Car_Pic108.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic108.Name = "Shelf_Car_Pic108"
Me.Shelf_Car_Pic108.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic108.TabIndex = 141
Me.Shelf_Car_Pic108.Text = "6001"
Me.Shelf_Car_Pic108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic108.Visible = false
'
'Shelf_Car_Pic107
'
Me.Shelf_Car_Pic107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic107.Location = New System.Drawing.Point(252, 166)
Me.Shelf_Car_Pic107.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic107.Name = "Shelf_Car_Pic107"
Me.Shelf_Car_Pic107.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic107.TabIndex = 140
Me.Shelf_Car_Pic107.Text = "6001"
Me.Shelf_Car_Pic107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic107.Visible = false
'
'Shelf_Car_Pic106
'
Me.Shelf_Car_Pic106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic106.Location = New System.Drawing.Point(252, 144)
Me.Shelf_Car_Pic106.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic106.Name = "Shelf_Car_Pic106"
Me.Shelf_Car_Pic106.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic106.TabIndex = 139
Me.Shelf_Car_Pic106.Text = "6001"
Me.Shelf_Car_Pic106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic106.Visible = false
'
'Shelf_Car_Pic105
'
Me.Shelf_Car_Pic105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic105.Location = New System.Drawing.Point(252, 116)
Me.Shelf_Car_Pic105.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic105.Name = "Shelf_Car_Pic105"
Me.Shelf_Car_Pic105.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic105.TabIndex = 138
Me.Shelf_Car_Pic105.Text = "6001"
Me.Shelf_Car_Pic105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic105.Visible = false
'
'Shelf_Car_Pic104
'
Me.Shelf_Car_Pic104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic104.Location = New System.Drawing.Point(252, 94)
Me.Shelf_Car_Pic104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic104.Name = "Shelf_Car_Pic104"
Me.Shelf_Car_Pic104.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic104.TabIndex = 137
Me.Shelf_Car_Pic104.Text = "6001"
Me.Shelf_Car_Pic104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic104.Visible = false
'
'Shelf_Car_Pic103
'
Me.Shelf_Car_Pic103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic103.Location = New System.Drawing.Point(252, 71)
Me.Shelf_Car_Pic103.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic103.Name = "Shelf_Car_Pic103"
Me.Shelf_Car_Pic103.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic103.TabIndex = 136
Me.Shelf_Car_Pic103.Text = "6001"
Me.Shelf_Car_Pic103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic103.Visible = false
'
'Shelf_Car_Pic102
'
Me.Shelf_Car_Pic102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic102.Location = New System.Drawing.Point(252, 50)
Me.Shelf_Car_Pic102.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic102.Name = "Shelf_Car_Pic102"
Me.Shelf_Car_Pic102.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic102.TabIndex = 135
Me.Shelf_Car_Pic102.Text = "6001"
Me.Shelf_Car_Pic102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic102.Visible = false
'
'Shelf_Car_Pic101
'
Me.Shelf_Car_Pic101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic101.Location = New System.Drawing.Point(252, 26)
Me.Shelf_Car_Pic101.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic101.Name = "Shelf_Car_Pic101"
Me.Shelf_Car_Pic101.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic101.TabIndex = 134
Me.Shelf_Car_Pic101.Text = "6001"
Me.Shelf_Car_Pic101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic101.Visible = false
'
'Shelf_Car_Pic100
'
Me.Shelf_Car_Pic100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic100.Location = New System.Drawing.Point(196, 680)
Me.Shelf_Car_Pic100.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic100.Name = "Shelf_Car_Pic100"
Me.Shelf_Car_Pic100.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic100.TabIndex = 133
Me.Shelf_Car_Pic100.Text = "6001"
Me.Shelf_Car_Pic100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic100.Visible = false
'
'Shelf_Car_Pic99
'
Me.Shelf_Car_Pic99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic99.Location = New System.Drawing.Point(196, 658)
Me.Shelf_Car_Pic99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic99.Name = "Shelf_Car_Pic99"
Me.Shelf_Car_Pic99.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic99.TabIndex = 132
Me.Shelf_Car_Pic99.Text = "6001"
Me.Shelf_Car_Pic99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic99.Visible = false
'
'Shelf_Car_Pic98
'
Me.Shelf_Car_Pic98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic98.Location = New System.Drawing.Point(196, 634)
Me.Shelf_Car_Pic98.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic98.Name = "Shelf_Car_Pic98"
Me.Shelf_Car_Pic98.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic98.TabIndex = 131
Me.Shelf_Car_Pic98.Text = "6001"
Me.Shelf_Car_Pic98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic98.Visible = false
'
'Shelf_Car_Pic97
'
Me.Shelf_Car_Pic97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic97.Location = New System.Drawing.Point(196, 613)
Me.Shelf_Car_Pic97.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic97.Name = "Shelf_Car_Pic97"
Me.Shelf_Car_Pic97.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic97.TabIndex = 130
Me.Shelf_Car_Pic97.Text = "6001"
Me.Shelf_Car_Pic97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic97.Visible = false
'
'Shelf_Car_Pic96
'
Me.Shelf_Car_Pic96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic96.Location = New System.Drawing.Point(196, 590)
Me.Shelf_Car_Pic96.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic96.Name = "Shelf_Car_Pic96"
Me.Shelf_Car_Pic96.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic96.TabIndex = 129
Me.Shelf_Car_Pic96.Text = "6001"
Me.Shelf_Car_Pic96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic96.Visible = false
'
'Shelf_Car_Pic95
'
Me.Shelf_Car_Pic95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic95.Location = New System.Drawing.Point(196, 562)
Me.Shelf_Car_Pic95.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic95.Name = "Shelf_Car_Pic95"
Me.Shelf_Car_Pic95.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic95.TabIndex = 128
Me.Shelf_Car_Pic95.Text = "6001"
Me.Shelf_Car_Pic95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic95.Visible = false
'
'Shelf_Car_Pic94
'
Me.Shelf_Car_Pic94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic94.Location = New System.Drawing.Point(196, 540)
Me.Shelf_Car_Pic94.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic94.Name = "Shelf_Car_Pic94"
Me.Shelf_Car_Pic94.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic94.TabIndex = 127
Me.Shelf_Car_Pic94.Text = "6001"
Me.Shelf_Car_Pic94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic94.Visible = false
'
'Shelf_Car_Pic93
'
Me.Shelf_Car_Pic93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic93.Location = New System.Drawing.Point(196, 518)
Me.Shelf_Car_Pic93.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic93.Name = "Shelf_Car_Pic93"
Me.Shelf_Car_Pic93.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic93.TabIndex = 126
Me.Shelf_Car_Pic93.Text = "6001"
Me.Shelf_Car_Pic93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic93.Visible = false
'
'Shelf_Car_Pic92
'
Me.Shelf_Car_Pic92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic92.Location = New System.Drawing.Point(196, 496)
Me.Shelf_Car_Pic92.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic92.Name = "Shelf_Car_Pic92"
Me.Shelf_Car_Pic92.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic92.TabIndex = 125
Me.Shelf_Car_Pic92.Text = "6001"
Me.Shelf_Car_Pic92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic92.Visible = false
'
'Shelf_Car_Pic91
'
Me.Shelf_Car_Pic91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic91.Location = New System.Drawing.Point(196, 474)
Me.Shelf_Car_Pic91.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic91.Name = "Shelf_Car_Pic91"
Me.Shelf_Car_Pic91.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic91.TabIndex = 124
Me.Shelf_Car_Pic91.Text = "6001"
Me.Shelf_Car_Pic91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic91.Visible = false
'
'Shelf_Car_Pic90
'
Me.Shelf_Car_Pic90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic90.Location = New System.Drawing.Point(191, 454)
Me.Shelf_Car_Pic90.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic90.Name = "Shelf_Car_Pic90"
Me.Shelf_Car_Pic90.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic90.TabIndex = 115
Me.Shelf_Car_Pic90.Text = "6001"
Me.Shelf_Car_Pic90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic90.Visible = false
'
'Shelf_Car_Pic89
'
Me.Shelf_Car_Pic89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic89.Location = New System.Drawing.Point(191, 432)
Me.Shelf_Car_Pic89.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic89.Name = "Shelf_Car_Pic89"
Me.Shelf_Car_Pic89.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic89.TabIndex = 114
Me.Shelf_Car_Pic89.Text = "6001"
Me.Shelf_Car_Pic89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic89.Visible = false
'
'Shelf_Car_Pic88
'
Me.Shelf_Car_Pic88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic88.Location = New System.Drawing.Point(191, 410)
Me.Shelf_Car_Pic88.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic88.Name = "Shelf_Car_Pic88"
Me.Shelf_Car_Pic88.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic88.TabIndex = 113
Me.Shelf_Car_Pic88.Text = "6001"
Me.Shelf_Car_Pic88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic88.Visible = false
'
'Shelf_Car_Pic87
'
Me.Shelf_Car_Pic87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic87.Location = New System.Drawing.Point(191, 388)
Me.Shelf_Car_Pic87.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic87.Name = "Shelf_Car_Pic87"
Me.Shelf_Car_Pic87.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic87.TabIndex = 112
Me.Shelf_Car_Pic87.Text = "6001"
Me.Shelf_Car_Pic87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic87.Visible = false
'
'Shelf_Car_Pic86
'
Me.Shelf_Car_Pic86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic86.Location = New System.Drawing.Point(191, 366)
Me.Shelf_Car_Pic86.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic86.Name = "Shelf_Car_Pic86"
Me.Shelf_Car_Pic86.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic86.TabIndex = 111
Me.Shelf_Car_Pic86.Text = "6001"
Me.Shelf_Car_Pic86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic86.Visible = false
'
'Shelf_Car_Pic85
'
Me.Shelf_Car_Pic85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic85.Location = New System.Drawing.Point(191, 338)
Me.Shelf_Car_Pic85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic85.Name = "Shelf_Car_Pic85"
Me.Shelf_Car_Pic85.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic85.TabIndex = 110
Me.Shelf_Car_Pic85.Text = "6001"
Me.Shelf_Car_Pic85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic85.Visible = false
'
'Shelf_Car_Pic84
'
Me.Shelf_Car_Pic84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic84.Location = New System.Drawing.Point(191, 314)
Me.Shelf_Car_Pic84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic84.Name = "Shelf_Car_Pic84"
Me.Shelf_Car_Pic84.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic84.TabIndex = 109
Me.Shelf_Car_Pic84.Text = "6001"
Me.Shelf_Car_Pic84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic84.Visible = false
'
'Shelf_Car_Pic83
'
Me.Shelf_Car_Pic83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic83.Location = New System.Drawing.Point(191, 292)
Me.Shelf_Car_Pic83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic83.Name = "Shelf_Car_Pic83"
Me.Shelf_Car_Pic83.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic83.TabIndex = 108
Me.Shelf_Car_Pic83.Text = "6001"
Me.Shelf_Car_Pic83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic83.Visible = false
'
'Shelf_Car_Pic82
'
Me.Shelf_Car_Pic82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic82.Location = New System.Drawing.Point(191, 271)
Me.Shelf_Car_Pic82.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic82.Name = "Shelf_Car_Pic82"
Me.Shelf_Car_Pic82.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic82.TabIndex = 107
Me.Shelf_Car_Pic82.Text = "6001"
Me.Shelf_Car_Pic82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic82.Visible = false
'
'Shelf_Car_Pic81
'
Me.Shelf_Car_Pic81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic81.Location = New System.Drawing.Point(191, 251)
Me.Shelf_Car_Pic81.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic81.Name = "Shelf_Car_Pic81"
Me.Shelf_Car_Pic81.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic81.TabIndex = 106
Me.Shelf_Car_Pic81.Text = "6001"
Me.Shelf_Car_Pic81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic81.Visible = false
'
'Shelf_Car_Pic80
'
Me.Shelf_Car_Pic80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic80.Location = New System.Drawing.Point(191, 226)
Me.Shelf_Car_Pic80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic80.Name = "Shelf_Car_Pic80"
Me.Shelf_Car_Pic80.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic80.TabIndex = 105
Me.Shelf_Car_Pic80.Text = "6001"
Me.Shelf_Car_Pic80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic80.Visible = false
'
'Shelf_Car_Pic79
'
Me.Shelf_Car_Pic79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic79.Location = New System.Drawing.Point(191, 204)
Me.Shelf_Car_Pic79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic79.Name = "Shelf_Car_Pic79"
Me.Shelf_Car_Pic79.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic79.TabIndex = 104
Me.Shelf_Car_Pic79.Text = "6001"
Me.Shelf_Car_Pic79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic79.Visible = false
'
'Shelf_Car_Pic78
'
Me.Shelf_Car_Pic78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic78.Location = New System.Drawing.Point(191, 181)
Me.Shelf_Car_Pic78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic78.Name = "Shelf_Car_Pic78"
Me.Shelf_Car_Pic78.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic78.TabIndex = 103
Me.Shelf_Car_Pic78.Text = "6001"
Me.Shelf_Car_Pic78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic78.Visible = false
'
'Shelf_Car_Pic77
'
Me.Shelf_Car_Pic77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic77.Location = New System.Drawing.Point(191, 161)
Me.Shelf_Car_Pic77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic77.Name = "Shelf_Car_Pic77"
Me.Shelf_Car_Pic77.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic77.TabIndex = 102
Me.Shelf_Car_Pic77.Text = "6001"
Me.Shelf_Car_Pic77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic77.Visible = false
'
'Shelf_Car_Pic76
'
Me.Shelf_Car_Pic76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic76.Location = New System.Drawing.Point(191, 138)
Me.Shelf_Car_Pic76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic76.Name = "Shelf_Car_Pic76"
Me.Shelf_Car_Pic76.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic76.TabIndex = 101
Me.Shelf_Car_Pic76.Text = "6001"
Me.Shelf_Car_Pic76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic76.Visible = false
'
'Shelf_Car_Pic75
'
Me.Shelf_Car_Pic75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic75.Location = New System.Drawing.Point(191, 116)
Me.Shelf_Car_Pic75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic75.Name = "Shelf_Car_Pic75"
Me.Shelf_Car_Pic75.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic75.TabIndex = 100
Me.Shelf_Car_Pic75.Text = "6001"
Me.Shelf_Car_Pic75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic75.Visible = false
'
'Shelf_Car_Pic74
'
Me.Shelf_Car_Pic74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic74.Location = New System.Drawing.Point(191, 94)
Me.Shelf_Car_Pic74.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic74.Name = "Shelf_Car_Pic74"
Me.Shelf_Car_Pic74.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic74.TabIndex = 99
Me.Shelf_Car_Pic74.Text = "6001"
Me.Shelf_Car_Pic74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic74.Visible = false
'
'Shelf_Car_Pic73
'
Me.Shelf_Car_Pic73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic73.Location = New System.Drawing.Point(191, 71)
Me.Shelf_Car_Pic73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic73.Name = "Shelf_Car_Pic73"
Me.Shelf_Car_Pic73.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic73.TabIndex = 98
Me.Shelf_Car_Pic73.Text = "6001"
Me.Shelf_Car_Pic73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic73.Visible = false
'
'Shelf_Car_Pic71
'
Me.Shelf_Car_Pic71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic71.Location = New System.Drawing.Point(191, 26)
Me.Shelf_Car_Pic71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic71.Name = "Shelf_Car_Pic71"
Me.Shelf_Car_Pic71.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic71.TabIndex = 96
Me.Shelf_Car_Pic71.Text = "6001"
Me.Shelf_Car_Pic71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic71.Visible = false
'
'Shelf_Car_Pic70
'
Me.Shelf_Car_Pic70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic70.Location = New System.Drawing.Point(154, 674)
Me.Shelf_Car_Pic70.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic70.Name = "Shelf_Car_Pic70"
Me.Shelf_Car_Pic70.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic70.TabIndex = 95
Me.Shelf_Car_Pic70.Text = "6001"
Me.Shelf_Car_Pic70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic70.Visible = false
'
'Shelf_Car_Pic69
'
Me.Shelf_Car_Pic69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic69.Location = New System.Drawing.Point(154, 649)
Me.Shelf_Car_Pic69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic69.Name = "Shelf_Car_Pic69"
Me.Shelf_Car_Pic69.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic69.TabIndex = 94
Me.Shelf_Car_Pic69.Text = "6001"
Me.Shelf_Car_Pic69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic69.Visible = false
'
'Shelf_Car_Pic68
'
Me.Shelf_Car_Pic68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic68.Location = New System.Drawing.Point(154, 629)
Me.Shelf_Car_Pic68.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic68.Name = "Shelf_Car_Pic68"
Me.Shelf_Car_Pic68.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic68.TabIndex = 93
Me.Shelf_Car_Pic68.Text = "6001"
Me.Shelf_Car_Pic68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic68.Visible = false
'
'Shelf_Car_Pic67
'
Me.Shelf_Car_Pic67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic67.Location = New System.Drawing.Point(154, 608)
Me.Shelf_Car_Pic67.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic67.Name = "Shelf_Car_Pic67"
Me.Shelf_Car_Pic67.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic67.TabIndex = 92
Me.Shelf_Car_Pic67.Text = "6001"
Me.Shelf_Car_Pic67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic67.Visible = false
'
'Shelf_Car_Pic66
'
Me.Shelf_Car_Pic66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic66.Location = New System.Drawing.Point(154, 586)
Me.Shelf_Car_Pic66.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic66.Name = "Shelf_Car_Pic66"
Me.Shelf_Car_Pic66.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic66.TabIndex = 91
Me.Shelf_Car_Pic66.Text = "6001"
Me.Shelf_Car_Pic66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic66.Visible = false
'
'Shelf_Car_Pic65
'
Me.Shelf_Car_Pic65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic65.Location = New System.Drawing.Point(154, 562)
Me.Shelf_Car_Pic65.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic65.Name = "Shelf_Car_Pic65"
Me.Shelf_Car_Pic65.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic65.TabIndex = 90
Me.Shelf_Car_Pic65.Text = "6001"
Me.Shelf_Car_Pic65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic65.Visible = false
'
'Shelf_Car_Pic64
'
Me.Shelf_Car_Pic64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic64.Location = New System.Drawing.Point(154, 540)
Me.Shelf_Car_Pic64.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic64.Name = "Shelf_Car_Pic64"
Me.Shelf_Car_Pic64.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic64.TabIndex = 89
Me.Shelf_Car_Pic64.Text = "6001"
Me.Shelf_Car_Pic64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic64.Visible = false
'
'Shelf_Car_Pic63
'
Me.Shelf_Car_Pic63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic63.Location = New System.Drawing.Point(154, 518)
Me.Shelf_Car_Pic63.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic63.Name = "Shelf_Car_Pic63"
Me.Shelf_Car_Pic63.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic63.TabIndex = 88
Me.Shelf_Car_Pic63.Text = "6001"
Me.Shelf_Car_Pic63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic63.Visible = false
'
'Shelf_Car_Pic62
'
Me.Shelf_Car_Pic62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic62.Location = New System.Drawing.Point(154, 496)
Me.Shelf_Car_Pic62.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic62.Name = "Shelf_Car_Pic62"
Me.Shelf_Car_Pic62.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic62.TabIndex = 87
Me.Shelf_Car_Pic62.Text = "6001"
Me.Shelf_Car_Pic62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic62.Visible = false
'
'Shelf_Car_Pic61
'
Me.Shelf_Car_Pic61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic61.Location = New System.Drawing.Point(154, 474)
Me.Shelf_Car_Pic61.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic61.Name = "Shelf_Car_Pic61"
Me.Shelf_Car_Pic61.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic61.TabIndex = 86
Me.Shelf_Car_Pic61.Text = "6001"
Me.Shelf_Car_Pic61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic61.Visible = false
'
'Shelf_Car_Pic60
'
Me.Shelf_Car_Pic60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic60.Location = New System.Drawing.Point(147, 451)
Me.Shelf_Car_Pic60.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic60.Name = "Shelf_Car_Pic60"
Me.Shelf_Car_Pic60.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic60.TabIndex = 85
Me.Shelf_Car_Pic60.Text = "6001"
Me.Shelf_Car_Pic60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic60.Visible = false
'
'Shelf_Car_Pic59
'
Me.Shelf_Car_Pic59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic59.Location = New System.Drawing.Point(147, 431)
Me.Shelf_Car_Pic59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic59.Name = "Shelf_Car_Pic59"
Me.Shelf_Car_Pic59.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic59.TabIndex = 84
Me.Shelf_Car_Pic59.Text = "6001"
Me.Shelf_Car_Pic59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic59.Visible = false
'
'Shelf_Car_Pic58
'
Me.Shelf_Car_Pic58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic58.Location = New System.Drawing.Point(147, 406)
Me.Shelf_Car_Pic58.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic58.Name = "Shelf_Car_Pic58"
Me.Shelf_Car_Pic58.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic58.TabIndex = 83
Me.Shelf_Car_Pic58.Text = "6001"
Me.Shelf_Car_Pic58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic58.Visible = false
'
'Shelf_Car_Pic57
'
Me.Shelf_Car_Pic57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic57.Location = New System.Drawing.Point(147, 386)
Me.Shelf_Car_Pic57.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic57.Name = "Shelf_Car_Pic57"
Me.Shelf_Car_Pic57.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic57.TabIndex = 82
Me.Shelf_Car_Pic57.Text = "6001"
Me.Shelf_Car_Pic57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic57.Visible = false
'
'Shelf_Car_Pic56
'
Me.Shelf_Car_Pic56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic56.Location = New System.Drawing.Point(147, 361)
Me.Shelf_Car_Pic56.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic56.Name = "Shelf_Car_Pic56"
Me.Shelf_Car_Pic56.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic56.TabIndex = 81
Me.Shelf_Car_Pic56.Text = "6001"
Me.Shelf_Car_Pic56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic56.Visible = false
'
'Shelf_Car_Pic55
'
Me.Shelf_Car_Pic55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic55.Location = New System.Drawing.Point(147, 338)
Me.Shelf_Car_Pic55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic55.Name = "Shelf_Car_Pic55"
Me.Shelf_Car_Pic55.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic55.TabIndex = 80
Me.Shelf_Car_Pic55.Text = "6001"
Me.Shelf_Car_Pic55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic55.Visible = false
'
'Shelf_Car_Pic54
'
Me.Shelf_Car_Pic54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic54.Location = New System.Drawing.Point(147, 314)
Me.Shelf_Car_Pic54.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic54.Name = "Shelf_Car_Pic54"
Me.Shelf_Car_Pic54.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic54.TabIndex = 79
Me.Shelf_Car_Pic54.Text = "6001"
Me.Shelf_Car_Pic54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic54.Visible = false
'
'Shelf_Car_Pic53
'
Me.Shelf_Car_Pic53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic53.Location = New System.Drawing.Point(147, 292)
Me.Shelf_Car_Pic53.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic53.Name = "Shelf_Car_Pic53"
Me.Shelf_Car_Pic53.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic53.TabIndex = 78
Me.Shelf_Car_Pic53.Text = "6001"
Me.Shelf_Car_Pic53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic53.Visible = false
'
'Shelf_Car_Pic52
'
Me.Shelf_Car_Pic52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic52.Location = New System.Drawing.Point(147, 271)
Me.Shelf_Car_Pic52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic52.Name = "Shelf_Car_Pic52"
Me.Shelf_Car_Pic52.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic52.TabIndex = 77
Me.Shelf_Car_Pic52.Text = "6001"
Me.Shelf_Car_Pic52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic52.Visible = false
'
'Shelf_Car_Pic51
'
Me.Shelf_Car_Pic51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic51.Location = New System.Drawing.Point(147, 251)
Me.Shelf_Car_Pic51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic51.Name = "Shelf_Car_Pic51"
Me.Shelf_Car_Pic51.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic51.TabIndex = 76
Me.Shelf_Car_Pic51.Text = "6001"
Me.Shelf_Car_Pic51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic51.Visible = false
'
'Shelf_Car_Pic50
'
Me.Shelf_Car_Pic50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic50.Location = New System.Drawing.Point(147, 226)
Me.Shelf_Car_Pic50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic50.Name = "Shelf_Car_Pic50"
Me.Shelf_Car_Pic50.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic50.TabIndex = 75
Me.Shelf_Car_Pic50.Text = "6001"
Me.Shelf_Car_Pic50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic50.Visible = false
'
'Shelf_Car_Pic49
'
Me.Shelf_Car_Pic49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic49.Location = New System.Drawing.Point(147, 204)
Me.Shelf_Car_Pic49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic49.Name = "Shelf_Car_Pic49"
Me.Shelf_Car_Pic49.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic49.TabIndex = 74
Me.Shelf_Car_Pic49.Text = "6001"
Me.Shelf_Car_Pic49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic49.Visible = false
'
'Shelf_Car_Pic48
'
Me.Shelf_Car_Pic48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic48.Location = New System.Drawing.Point(147, 181)
Me.Shelf_Car_Pic48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic48.Name = "Shelf_Car_Pic48"
Me.Shelf_Car_Pic48.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic48.TabIndex = 73
Me.Shelf_Car_Pic48.Text = "6001"
Me.Shelf_Car_Pic48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic48.Visible = false
'
'Shelf_Car_Pic47
'
Me.Shelf_Car_Pic47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic47.Location = New System.Drawing.Point(147, 161)
Me.Shelf_Car_Pic47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic47.Name = "Shelf_Car_Pic47"
Me.Shelf_Car_Pic47.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic47.TabIndex = 72
Me.Shelf_Car_Pic47.Text = "6001"
Me.Shelf_Car_Pic47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic47.Visible = false
'
'Shelf_Car_Pic46
'
Me.Shelf_Car_Pic46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic46.Location = New System.Drawing.Point(147, 138)
Me.Shelf_Car_Pic46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic46.Name = "Shelf_Car_Pic46"
Me.Shelf_Car_Pic46.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic46.TabIndex = 71
Me.Shelf_Car_Pic46.Text = "6001"
Me.Shelf_Car_Pic46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic46.Visible = false
'
'Shelf_Car_Pic45
'
Me.Shelf_Car_Pic45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic45.Location = New System.Drawing.Point(147, 116)
Me.Shelf_Car_Pic45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic45.Name = "Shelf_Car_Pic45"
Me.Shelf_Car_Pic45.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic45.TabIndex = 70
Me.Shelf_Car_Pic45.Text = "6001"
Me.Shelf_Car_Pic45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic45.Visible = false
'
'Shelf_Car_Pic44
'
Me.Shelf_Car_Pic44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic44.Location = New System.Drawing.Point(147, 94)
Me.Shelf_Car_Pic44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic44.Name = "Shelf_Car_Pic44"
Me.Shelf_Car_Pic44.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic44.TabIndex = 69
Me.Shelf_Car_Pic44.Text = "6001"
Me.Shelf_Car_Pic44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic44.Visible = false
'
'Shelf_Car_Pic43
'
Me.Shelf_Car_Pic43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic43.Location = New System.Drawing.Point(147, 71)
Me.Shelf_Car_Pic43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic43.Name = "Shelf_Car_Pic43"
Me.Shelf_Car_Pic43.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic43.TabIndex = 68
Me.Shelf_Car_Pic43.Text = "6001"
Me.Shelf_Car_Pic43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic43.Visible = false
'
'Shelf_Car_Pic42
'
Me.Shelf_Car_Pic42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic42.Location = New System.Drawing.Point(147, 50)
Me.Shelf_Car_Pic42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic42.Name = "Shelf_Car_Pic42"
Me.Shelf_Car_Pic42.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic42.TabIndex = 67
Me.Shelf_Car_Pic42.Text = "6001"
Me.Shelf_Car_Pic42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic42.Visible = false
'
'Shelf_Car_Pic41
'
Me.Shelf_Car_Pic41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic41.Location = New System.Drawing.Point(147, 26)
Me.Shelf_Car_Pic41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic41.Name = "Shelf_Car_Pic41"
Me.Shelf_Car_Pic41.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic41.TabIndex = 66
Me.Shelf_Car_Pic41.Text = "6001"
Me.Shelf_Car_Pic41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic41.Visible = false
'
'Shelf_Car_Pic72
'
Me.Shelf_Car_Pic72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic72.Location = New System.Drawing.Point(191, 50)
Me.Shelf_Car_Pic72.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic72.Name = "Shelf_Car_Pic72"
Me.Shelf_Car_Pic72.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic72.TabIndex = 97
Me.Shelf_Car_Pic72.Text = "6001"
Me.Shelf_Car_Pic72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic72.Visible = false
'
'LFT3
'
Me.LFT3.BackColor = System.Drawing.Color.Red
Me.LFT3.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT3.Location = New System.Drawing.Point(819, 413)
Me.LFT3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT3.Name = "LFT3"
Me.LFT3.Size = New System.Drawing.Size(47, 18)
Me.LFT3.TabIndex = 65
Me.LFT3.Text = "LFT3"
Me.LFT3.Visible = false
'
'LFT2
'
Me.LFT2.BackColor = System.Drawing.Color.Red
Me.LFT2.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT2.Location = New System.Drawing.Point(819, 388)
Me.LFT2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT2.Name = "LFT2"
Me.LFT2.Size = New System.Drawing.Size(47, 18)
Me.LFT2.TabIndex = 64
Me.LFT2.Text = "LFT2"
Me.LFT2.Visible = false
'
'LFT1
'
Me.LFT1.BackColor = System.Drawing.Color.Red
Me.LFT1.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT1.Location = New System.Drawing.Point(819, 366)
Me.LFT1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT1.Name = "LFT1"
Me.LFT1.Size = New System.Drawing.Size(47, 18)
Me.LFT1.TabIndex = 63
Me.LFT1.Text = "LFT1"
Me.LFT1.Visible = false
'
'LFT0
'
Me.LFT0.BackColor = System.Drawing.Color.Red
Me.LFT0.Font = New System.Drawing.Font("PMingLiU", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.LFT0.Location = New System.Drawing.Point(819, 343)
Me.LFT0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT0.Name = "LFT0"
Me.LFT0.Size = New System.Drawing.Size(47, 18)
Me.LFT0.TabIndex = 62
Me.LFT0.Text = "LFT0"
Me.LFT0.Visible = false
'
'Shelf_Car_Pic40
'
Me.Shelf_Car_Pic40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic40.Location = New System.Drawing.Point(112, 658)
Me.Shelf_Car_Pic40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic40.Name = "Shelf_Car_Pic40"
Me.Shelf_Car_Pic40.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic40.TabIndex = 61
Me.Shelf_Car_Pic40.Text = "6001"
Me.Shelf_Car_Pic40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic40.Visible = false
'
'Shelf_Car_Pic39
'
Me.Shelf_Car_Pic39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic39.Location = New System.Drawing.Point(112, 622)
Me.Shelf_Car_Pic39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic39.Name = "Shelf_Car_Pic39"
Me.Shelf_Car_Pic39.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic39.TabIndex = 60
Me.Shelf_Car_Pic39.Text = "6001"
Me.Shelf_Car_Pic39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic39.Visible = false
'
'Shelf_Car_Pic38
'
Me.Shelf_Car_Pic38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic38.Location = New System.Drawing.Point(112, 582)
Me.Shelf_Car_Pic38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic38.Name = "Shelf_Car_Pic38"
Me.Shelf_Car_Pic38.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic38.TabIndex = 59
Me.Shelf_Car_Pic38.Text = "6001"
Me.Shelf_Car_Pic38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic38.Visible = false
'
'Shelf_Car_Pic37
'
Me.Shelf_Car_Pic37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic37.Location = New System.Drawing.Point(112, 541)
Me.Shelf_Car_Pic37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic37.Name = "Shelf_Car_Pic37"
Me.Shelf_Car_Pic37.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic37.TabIndex = 58
Me.Shelf_Car_Pic37.Text = "6001"
Me.Shelf_Car_Pic37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic37.Visible = false
'
'Shelf_Car_Pic36
'
Me.Shelf_Car_Pic36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic36.Location = New System.Drawing.Point(112, 505)
Me.Shelf_Car_Pic36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic36.Name = "Shelf_Car_Pic36"
Me.Shelf_Car_Pic36.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic36.TabIndex = 57
Me.Shelf_Car_Pic36.Text = "6001"
Me.Shelf_Car_Pic36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic36.Visible = false
'
'Shelf_Car_Pic35
'
Me.Shelf_Car_Pic35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic35.Location = New System.Drawing.Point(107, 468)
Me.Shelf_Car_Pic35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic35.Name = "Shelf_Car_Pic35"
Me.Shelf_Car_Pic35.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic35.TabIndex = 56
Me.Shelf_Car_Pic35.Text = "6001"
Me.Shelf_Car_Pic35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic35.Visible = false
'
'Shelf_Car_Pic34
'
Me.Shelf_Car_Pic34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic34.Location = New System.Drawing.Point(107, 431)
Me.Shelf_Car_Pic34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic34.Name = "Shelf_Car_Pic34"
Me.Shelf_Car_Pic34.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic34.TabIndex = 55
Me.Shelf_Car_Pic34.Text = "6001"
Me.Shelf_Car_Pic34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic34.Visible = false
'
'Shelf_Car_Pic33
'
Me.Shelf_Car_Pic33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic33.Location = New System.Drawing.Point(107, 374)
Me.Shelf_Car_Pic33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic33.Name = "Shelf_Car_Pic33"
Me.Shelf_Car_Pic33.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic33.TabIndex = 54
Me.Shelf_Car_Pic33.Text = "6001"
Me.Shelf_Car_Pic33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic33.Visible = false
'
'Shelf_Car_Pic32
'
Me.Shelf_Car_Pic32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic32.Location = New System.Drawing.Point(107, 334)
Me.Shelf_Car_Pic32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic32.Name = "Shelf_Car_Pic32"
Me.Shelf_Car_Pic32.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic32.TabIndex = 53
Me.Shelf_Car_Pic32.Text = "6001"
Me.Shelf_Car_Pic32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic32.Visible = false
'
'Shelf_Car_Pic31
'
Me.Shelf_Car_Pic31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic31.Location = New System.Drawing.Point(105, 298)
Me.Shelf_Car_Pic31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic31.Name = "Shelf_Car_Pic31"
Me.Shelf_Car_Pic31.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic31.TabIndex = 52
Me.Shelf_Car_Pic31.Text = "6001"
Me.Shelf_Car_Pic31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic31.Visible = false
'
'Shelf_Car_Pic30
'
Me.Shelf_Car_Pic30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic30.Location = New System.Drawing.Point(107, 262)
Me.Shelf_Car_Pic30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic30.Name = "Shelf_Car_Pic30"
Me.Shelf_Car_Pic30.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic30.TabIndex = 51
Me.Shelf_Car_Pic30.Text = "6001"
Me.Shelf_Car_Pic30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic30.Visible = false
'
'Shelf_Car_Pic29
'
Me.Shelf_Car_Pic29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic29.Location = New System.Drawing.Point(107, 204)
Me.Shelf_Car_Pic29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic29.Name = "Shelf_Car_Pic29"
Me.Shelf_Car_Pic29.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic29.TabIndex = 50
Me.Shelf_Car_Pic29.Text = "6001"
Me.Shelf_Car_Pic29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic29.Visible = false
'
'Shelf_Car_Pic28
'
Me.Shelf_Car_Pic28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic28.Location = New System.Drawing.Point(107, 170)
Me.Shelf_Car_Pic28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic28.Name = "Shelf_Car_Pic28"
Me.Shelf_Car_Pic28.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic28.TabIndex = 49
Me.Shelf_Car_Pic28.Text = "6001"
Me.Shelf_Car_Pic28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic28.Visible = false
'
'Shelf_Car_Pic27
'
Me.Shelf_Car_Pic27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic27.Location = New System.Drawing.Point(107, 134)
Me.Shelf_Car_Pic27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic27.Name = "Shelf_Car_Pic27"
Me.Shelf_Car_Pic27.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic27.TabIndex = 48
Me.Shelf_Car_Pic27.Text = "6001"
Me.Shelf_Car_Pic27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic27.Visible = false
'
'Shelf_Car_Pic26
'
Me.Shelf_Car_Pic26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic26.Location = New System.Drawing.Point(107, 94)
Me.Shelf_Car_Pic26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic26.Name = "Shelf_Car_Pic26"
Me.Shelf_Car_Pic26.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic26.TabIndex = 47
Me.Shelf_Car_Pic26.Text = "6001"
Me.Shelf_Car_Pic26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic26.Visible = false
'
'Shelf_Car_Pic25
'
Me.Shelf_Car_Pic25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic25.Location = New System.Drawing.Point(70, 658)
Me.Shelf_Car_Pic25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic25.Name = "Shelf_Car_Pic25"
Me.Shelf_Car_Pic25.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic25.TabIndex = 36
Me.Shelf_Car_Pic25.Text = "6001"
Me.Shelf_Car_Pic25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic25.Visible = false
'
'Shelf_Car_Pic24
'
Me.Shelf_Car_Pic24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic24.Location = New System.Drawing.Point(65, 622)
Me.Shelf_Car_Pic24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic24.Name = "Shelf_Car_Pic24"
Me.Shelf_Car_Pic24.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic24.TabIndex = 35
Me.Shelf_Car_Pic24.Text = "6001"
Me.Shelf_Car_Pic24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic24.Visible = false
'
'Shelf_Car_Pic23
'
Me.Shelf_Car_Pic23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic23.Location = New System.Drawing.Point(65, 582)
Me.Shelf_Car_Pic23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic23.Name = "Shelf_Car_Pic23"
Me.Shelf_Car_Pic23.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic23.TabIndex = 34
Me.Shelf_Car_Pic23.Text = "6001"
Me.Shelf_Car_Pic23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic23.Visible = false
'
'Shelf_Car_Pic22
'
Me.Shelf_Car_Pic22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic22.Location = New System.Drawing.Point(65, 541)
Me.Shelf_Car_Pic22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic22.Name = "Shelf_Car_Pic22"
Me.Shelf_Car_Pic22.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic22.TabIndex = 33
Me.Shelf_Car_Pic22.Text = "6001"
Me.Shelf_Car_Pic22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic22.Visible = false
'
'Shelf_Car_Pic21
'
Me.Shelf_Car_Pic21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic21.Location = New System.Drawing.Point(65, 505)
Me.Shelf_Car_Pic21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic21.Name = "Shelf_Car_Pic21"
Me.Shelf_Car_Pic21.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic21.TabIndex = 32
Me.Shelf_Car_Pic21.Text = "6001"
Me.Shelf_Car_Pic21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic21.Visible = false
'
'Shelf_Car_Pic20
'
Me.Shelf_Car_Pic20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic20.Location = New System.Drawing.Point(63, 468)
Me.Shelf_Car_Pic20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic20.Name = "Shelf_Car_Pic20"
Me.Shelf_Car_Pic20.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic20.TabIndex = 31
Me.Shelf_Car_Pic20.Text = "6001"
Me.Shelf_Car_Pic20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic20.Visible = false
'
'Shelf_Car_Pic19
'
Me.Shelf_Car_Pic19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic19.Location = New System.Drawing.Point(63, 431)
Me.Shelf_Car_Pic19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic19.Name = "Shelf_Car_Pic19"
Me.Shelf_Car_Pic19.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic19.TabIndex = 30
Me.Shelf_Car_Pic19.Text = "6001"
Me.Shelf_Car_Pic19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic19.Visible = false
'
'Shelf_Car_Pic18
'
Me.Shelf_Car_Pic18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic18.Location = New System.Drawing.Point(63, 374)
Me.Shelf_Car_Pic18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic18.Name = "Shelf_Car_Pic18"
Me.Shelf_Car_Pic18.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic18.TabIndex = 29
Me.Shelf_Car_Pic18.Text = "6001"
Me.Shelf_Car_Pic18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic18.Visible = false
'
'Shelf_Car_Pic17
'
Me.Shelf_Car_Pic17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic17.Location = New System.Drawing.Point(63, 334)
Me.Shelf_Car_Pic17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic17.Name = "Shelf_Car_Pic17"
Me.Shelf_Car_Pic17.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic17.TabIndex = 28
Me.Shelf_Car_Pic17.Text = "6001"
Me.Shelf_Car_Pic17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic17.Visible = false
'
'Shelf_Car_Pic16
'
Me.Shelf_Car_Pic16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic16.Location = New System.Drawing.Point(63, 298)
Me.Shelf_Car_Pic16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic16.Name = "Shelf_Car_Pic16"
Me.Shelf_Car_Pic16.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic16.TabIndex = 27
Me.Shelf_Car_Pic16.Text = "6001"
Me.Shelf_Car_Pic16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic16.Visible = false
'
'Shelf_Car_Pic15
'
Me.Shelf_Car_Pic15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic15.Location = New System.Drawing.Point(63, 258)
Me.Shelf_Car_Pic15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic15.Name = "Shelf_Car_Pic15"
Me.Shelf_Car_Pic15.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic15.TabIndex = 26
Me.Shelf_Car_Pic15.Text = "6001"
Me.Shelf_Car_Pic15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic15.Visible = false
'
'Shelf_Car_Pic14
'
Me.Shelf_Car_Pic14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic14.Location = New System.Drawing.Point(63, 208)
Me.Shelf_Car_Pic14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic14.Name = "Shelf_Car_Pic14"
Me.Shelf_Car_Pic14.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic14.TabIndex = 25
Me.Shelf_Car_Pic14.Text = "6001"
Me.Shelf_Car_Pic14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic14.Visible = false
'
'Shelf_Car_Pic13
'
Me.Shelf_Car_Pic13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic13.Location = New System.Drawing.Point(63, 170)
Me.Shelf_Car_Pic13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic13.Name = "Shelf_Car_Pic13"
Me.Shelf_Car_Pic13.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic13.TabIndex = 24
Me.Shelf_Car_Pic13.Text = "6001"
Me.Shelf_Car_Pic13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic13.Visible = false
'
'Shelf_Car_Pic12
'
Me.Shelf_Car_Pic12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic12.Location = New System.Drawing.Point(63, 132)
Me.Shelf_Car_Pic12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic12.Name = "Shelf_Car_Pic12"
Me.Shelf_Car_Pic12.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic12.TabIndex = 23
Me.Shelf_Car_Pic12.Text = "6001"
Me.Shelf_Car_Pic12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic12.Visible = false
'
'Shelf_Car_Pic11
'
Me.Shelf_Car_Pic11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic11.Location = New System.Drawing.Point(63, 94)
Me.Shelf_Car_Pic11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic11.Name = "Shelf_Car_Pic11"
Me.Shelf_Car_Pic11.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic11.TabIndex = 22
Me.Shelf_Car_Pic11.Text = "6001"
Me.Shelf_Car_Pic11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic11.Visible = false
'
'Shelf_Car_Pic10
'
Me.Shelf_Car_Pic10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic10.Location = New System.Drawing.Point(19, 505)
Me.Shelf_Car_Pic10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic10.Name = "Shelf_Car_Pic10"
Me.Shelf_Car_Pic10.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic10.TabIndex = 14
Me.Shelf_Car_Pic10.Text = "6001"
Me.Shelf_Car_Pic10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic10.Visible = false
'
'Shelf_Car_Pic9
'
Me.Shelf_Car_Pic9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic9.Location = New System.Drawing.Point(16, 468)
Me.Shelf_Car_Pic9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic9.Name = "Shelf_Car_Pic9"
Me.Shelf_Car_Pic9.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic9.TabIndex = 13
Me.Shelf_Car_Pic9.Text = "6001"
Me.Shelf_Car_Pic9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic9.Visible = false
'
'Shelf_Car_Pic8
'
Me.Shelf_Car_Pic8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic8.Location = New System.Drawing.Point(16, 431)
Me.Shelf_Car_Pic8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic8.Name = "Shelf_Car_Pic8"
Me.Shelf_Car_Pic8.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic8.TabIndex = 12
Me.Shelf_Car_Pic8.Text = "6001"
Me.Shelf_Car_Pic8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic8.Visible = false
'
'Shelf_Car_Pic7
'
Me.Shelf_Car_Pic7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic7.Location = New System.Drawing.Point(16, 374)
Me.Shelf_Car_Pic7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic7.Name = "Shelf_Car_Pic7"
Me.Shelf_Car_Pic7.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic7.TabIndex = 11
Me.Shelf_Car_Pic7.Text = "6001"
Me.Shelf_Car_Pic7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic7.Visible = false
'
'Shelf_Car_Pic6
'
Me.Shelf_Car_Pic6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic6.Location = New System.Drawing.Point(16, 334)
Me.Shelf_Car_Pic6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic6.Name = "Shelf_Car_Pic6"
Me.Shelf_Car_Pic6.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic6.TabIndex = 10
Me.Shelf_Car_Pic6.Text = "6001"
Me.Shelf_Car_Pic6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic6.Visible = false
'
'Shelf_Car_Pic5
'
Me.Shelf_Car_Pic5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic5.Location = New System.Drawing.Point(16, 298)
Me.Shelf_Car_Pic5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic5.Name = "Shelf_Car_Pic5"
Me.Shelf_Car_Pic5.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic5.TabIndex = 9
Me.Shelf_Car_Pic5.Text = "6001"
Me.Shelf_Car_Pic5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic5.Visible = false
'
'Shelf_Car_Pic4
'
Me.Shelf_Car_Pic4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic4.Location = New System.Drawing.Point(16, 258)
Me.Shelf_Car_Pic4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic4.Name = "Shelf_Car_Pic4"
Me.Shelf_Car_Pic4.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic4.TabIndex = 8
Me.Shelf_Car_Pic4.Text = "6001"
Me.Shelf_Car_Pic4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic4.Visible = false
'
'Shelf_Car_Pic3
'
Me.Shelf_Car_Pic3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic3.Location = New System.Drawing.Point(16, 208)
Me.Shelf_Car_Pic3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic3.Name = "Shelf_Car_Pic3"
Me.Shelf_Car_Pic3.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic3.TabIndex = 7
Me.Shelf_Car_Pic3.Text = "6001"
Me.Shelf_Car_Pic3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic3.Visible = false
'
'Shelf_Car_Pic2
'
Me.Shelf_Car_Pic2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic2.Location = New System.Drawing.Point(16, 170)
Me.Shelf_Car_Pic2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic2.Name = "Shelf_Car_Pic2"
Me.Shelf_Car_Pic2.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic2.TabIndex = 6
Me.Shelf_Car_Pic2.Text = "6001"
Me.Shelf_Car_Pic2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic2.Visible = false
'
'Shelf_Car_Pic1
'
Me.Shelf_Car_Pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic1.Location = New System.Drawing.Point(16, 132)
Me.Shelf_Car_Pic1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic1.Name = "Shelf_Car_Pic1"
Me.Shelf_Car_Pic1.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic1.TabIndex = 5
Me.Shelf_Car_Pic1.Text = "6001"
Me.Shelf_Car_Pic1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic1.Visible = false
'
'Shelf_Car_Pic0
'
Me.Shelf_Car_Pic0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Shelf_Car_Pic0.Location = New System.Drawing.Point(16, 94)
Me.Shelf_Car_Pic0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Shelf_Car_Pic0.Name = "Shelf_Car_Pic0"
Me.Shelf_Car_Pic0.Size = New System.Drawing.Size(37, 21)
Me.Shelf_Car_Pic0.TabIndex = 4
Me.Shelf_Car_Pic0.Text = "6001"
Me.Shelf_Car_Pic0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
Me.Shelf_Car_Pic0.Visible = false
'
'PictureBox1
'
Me.PictureBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
Me.PictureBox1.Location = New System.Drawing.Point(-4, 4)
Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.PictureBox1.Name = "PictureBox1"
Me.PictureBox1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 1)
Me.PictureBox1.Size = New System.Drawing.Size(1606, 756)
Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
Me.PictureBox1.TabIndex = 0
Me.PictureBox1.TabStop = false
'
'TabPage2
'
Me.TabPage2.Controls.Add(Me.GroupBox5)
Me.TabPage2.Controls.Add(Me.GroupBox2)
Me.TabPage2.Controls.Add(Me.GroupBox1)
Me.TabPage2.Controls.Add(Me.IR_check)
Me.TabPage2.Controls.Add(Me.Label59)
Me.TabPage2.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage2.Location = New System.Drawing.Point(4, 24)
Me.TabPage2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage2.Name = "TabPage2"
Me.TabPage2.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage2.Size = New System.Drawing.Size(1606, 732)
Me.TabPage2.TabIndex = 1
Me.TabPage2.Text = "Setting"
Me.TabPage2.UseVisualStyleBackColor = true
'
'GroupBox5
'
Me.GroupBox5.Controls.Add(Me.Label56)
Me.GroupBox5.Controls.Add(Me.Label30)
Me.GroupBox5.Controls.Add(Me.MapY)
Me.GroupBox5.Controls.Add(Me.MapX)
Me.GroupBox5.Controls.Add(Me.BlockPoint)
Me.GroupBox5.Controls.Add(Me.Button17)
Me.GroupBox5.Controls.Add(Me.Label101)
Me.GroupBox5.Controls.Add(Me.DebugMode)
Me.GroupBox5.Controls.Add(Me.Label88)
Me.GroupBox5.Controls.Add(Me.Label66)
Me.GroupBox5.Controls.Add(Me.SOCTxt)
Me.GroupBox5.Controls.Add(Me.ALL_Loading_check)
Me.GroupBox5.Controls.Add(Me.Label47)
Me.GroupBox5.Controls.Add(Me.Label61)
Me.GroupBox5.Controls.Add(Me.Label100)
Me.GroupBox5.Controls.Add(Me.MyDB_txt)
Me.GroupBox5.Controls.Add(Me.Label58)
Me.GroupBox5.Controls.Add(Me.Label57)
Me.GroupBox5.Controls.Add(Me.Loading_Check)
Me.GroupBox5.Controls.Add(Me.McsPortTxt)
Me.GroupBox5.Controls.Add(Me.Label31)
Me.GroupBox5.Controls.Add(Me.LPort)
Me.GroupBox5.Controls.Add(Me.Agvc_shelfcheck)
Me.GroupBox5.Controls.Add(Me.Label62)
Me.GroupBox5.Controls.Add(Me.ratio)
Me.GroupBox5.Controls.Add(Me.IP)
Me.GroupBox5.Controls.Add(Me.Label72)
Me.GroupBox5.Controls.Add(Me.Label46)
Me.GroupBox5.Controls.Add(Me.AgvTimeout)
Me.GroupBox5.Controls.Add(Me.user_txt)
Me.GroupBox5.Controls.Add(Me.Label65)
Me.GroupBox5.Controls.Add(Me.Label63)
Me.GroupBox5.Controls.Add(Me.DoorSetLenTxt)
Me.GroupBox5.Controls.Add(Me.password_txt)
Me.GroupBox5.Controls.Add(Me.Label67)
Me.GroupBox5.Location = New System.Drawing.Point(7, 20)
Me.GroupBox5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox5.Name = "GroupBox5"
Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox5.Size = New System.Drawing.Size(248, 694)
Me.GroupBox5.TabIndex = 58
Me.GroupBox5.TabStop = false
Me.GroupBox5.Text = "全域設定"
'
'Label56
'
Me.Label56.AutoSize = true
Me.Label56.Location = New System.Drawing.Point(9, 269)
Me.Label56.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label56.Name = "Label56"
Me.Label56.Size = New System.Drawing.Size(59, 16)
Me.Label56.TabIndex = 62
Me.Label56.Text = "MapInitY"
'
'Label30
'
Me.Label30.AutoSize = true
Me.Label30.Location = New System.Drawing.Point(9, 244)
Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label30.Name = "Label30"
Me.Label30.Size = New System.Drawing.Size(60, 16)
Me.Label30.TabIndex = 61
Me.Label30.Text = "MapInitX"
'
'MapY
'
Me.MapY.Location = New System.Drawing.Point(109, 266)
Me.MapY.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.MapY.Name = "MapY"
Me.MapY.Size = New System.Drawing.Size(116, 23)
Me.MapY.TabIndex = 60
'
'MapX
'
Me.MapX.Location = New System.Drawing.Point(109, 241)
Me.MapX.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.MapX.Name = "MapX"
Me.MapX.Size = New System.Drawing.Size(116, 23)
Me.MapX.TabIndex = 59
'
'BlockPoint
'
Me.BlockPoint.Location = New System.Drawing.Point(109, 390)
Me.BlockPoint.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.BlockPoint.Name = "BlockPoint"
Me.BlockPoint.Size = New System.Drawing.Size(116, 23)
Me.BlockPoint.TabIndex = 58
'
'Button17
'
Me.Button17.Location = New System.Drawing.Point(137, 629)
Me.Button17.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button17.Name = "Button17"
Me.Button17.Size = New System.Drawing.Size(107, 57)
Me.Button17.TabIndex = 26
Me.Button17.Text = "存檔"
Me.Button17.UseVisualStyleBackColor = true
'
'Label101
'
Me.Label101.AutoSize = true
Me.Label101.Location = New System.Drawing.Point(7, 390)
Me.Label101.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label101.Name = "Label101"
Me.Label101.Size = New System.Drawing.Size(67, 16)
Me.Label101.TabIndex = 57
Me.Label101.Text = "BlockPoint"
'
'DebugMode
'
Me.DebugMode.AutoSize = true
Me.DebugMode.Location = New System.Drawing.Point(207, 57)
Me.DebugMode.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.DebugMode.Name = "DebugMode"
Me.DebugMode.Size = New System.Drawing.Size(15, 14)
Me.DebugMode.TabIndex = 43
Me.DebugMode.UseVisualStyleBackColor = true
'
'Label88
'
Me.Label88.AutoSize = true
Me.Label88.Location = New System.Drawing.Point(8, 90)
Me.Label88.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label88.Name = "Label88"
Me.Label88.Size = New System.Drawing.Size(61, 16)
Me.Label88.TabIndex = 52
Me.Label88.Text = "MCS Port"
'
'Label66
'
Me.Label66.AutoSize = true
Me.Label66.Location = New System.Drawing.Point(123, 59)
Me.Label66.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label66.Name = "Label66"
Me.Label66.Size = New System.Drawing.Size(71, 16)
Me.Label66.TabIndex = 42
Me.Label66.Text = "Debug模式"
'
'SOCTxt
'
Me.SOCTxt.Location = New System.Drawing.Point(109, 365)
Me.SOCTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.SOCTxt.Name = "SOCTxt"
Me.SOCTxt.Size = New System.Drawing.Size(116, 23)
Me.SOCTxt.TabIndex = 56
'
'ALL_Loading_check
'
Me.ALL_Loading_check.AutoSize = true
Me.ALL_Loading_check.Location = New System.Drawing.Point(207, 29)
Me.ALL_Loading_check.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ALL_Loading_check.Name = "ALL_Loading_check"
Me.ALL_Loading_check.Size = New System.Drawing.Size(15, 14)
Me.ALL_Loading_check.TabIndex = 23
Me.ALL_Loading_check.UseVisualStyleBackColor = true
'
'Label47
'
Me.Label47.AutoSize = true
Me.Label47.Location = New System.Drawing.Point(8, 115)
Me.Label47.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label47.Name = "Label47"
Me.Label47.Size = New System.Drawing.Size(44, 16)
Me.Label47.TabIndex = 8
Me.Label47.Text = "資料庫"
'
'Label61
'
Me.Label61.AutoSize = true
Me.Label61.Location = New System.Drawing.Point(123, 29)
Me.Label61.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label61.Name = "Label61"
Me.Label61.Size = New System.Drawing.Size(56, 16)
Me.Label61.TabIndex = 22
Me.Label61.Text = "全程監控"
'
'Label100
'
Me.Label100.AutoSize = true
Me.Label100.Location = New System.Drawing.Point(8, 365)
Me.Label100.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label100.Name = "Label100"
Me.Label100.Size = New System.Drawing.Size(57, 16)
Me.Label100.TabIndex = 55
Me.Label100.Text = "SOC上限"
'
'MyDB_txt
'
Me.MyDB_txt.Location = New System.Drawing.Point(109, 115)
Me.MyDB_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.MyDB_txt.Name = "MyDB_txt"
Me.MyDB_txt.Size = New System.Drawing.Size(116, 23)
Me.MyDB_txt.TabIndex = 9
'
'Label58
'
Me.Label58.AutoSize = true
Me.Label58.Location = New System.Drawing.Point(7, 62)
Me.Label58.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label58.Name = "Label58"
Me.Label58.Size = New System.Drawing.Size(56, 16)
Me.Label58.TabIndex = 17
Me.Label58.Text = "帳料判斷"
'
'Label57
'
Me.Label57.AutoSize = true
Me.Label57.Location = New System.Drawing.Point(8, 140)
Me.Label57.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label57.Name = "Label57"
Me.Label57.Size = New System.Drawing.Size(67, 16)
Me.Label57.TabIndex = 14
Me.Label57.Text = "Moxa Port"
'
'Loading_Check
'
Me.Loading_Check.AutoSize = true
Me.Loading_Check.Location = New System.Drawing.Point(74, 29)
Me.Loading_Check.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Loading_Check.Name = "Loading_Check"
Me.Loading_Check.Size = New System.Drawing.Size(15, 14)
Me.Loading_Check.TabIndex = 16
Me.Loading_Check.UseVisualStyleBackColor = true
'
'McsPortTxt
'
Me.McsPortTxt.Location = New System.Drawing.Point(109, 90)
Me.McsPortTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.McsPortTxt.Name = "McsPortTxt"
Me.McsPortTxt.Size = New System.Drawing.Size(116, 23)
Me.McsPortTxt.TabIndex = 53
'
'Label31
'
Me.Label31.AutoSize = true
Me.Label31.Location = New System.Drawing.Point(9, 29)
Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label31.Name = "Label31"
Me.Label31.Size = New System.Drawing.Size(56, 16)
Me.Label31.TabIndex = 4
Me.Label31.Text = "在荷判斷"
'
'LPort
'
Me.LPort.Location = New System.Drawing.Point(109, 140)
Me.LPort.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.LPort.Name = "LPort"
Me.LPort.Size = New System.Drawing.Size(116, 23)
Me.LPort.TabIndex = 15
'
'Agvc_shelfcheck
'
Me.Agvc_shelfcheck.AutoSize = true
Me.Agvc_shelfcheck.Location = New System.Drawing.Point(74, 59)
Me.Agvc_shelfcheck.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Agvc_shelfcheck.Name = "Agvc_shelfcheck"
Me.Agvc_shelfcheck.Size = New System.Drawing.Size(15, 14)
Me.Agvc_shelfcheck.TabIndex = 3
Me.Agvc_shelfcheck.UseVisualStyleBackColor = true
'
'Label62
'
Me.Label62.AutoSize = true
Me.Label62.Location = New System.Drawing.Point(8, 165)
Me.Label62.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label62.Name = "Label62"
Me.Label62.Size = New System.Drawing.Size(18, 16)
Me.Label62.TabIndex = 24
Me.Label62.Text = "IP"
'
'ratio
'
Me.ratio.Location = New System.Drawing.Point(109, 340)
Me.ratio.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ratio.Name = "ratio"
Me.ratio.Size = New System.Drawing.Size(116, 23)
Me.ratio.TabIndex = 51
'
'IP
'
Me.IP.Location = New System.Drawing.Point(109, 165)
Me.IP.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.IP.Name = "IP"
Me.IP.Size = New System.Drawing.Size(116, 23)
Me.IP.TabIndex = 25
'
'Label72
'
Me.Label72.AutoSize = true
Me.Label72.Location = New System.Drawing.Point(8, 340)
Me.Label72.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label72.Name = "Label72"
Me.Label72.Size = New System.Drawing.Size(56, 16)
Me.Label72.TabIndex = 50
Me.Label72.Text = "顯示倍率"
'
'Label46
'
Me.Label46.AutoSize = true
Me.Label46.Location = New System.Drawing.Point(8, 190)
Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label46.Name = "Label46"
Me.Label46.Size = New System.Drawing.Size(33, 16)
Me.Label46.TabIndex = 27
Me.Label46.Text = "User"
'
'AgvTimeout
'
Me.AgvTimeout.Location = New System.Drawing.Point(109, 315)
Me.AgvTimeout.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.AgvTimeout.Name = "AgvTimeout"
Me.AgvTimeout.Size = New System.Drawing.Size(116, 23)
Me.AgvTimeout.TabIndex = 49
'
'user_txt
'
Me.user_txt.Location = New System.Drawing.Point(109, 190)
Me.user_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.user_txt.Name = "user_txt"
Me.user_txt.Size = New System.Drawing.Size(116, 23)
Me.user_txt.TabIndex = 28
'
'Label65
'
Me.Label65.AutoSize = true
Me.Label65.Location = New System.Drawing.Point(8, 315)
Me.Label65.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label65.Name = "Label65"
Me.Label65.Size = New System.Drawing.Size(89, 16)
Me.Label65.TabIndex = 48
Me.Label65.Text = "對峙timeout(s)"
'
'Label63
'
Me.Label63.AutoSize = true
Me.Label63.Location = New System.Drawing.Point(8, 215)
Me.Label63.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label63.Name = "Label63"
Me.Label63.Size = New System.Drawing.Size(61, 16)
Me.Label63.TabIndex = 29
Me.Label63.Text = "Password"
'
'DoorSetLenTxt
'
Me.DoorSetLenTxt.Location = New System.Drawing.Point(109, 290)
Me.DoorSetLenTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.DoorSetLenTxt.Name = "DoorSetLenTxt"
Me.DoorSetLenTxt.Size = New System.Drawing.Size(116, 23)
Me.DoorSetLenTxt.TabIndex = 45
'
'password_txt
'
Me.password_txt.Location = New System.Drawing.Point(109, 215)
Me.password_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.password_txt.Name = "password_txt"
Me.password_txt.Size = New System.Drawing.Size(116, 23)
Me.password_txt.TabIndex = 32
'
'Label67
'
Me.Label67.AutoSize = true
Me.Label67.Location = New System.Drawing.Point(8, 290)
Me.Label67.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label67.Name = "Label67"
Me.Label67.Size = New System.Drawing.Size(44, 16)
Me.Label67.TabIndex = 44
Me.Label67.Text = "滑升門"
'
'GroupBox2
'
Me.GroupBox2.Controls.Add(Me.RetreatPath)
Me.GroupBox2.Controls.Add(Me.Label116)
Me.GroupBox2.Controls.Add(Me.SiteTxt)
Me.GroupBox2.Controls.Add(Me.Label115)
Me.GroupBox2.Controls.Add(Me.Label114)
Me.GroupBox2.Controls.Add(Me.block_Path)
Me.GroupBox2.Controls.Add(Me.RePath)
Me.GroupBox2.Controls.Add(Me.Label106)
Me.GroupBox2.Controls.Add(Me.MaxPath)
Me.GroupBox2.Controls.Add(Me.Label113)
Me.GroupBox2.Controls.Add(Me.Button30)
Me.GroupBox2.Controls.Add(Me.ReverseXY)
Me.GroupBox2.Controls.Add(Me.Label112)
Me.GroupBox2.Controls.Add(Me.SetOffset_Y)
Me.GroupBox2.Controls.Add(Me.Label111)
Me.GroupBox2.Controls.Add(Me.Recharge_volt)
Me.GroupBox2.Controls.Add(Me.Label102)
Me.GroupBox2.Controls.Add(Me.AGV_SetNo)
Me.GroupBox2.Controls.Add(Me.SetOffset_X)
Me.GroupBox2.Controls.Add(Me.Label110)
Me.GroupBox2.Controls.Add(Me.Label103)
Me.GroupBox2.Controls.Add(Me.Recharge_SOC)
Me.GroupBox2.Controls.Add(Me.Setheight)
Me.GroupBox2.Controls.Add(Me.Label109)
Me.GroupBox2.Controls.Add(Me.Label104)
Me.GroupBox2.Controls.Add(Me.Recharge_Point)
Me.GroupBox2.Controls.Add(Me.Setwidth)
Me.GroupBox2.Controls.Add(Me.Label108)
Me.GroupBox2.Controls.Add(Me.Label105)
Me.GroupBox2.Controls.Add(Me.wait_point)
Me.GroupBox2.Controls.Add(Me.Label107)
Me.GroupBox2.Controls.Add(Me.block_point)
Me.GroupBox2.Location = New System.Drawing.Point(517, 20)
Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox2.Name = "GroupBox2"
Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox2.Size = New System.Drawing.Size(250, 694)
Me.GroupBox2.TabIndex = 58
Me.GroupBox2.TabStop = false
Me.GroupBox2.Text = "AGV"
'
'RetreatPath
'
Me.RetreatPath.Location = New System.Drawing.Point(112, 353)
Me.RetreatPath.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.RetreatPath.Name = "RetreatPath"
Me.RetreatPath.Size = New System.Drawing.Size(116, 23)
Me.RetreatPath.TabIndex = 116
'
'Label116
'
Me.Label116.AutoSize = true
Me.Label116.Location = New System.Drawing.Point(11, 353)
Me.Label116.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label116.Name = "Label116"
Me.Label116.Size = New System.Drawing.Size(56, 16)
Me.Label116.TabIndex = 115
Me.Label116.Text = "退避長度"
'
'SiteTxt
'
Me.SiteTxt.Location = New System.Drawing.Point(112, 379)
Me.SiteTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.SiteTxt.Name = "SiteTxt"
Me.SiteTxt.Size = New System.Drawing.Size(116, 23)
Me.SiteTxt.TabIndex = 114
'
'Label115
'
Me.Label115.AutoSize = true
Me.Label115.Location = New System.Drawing.Point(11, 379)
Me.Label115.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label115.Name = "Label115"
Me.Label115.Size = New System.Drawing.Size(32, 16)
Me.Label115.TabIndex = 113
Me.Label115.Text = "區域"
'
'Label114
'
Me.Label114.AutoSize = true
Me.Label114.Location = New System.Drawing.Point(11, 495)
Me.Label114.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label114.Name = "Label114"
Me.Label114.Size = New System.Drawing.Size(66, 16)
Me.Label114.TabIndex = 111
Me.Label114.Text = "Bock_path"
'
'block_Path
'
Me.block_Path.Location = New System.Drawing.Point(112, 492)
Me.block_Path.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.block_Path.Multiline = true
Me.block_Path.Name = "block_Path"
Me.block_Path.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.block_Path.Size = New System.Drawing.Size(116, 113)
Me.block_Path.TabIndex = 112
'
'RePath
'
Me.RePath.Location = New System.Drawing.Point(112, 326)
Me.RePath.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.RePath.Name = "RePath"
Me.RePath.Size = New System.Drawing.Size(116, 23)
Me.RePath.TabIndex = 110
'
'Label106
'
Me.Label106.AutoSize = true
Me.Label106.Location = New System.Drawing.Point(11, 326)
Me.Label106.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label106.Name = "Label106"
Me.Label106.Size = New System.Drawing.Size(56, 16)
Me.Label106.TabIndex = 109
Me.Label106.Text = "重新規劃"
'
'MaxPath
'
Me.MaxPath.Location = New System.Drawing.Point(112, 299)
Me.MaxPath.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.MaxPath.Name = "MaxPath"
Me.MaxPath.Size = New System.Drawing.Size(116, 23)
Me.MaxPath.TabIndex = 108
'
'Label113
'
Me.Label113.AutoSize = true
Me.Label113.Location = New System.Drawing.Point(11, 299)
Me.Label113.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label113.Name = "Label113"
Me.Label113.Size = New System.Drawing.Size(56, 16)
Me.Label113.TabIndex = 107
Me.Label113.Text = "預約長度"
'
'Button30
'
Me.Button30.Location = New System.Drawing.Point(130, 629)
Me.Button30.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button30.Name = "Button30"
Me.Button30.Size = New System.Drawing.Size(116, 57)
Me.Button30.TabIndex = 59
Me.Button30.Text = "存檔"
Me.Button30.UseVisualStyleBackColor = true
'
'ReverseXY
'
Me.ReverseXY.Location = New System.Drawing.Point(112, 210)
Me.ReverseXY.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ReverseXY.Name = "ReverseXY"
Me.ReverseXY.Size = New System.Drawing.Size(116, 23)
Me.ReverseXY.TabIndex = 106
'
'Label112
'
Me.Label112.AutoSize = true
Me.Label112.Location = New System.Drawing.Point(11, 210)
Me.Label112.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label112.Name = "Label112"
Me.Label112.Size = New System.Drawing.Size(67, 16)
Me.Label112.TabIndex = 105
Me.Label112.Text = "XYReverse"
'
'SetOffset_Y
'
Me.SetOffset_Y.Location = New System.Drawing.Point(112, 268)
Me.SetOffset_Y.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.SetOffset_Y.Name = "SetOffset_Y"
Me.SetOffset_Y.Size = New System.Drawing.Size(116, 23)
Me.SetOffset_Y.TabIndex = 104
'
'Label111
'
Me.Label111.AutoSize = true
Me.Label111.Location = New System.Drawing.Point(11, 268)
Me.Label111.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label111.Name = "Label111"
Me.Label111.Size = New System.Drawing.Size(52, 16)
Me.Label111.TabIndex = 103
Me.Label111.Text = "offset_Y"
'
'Recharge_volt
'
Me.Recharge_volt.Location = New System.Drawing.Point(112, 58)
Me.Recharge_volt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Recharge_volt.Name = "Recharge_volt"
Me.Recharge_volt.Size = New System.Drawing.Size(116, 23)
Me.Recharge_volt.TabIndex = 76
'
'Label102
'
Me.Label102.AutoSize = true
Me.Label102.Location = New System.Drawing.Point(11, 58)
Me.Label102.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label102.Name = "Label102"
Me.Label102.Size = New System.Drawing.Size(75, 16)
Me.Label102.TabIndex = 75
Me.Label102.Text = "Charge_volt"
'
'AGV_SetNo
'
Me.AGV_SetNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.AGV_SetNo.FormattingEnabled = true
Me.AGV_SetNo.Location = New System.Drawing.Point(14, 25)
Me.AGV_SetNo.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.AGV_SetNo.Name = "AGV_SetNo"
Me.AGV_SetNo.Size = New System.Drawing.Size(37, 23)
Me.AGV_SetNo.TabIndex = 102
'
'SetOffset_X
'
Me.SetOffset_X.Location = New System.Drawing.Point(112, 241)
Me.SetOffset_X.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.SetOffset_X.Name = "SetOffset_X"
Me.SetOffset_X.Size = New System.Drawing.Size(116, 23)
Me.SetOffset_X.TabIndex = 74
'
'Label110
'
Me.Label110.AutoSize = true
Me.Label110.Location = New System.Drawing.Point(11, 83)
Me.Label110.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label110.Name = "Label110"
Me.Label110.Size = New System.Drawing.Size(79, 16)
Me.Label110.TabIndex = 59
Me.Label110.Text = "Charge_SOC"
'
'Label103
'
Me.Label103.AutoSize = true
Me.Label103.Location = New System.Drawing.Point(11, 241)
Me.Label103.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label103.Name = "Label103"
Me.Label103.Size = New System.Drawing.Size(53, 16)
Me.Label103.TabIndex = 73
Me.Label103.Text = "offset_X"
'
'Recharge_SOC
'
Me.Recharge_SOC.Location = New System.Drawing.Point(112, 83)
Me.Recharge_SOC.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Recharge_SOC.Name = "Recharge_SOC"
Me.Recharge_SOC.Size = New System.Drawing.Size(116, 23)
Me.Recharge_SOC.TabIndex = 60
'
'Setheight
'
Me.Setheight.Location = New System.Drawing.Point(112, 182)
Me.Setheight.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Setheight.Name = "Setheight"
Me.Setheight.Size = New System.Drawing.Size(116, 23)
Me.Setheight.TabIndex = 72
'
'Label109
'
Me.Label109.AutoSize = true
Me.Label109.Location = New System.Drawing.Point(11, 108)
Me.Label109.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label109.Name = "Label109"
Me.Label109.Size = New System.Drawing.Size(83, 16)
Me.Label109.TabIndex = 61
Me.Label109.Text = "Charge_Point"
'
'Label104
'
Me.Label104.AutoSize = true
Me.Label104.Location = New System.Drawing.Point(11, 182)
Me.Label104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label104.Name = "Label104"
Me.Label104.Size = New System.Drawing.Size(44, 16)
Me.Label104.TabIndex = 71
Me.Label104.Text = "height"
'
'Recharge_Point
'
Me.Recharge_Point.Location = New System.Drawing.Point(112, 108)
Me.Recharge_Point.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Recharge_Point.Name = "Recharge_Point"
Me.Recharge_Point.Size = New System.Drawing.Size(116, 23)
Me.Recharge_Point.TabIndex = 62
'
'Setwidth
'
Me.Setwidth.Location = New System.Drawing.Point(112, 157)
Me.Setwidth.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Setwidth.Name = "Setwidth"
Me.Setwidth.Size = New System.Drawing.Size(116, 23)
Me.Setwidth.TabIndex = 70
'
'Label108
'
Me.Label108.AutoSize = true
Me.Label108.Location = New System.Drawing.Point(11, 133)
Me.Label108.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label108.Name = "Label108"
Me.Label108.Size = New System.Drawing.Size(69, 16)
Me.Label108.TabIndex = 63
Me.Label108.Text = "Wait_point"
'
'Label105
'
Me.Label105.AutoSize = true
Me.Label105.Location = New System.Drawing.Point(11, 157)
Me.Label105.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label105.Name = "Label105"
Me.Label105.Size = New System.Drawing.Size(39, 16)
Me.Label105.TabIndex = 69
Me.Label105.Text = "width"
'
'wait_point
'
Me.wait_point.Location = New System.Drawing.Point(112, 133)
Me.wait_point.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.wait_point.Name = "wait_point"
Me.wait_point.Size = New System.Drawing.Size(116, 23)
Me.wait_point.TabIndex = 64
'
'Label107
'
Me.Label107.AutoSize = true
Me.Label107.Location = New System.Drawing.Point(11, 410)
Me.Label107.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label107.Name = "Label107"
Me.Label107.Size = New System.Drawing.Size(70, 16)
Me.Label107.TabIndex = 65
Me.Label107.Text = "Bock_point"
'
'block_point
'
Me.block_point.Location = New System.Drawing.Point(112, 410)
Me.block_point.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.block_point.Multiline = true
Me.block_point.Name = "block_point"
Me.block_point.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.block_point.Size = New System.Drawing.Size(116, 74)
Me.block_point.TabIndex = 66
'
'GroupBox1
'
Me.GroupBox1.Controls.Add(Me.Label92)
Me.GroupBox1.Controls.Add(Me.Button35)
Me.GroupBox1.Controls.Add(Me.Err211)
Me.GroupBox1.Location = New System.Drawing.Point(259, 20)
Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox1.Name = "GroupBox1"
Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox1.Size = New System.Drawing.Size(228, 694)
Me.GroupBox1.TabIndex = 54
Me.GroupBox1.TabStop = false
Me.GroupBox1.Text = "自動復歸"
'
'Label92
'
Me.Label92.AutoSize = true
Me.Label92.Location = New System.Drawing.Point(15, 27)
Me.Label92.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label92.Name = "Label92"
Me.Label92.Size = New System.Drawing.Size(81, 16)
Me.Label92.TabIndex = 56
Me.Label92.Text = "No Bar Code"
'
'Button35
'
Me.Button35.Location = New System.Drawing.Point(117, 629)
Me.Button35.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button35.Name = "Button35"
Me.Button35.Size = New System.Drawing.Size(107, 57)
Me.Button35.TabIndex = 26
Me.Button35.Text = "存檔"
Me.Button35.UseVisualStyleBackColor = true
'
'Err211
'
Me.Err211.AutoSize = true
Me.Err211.Location = New System.Drawing.Point(127, 27)
Me.Err211.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Err211.Name = "Err211"
Me.Err211.Size = New System.Drawing.Size(15, 14)
Me.Err211.TabIndex = 57
Me.Err211.UseVisualStyleBackColor = true
'
'IR_check
'
Me.IR_check.AutoSize = true
Me.IR_check.Location = New System.Drawing.Point(883, 24)
Me.IR_check.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.IR_check.Name = "IR_check"
Me.IR_check.Size = New System.Drawing.Size(15, 14)
Me.IR_check.TabIndex = 19
Me.IR_check.UseVisualStyleBackColor = true
'
'Label59
'
Me.Label59.AutoSize = true
Me.Label59.Location = New System.Drawing.Point(787, 24)
Me.Label59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label59.Name = "Label59"
Me.Label59.Size = New System.Drawing.Size(60, 16)
Me.Label59.TabIndex = 18
Me.Label59.Text = "IR Sensor"
'
'TabPage3
'
Me.TabPage3.Controls.Add(Me.Button13)
Me.TabPage3.Controls.Add(Me.Button11)
Me.TabPage3.Controls.Add(Me.Label89)
Me.TabPage3.Controls.Add(Me.Econ_49)
Me.TabPage3.Controls.Add(Me.Label90)
Me.TabPage3.Controls.Add(Me.Econ_48)
Me.TabPage3.Controls.Add(Me.Label91)
Me.TabPage3.Controls.Add(Me.Econ_47)
Me.TabPage3.Controls.Add(Me.Label93)
Me.TabPage3.Controls.Add(Me.Econ_46)
Me.TabPage3.Controls.Add(Me.Label94)
Me.TabPage3.Controls.Add(Me.Econ_45)
Me.TabPage3.Controls.Add(Me.Label95)
Me.TabPage3.Controls.Add(Me.Econ_44)
Me.TabPage3.Controls.Add(Me.Label96)
Me.TabPage3.Controls.Add(Me.Econ_43)
Me.TabPage3.Controls.Add(Me.Label97)
Me.TabPage3.Controls.Add(Me.Econ_42)
Me.TabPage3.Controls.Add(Me.Label98)
Me.TabPage3.Controls.Add(Me.Econ_41)
Me.TabPage3.Controls.Add(Me.Label99)
Me.TabPage3.Controls.Add(Me.Econ_40)
Me.TabPage3.Controls.Add(Me.Label87)
Me.TabPage3.Controls.Add(Me.Econ_39)
Me.TabPage3.Controls.Add(Me.Label86)
Me.TabPage3.Controls.Add(Me.Econ_38)
Me.TabPage3.Controls.Add(Me.Label85)
Me.TabPage3.Controls.Add(Me.Econ_37)
Me.TabPage3.Controls.Add(Me.Label84)
Me.TabPage3.Controls.Add(Me.Econ_36)
Me.TabPage3.Controls.Add(Me.Label83)
Me.TabPage3.Controls.Add(Me.Econ_35)
Me.TabPage3.Controls.Add(Me.Label82)
Me.TabPage3.Controls.Add(Me.Econ_34)
Me.TabPage3.Controls.Add(Me.Label81)
Me.TabPage3.Controls.Add(Me.Econ_33)
Me.TabPage3.Controls.Add(Me.Label64)
Me.TabPage3.Controls.Add(Me.Econ_32)
Me.TabPage3.Controls.Add(Me.Label60)
Me.TabPage3.Controls.Add(Me.Econ_31)
Me.TabPage3.Controls.Add(Me.Label80)
Me.TabPage3.Controls.Add(Me.CstID)
Me.TabPage3.Controls.Add(Me.Label69)
Me.TabPage3.Controls.Add(Me.Label70)
Me.TabPage3.Controls.Add(Me.Econ_30)
Me.TabPage3.Controls.Add(Me.Econ_29)
Me.TabPage3.Controls.Add(Me.Label71)
Me.TabPage3.Controls.Add(Me.Econ_28)
Me.TabPage3.Controls.Add(Me.Label73)
Me.TabPage3.Controls.Add(Me.Label74)
Me.TabPage3.Controls.Add(Me.Label75)
Me.TabPage3.Controls.Add(Me.Label76)
Me.TabPage3.Controls.Add(Me.Label77)
Me.TabPage3.Controls.Add(Me.Label78)
Me.TabPage3.Controls.Add(Me.Label79)
Me.TabPage3.Controls.Add(Me.Econ_27)
Me.TabPage3.Controls.Add(Me.Econ_26)
Me.TabPage3.Controls.Add(Me.Econ_25)
Me.TabPage3.Controls.Add(Me.Econ_24)
Me.TabPage3.Controls.Add(Me.Econ_23)
Me.TabPage3.Controls.Add(Me.Econ_22)
Me.TabPage3.Controls.Add(Me.Econ_21)
Me.TabPage3.Controls.Add(Me.Label55)
Me.TabPage3.Controls.Add(Me.Label54)
Me.TabPage3.Controls.Add(Me.Econ_19)
Me.TabPage3.Controls.Add(Me.Econ_18)
Me.TabPage3.Controls.Add(Me.Label52)
Me.TabPage3.Controls.Add(Me.txtTemp_to)
Me.TabPage3.Controls.Add(Me.Label51)
Me.TabPage3.Controls.Add(Me.strReserve_txt)
Me.TabPage3.Controls.Add(Me.Label50)
Me.TabPage3.Controls.Add(Me.Label48)
Me.TabPage3.Controls.Add(Me.Label49)
Me.TabPage3.Controls.Add(Me.txtFrom)
Me.TabPage3.Controls.Add(Me.txtTo)
Me.TabPage3.Controls.Add(Me.txtToAGV20)
Me.TabPage3.Controls.Add(Me.Label41)
Me.TabPage3.Controls.Add(Me.Label42)
Me.TabPage3.Controls.Add(Me.Label43)
Me.TabPage3.Controls.Add(Me.Label44)
Me.TabPage3.Controls.Add(Me.Label45)
Me.TabPage3.Controls.Add(Me.Label36)
Me.TabPage3.Controls.Add(Me.Label37)
Me.TabPage3.Controls.Add(Me.Label38)
Me.TabPage3.Controls.Add(Me.Label39)
Me.TabPage3.Controls.Add(Me.Label40)
Me.TabPage3.Controls.Add(Me.Label25)
Me.TabPage3.Controls.Add(Me.Label26)
Me.TabPage3.Controls.Add(Me.Label33)
Me.TabPage3.Controls.Add(Me.Label34)
Me.TabPage3.Controls.Add(Me.Label35)
Me.TabPage3.Controls.Add(Me.txtToAGV18)
Me.TabPage3.Controls.Add(Me.txtToAGV19)
Me.TabPage3.Controls.Add(Me.txtToAGV17)
Me.TabPage3.Controls.Add(Me.txtToAGV16)
Me.TabPage3.Controls.Add(Me.txtToAGV15)
Me.TabPage3.Controls.Add(Me.txtToAGV13)
Me.TabPage3.Controls.Add(Me.txtToAGV14)
Me.TabPage3.Controls.Add(Me.txtToAGV12)
Me.TabPage3.Controls.Add(Me.txtToAGV11)
Me.TabPage3.Controls.Add(Me.txtToAGV10)
Me.TabPage3.Controls.Add(Me.txtToAGV9)
Me.TabPage3.Controls.Add(Me.txtToAGV0)
Me.TabPage3.Controls.Add(Me.txtToAGV8)
Me.TabPage3.Controls.Add(Me.txtToAGV7)
Me.TabPage3.Controls.Add(Me.txtToAGV6)
Me.TabPage3.Controls.Add(Me.Label32)
Me.TabPage3.Controls.Add(Me.Econ_17)
Me.TabPage3.Controls.Add(Me.Label29)
Me.TabPage3.Controls.Add(Me.WorkList)
Me.TabPage3.Controls.Add(Me.Label27)
Me.TabPage3.Controls.Add(Me.Label28)
Me.TabPage3.Controls.Add(Me.txtToAGV4)
Me.TabPage3.Controls.Add(Me.txtToAGV5)
Me.TabPage3.Controls.Add(Me.Label23)
Me.TabPage3.Controls.Add(Me.Label22)
Me.TabPage3.Controls.Add(Me.Label21)
Me.TabPage3.Controls.Add(Me.txtToAGV3)
Me.TabPage3.Controls.Add(Me.txtToAGV2)
Me.TabPage3.Controls.Add(Me.txtToAGV1)
Me.TabPage3.Controls.Add(Me.Label12)
Me.TabPage3.Controls.Add(Me.Label11)
Me.TabPage3.Controls.Add(Me.TextBox2)
Me.TabPage3.Controls.Add(Me.TextBox1)
Me.TabPage3.Controls.Add(Me.Label13)
Me.TabPage3.Controls.Add(Me.Label14)
Me.TabPage3.Controls.Add(Me.Label15)
Me.TabPage3.Controls.Add(Me.Label16)
Me.TabPage3.Controls.Add(Me.Label17)
Me.TabPage3.Controls.Add(Me.Label18)
Me.TabPage3.Controls.Add(Me.Label19)
Me.TabPage3.Controls.Add(Me.Label20)
Me.TabPage3.Controls.Add(Me.Econ_20)
Me.TabPage3.Controls.Add(Me.Econ_16)
Me.TabPage3.Controls.Add(Me.Econ_15)
Me.TabPage3.Controls.Add(Me.Econ_14)
Me.TabPage3.Controls.Add(Me.Econ_13)
Me.TabPage3.Controls.Add(Me.Econ_12)
Me.TabPage3.Controls.Add(Me.Econ_11)
Me.TabPage3.Controls.Add(Me.Econ_10)
Me.TabPage3.Controls.Add(Me.Label10)
Me.TabPage3.Controls.Add(Me.Label9)
Me.TabPage3.Controls.Add(Me.Label5)
Me.TabPage3.Controls.Add(Me.Label6)
Me.TabPage3.Controls.Add(Me.Label7)
Me.TabPage3.Controls.Add(Me.Label8)
Me.TabPage3.Controls.Add(Me.Label4)
Me.TabPage3.Controls.Add(Me.Label3)
Me.TabPage3.Controls.Add(Me.Label2)
Me.TabPage3.Controls.Add(Me.Label1)
Me.TabPage3.Controls.Add(Me.Econ_9)
Me.TabPage3.Controls.Add(Me.Econ_8)
Me.TabPage3.Controls.Add(Me.Econ_7)
Me.TabPage3.Controls.Add(Me.Econ_6)
Me.TabPage3.Controls.Add(Me.Econ_5)
Me.TabPage3.Controls.Add(Me.Econ_4)
Me.TabPage3.Controls.Add(Me.Econ_3)
Me.TabPage3.Controls.Add(Me.Econ_2)
Me.TabPage3.Controls.Add(Me.Econ_1)
Me.TabPage3.Controls.Add(Me.Econ_0)
Me.TabPage3.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage3.Location = New System.Drawing.Point(4, 24)
Me.TabPage3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage3.Name = "TabPage3"
Me.TabPage3.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage3.Size = New System.Drawing.Size(1606, 732)
Me.TabPage3.TabIndex = 2
Me.TabPage3.Text = "狀態"
Me.TabPage3.UseVisualStyleBackColor = true
'
'Button13
'
Me.Button13.Location = New System.Drawing.Point(1042, 287)
Me.Button13.Name = "Button13"
Me.Button13.Size = New System.Drawing.Size(75, 23)
Me.Button13.TabIndex = 366
Me.Button13.Text = "Button13"
Me.Button13.UseVisualStyleBackColor = true
'
'Button11
'
Me.Button11.Location = New System.Drawing.Point(1042, 255)
Me.Button11.Name = "Button11"
Me.Button11.Size = New System.Drawing.Size(75, 23)
Me.Button11.TabIndex = 365
Me.Button11.Text = "Button11"
Me.Button11.UseVisualStyleBackColor = true
'
'Label89
'
Me.Label89.AutoSize = true
Me.Label89.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label89.Location = New System.Drawing.Point(450, 375)
Me.Label89.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label89.Name = "Label89"
Me.Label89.Size = New System.Drawing.Size(32, 16)
Me.Label89.TabIndex = 209
Me.Label89.Text = "保留"
'
'Econ_49
'
Me.Econ_49.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_49.Location = New System.Drawing.Point(513, 368)
Me.Econ_49.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_49.Name = "Econ_49"
Me.Econ_49.Size = New System.Drawing.Size(46, 23)
Me.Econ_49.TabIndex = 208
'
'Label90
'
Me.Label90.AutoSize = true
Me.Label90.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label90.Location = New System.Drawing.Point(450, 338)
Me.Label90.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label90.Name = "Label90"
Me.Label90.Size = New System.Drawing.Size(32, 16)
Me.Label90.TabIndex = 207
Me.Label90.Text = "保留"
'
'Econ_48
'
Me.Econ_48.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_48.Location = New System.Drawing.Point(513, 330)
Me.Econ_48.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_48.Name = "Econ_48"
Me.Econ_48.Size = New System.Drawing.Size(46, 23)
Me.Econ_48.TabIndex = 206
'
'Label91
'
Me.Label91.AutoSize = true
Me.Label91.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label91.Location = New System.Drawing.Point(448, 300)
Me.Label91.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label91.Name = "Label91"
Me.Label91.Size = New System.Drawing.Size(32, 16)
Me.Label91.TabIndex = 205
Me.Label91.Text = "保留"
'
'Econ_47
'
Me.Econ_47.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_47.Location = New System.Drawing.Point(513, 292)
Me.Econ_47.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_47.Name = "Econ_47"
Me.Econ_47.Size = New System.Drawing.Size(46, 23)
Me.Econ_47.TabIndex = 204
'
'Label93
'
Me.Label93.AutoSize = true
Me.Label93.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label93.Location = New System.Drawing.Point(448, 262)
Me.Label93.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label93.Name = "Label93"
Me.Label93.Size = New System.Drawing.Size(32, 16)
Me.Label93.TabIndex = 203
Me.Label93.Text = "保留"
'
'Econ_46
'
Me.Econ_46.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_46.Location = New System.Drawing.Point(513, 255)
Me.Econ_46.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_46.Name = "Econ_46"
Me.Econ_46.Size = New System.Drawing.Size(46, 23)
Me.Econ_46.TabIndex = 202
'
'Label94
'
Me.Label94.AutoSize = true
Me.Label94.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label94.Location = New System.Drawing.Point(450, 225)
Me.Label94.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label94.Name = "Label94"
Me.Label94.Size = New System.Drawing.Size(32, 16)
Me.Label94.TabIndex = 201
Me.Label94.Text = "保留"
'
'Econ_45
'
Me.Econ_45.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_45.Location = New System.Drawing.Point(513, 217)
Me.Econ_45.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_45.Name = "Econ_45"
Me.Econ_45.Size = New System.Drawing.Size(46, 23)
Me.Econ_45.TabIndex = 200
'
'Label95
'
Me.Label95.AutoSize = true
Me.Label95.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label95.Location = New System.Drawing.Point(448, 188)
Me.Label95.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label95.Name = "Label95"
Me.Label95.Size = New System.Drawing.Size(32, 16)
Me.Label95.TabIndex = 199
Me.Label95.Text = "保留"
'
'Econ_44
'
Me.Econ_44.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_44.Location = New System.Drawing.Point(513, 180)
Me.Econ_44.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_44.Name = "Econ_44"
Me.Econ_44.Size = New System.Drawing.Size(46, 23)
Me.Econ_44.TabIndex = 198
'
'Label96
'
Me.Label96.AutoSize = true
Me.Label96.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label96.Location = New System.Drawing.Point(448, 150)
Me.Label96.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label96.Name = "Label96"
Me.Label96.Size = New System.Drawing.Size(32, 16)
Me.Label96.TabIndex = 197
Me.Label96.Text = "輸出"
'
'Econ_43
'
Me.Econ_43.AcceptsReturn = true
Me.Econ_43.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_43.Location = New System.Drawing.Point(513, 143)
Me.Econ_43.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_43.Name = "Econ_43"
Me.Econ_43.Size = New System.Drawing.Size(46, 23)
Me.Econ_43.TabIndex = 196
'
'Label97
'
Me.Label97.AutoSize = true
Me.Label97.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label97.Location = New System.Drawing.Point(448, 112)
Me.Label97.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label97.Name = "Label97"
Me.Label97.Size = New System.Drawing.Size(41, 16)
Me.Label97.TabIndex = 195
Me.Label97.Text = "IL誤差"
'
'Econ_42
'
Me.Econ_42.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_42.Location = New System.Drawing.Point(513, 105)
Me.Econ_42.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_42.Name = "Econ_42"
Me.Econ_42.Size = New System.Drawing.Size(46, 23)
Me.Econ_42.TabIndex = 194
'
'Label98
'
Me.Label98.AutoSize = true
Me.Label98.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label98.Location = New System.Drawing.Point(448, 75)
Me.Label98.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label98.Name = "Label98"
Me.Label98.Size = New System.Drawing.Size(55, 16)
Me.Label98.TabIndex = 193
Me.Label98.Text = "BCR誤差"
'
'Econ_41
'
Me.Econ_41.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_41.Location = New System.Drawing.Point(513, 68)
Me.Econ_41.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_41.Name = "Econ_41"
Me.Econ_41.Size = New System.Drawing.Size(46, 23)
Me.Econ_41.TabIndex = 192
'
'Label99
'
Me.Label99.AutoSize = true
Me.Label99.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label99.Location = New System.Drawing.Point(448, 37)
Me.Label99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label99.Name = "Label99"
Me.Label99.Size = New System.Drawing.Size(55, 16)
Me.Label99.TabIndex = 191
Me.Label99.Text = "BCR誤差"
'
'Econ_40
'
Me.Econ_40.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_40.Location = New System.Drawing.Point(513, 30)
Me.Econ_40.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_40.Name = "Econ_40"
Me.Econ_40.Size = New System.Drawing.Size(46, 23)
Me.Econ_40.TabIndex = 190
'
'Label87
'
Me.Label87.AutoSize = true
Me.Label87.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label87.Location = New System.Drawing.Point(345, 375)
Me.Label87.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label87.Name = "Label87"
Me.Label87.Size = New System.Drawing.Size(41, 16)
Me.Label87.TabIndex = 189
Me.Label87.Text = "右側IL"
'
'Econ_39
'
Me.Econ_39.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_39.Location = New System.Drawing.Point(394, 368)
Me.Econ_39.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_39.Name = "Econ_39"
Me.Econ_39.Size = New System.Drawing.Size(46, 23)
Me.Econ_39.TabIndex = 188
'
'Label86
'
Me.Label86.AutoSize = true
Me.Label86.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label86.Location = New System.Drawing.Point(345, 338)
Me.Label86.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label86.Name = "Label86"
Me.Label86.Size = New System.Drawing.Size(41, 16)
Me.Label86.TabIndex = 187
Me.Label86.Text = "右側IL"
'
'Econ_38
'
Me.Econ_38.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_38.Location = New System.Drawing.Point(394, 330)
Me.Econ_38.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_38.Name = "Econ_38"
Me.Econ_38.Size = New System.Drawing.Size(46, 23)
Me.Econ_38.TabIndex = 186
'
'Label85
'
Me.Label85.AutoSize = true
Me.Label85.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label85.Location = New System.Drawing.Point(345, 300)
Me.Label85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label85.Name = "Label85"
Me.Label85.Size = New System.Drawing.Size(41, 16)
Me.Label85.TabIndex = 185
Me.Label85.Text = "左側IL"
'
'Econ_37
'
Me.Econ_37.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_37.Location = New System.Drawing.Point(394, 292)
Me.Econ_37.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_37.Name = "Econ_37"
Me.Econ_37.Size = New System.Drawing.Size(46, 23)
Me.Econ_37.TabIndex = 184
'
'Label84
'
Me.Label84.AutoSize = true
Me.Label84.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label84.Location = New System.Drawing.Point(345, 262)
Me.Label84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label84.Name = "Label84"
Me.Label84.Size = New System.Drawing.Size(41, 16)
Me.Label84.TabIndex = 183
Me.Label84.Text = "左側IL"
'
'Econ_36
'
Me.Econ_36.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_36.Location = New System.Drawing.Point(394, 255)
Me.Econ_36.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_36.Name = "Econ_36"
Me.Econ_36.Size = New System.Drawing.Size(46, 23)
Me.Econ_36.TabIndex = 182
'
'Label83
'
Me.Label83.AutoSize = true
Me.Label83.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label83.Location = New System.Drawing.Point(345, 225)
Me.Label83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label83.Name = "Label83"
Me.Label83.Size = New System.Drawing.Size(38, 16)
Me.Label83.TabIndex = 181
Me.Label83.Text = "BCRY"
'
'Econ_35
'
Me.Econ_35.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_35.Location = New System.Drawing.Point(394, 217)
Me.Econ_35.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_35.Name = "Econ_35"
Me.Econ_35.Size = New System.Drawing.Size(46, 23)
Me.Econ_35.TabIndex = 180
'
'Label82
'
Me.Label82.AutoSize = true
Me.Label82.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label82.Location = New System.Drawing.Point(345, 188)
Me.Label82.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label82.Name = "Label82"
Me.Label82.Size = New System.Drawing.Size(39, 16)
Me.Label82.TabIndex = 179
Me.Label82.Text = "BCRX"
'
'Econ_34
'
Me.Econ_34.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_34.Location = New System.Drawing.Point(394, 180)
Me.Econ_34.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_34.Name = "Econ_34"
Me.Econ_34.Size = New System.Drawing.Size(46, 23)
Me.Econ_34.TabIndex = 178
'
'Label81
'
Me.Label81.AutoSize = true
Me.Label81.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label81.Location = New System.Drawing.Point(345, 150)
Me.Label81.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label81.Name = "Label81"
Me.Label81.Size = New System.Drawing.Size(32, 16)
Me.Label81.TabIndex = 177
Me.Label81.Text = "輸出"
'
'Econ_33
'
Me.Econ_33.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_33.Location = New System.Drawing.Point(394, 143)
Me.Econ_33.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_33.Name = "Econ_33"
Me.Econ_33.Size = New System.Drawing.Size(46, 23)
Me.Econ_33.TabIndex = 176
'
'Label64
'
Me.Label64.AutoSize = true
Me.Label64.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label64.Location = New System.Drawing.Point(345, 112)
Me.Label64.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label64.Name = "Label64"
Me.Label64.Size = New System.Drawing.Size(39, 16)
Me.Label64.TabIndex = 175
Me.Label64.Text = "輸入3"
'
'Econ_32
'
Me.Econ_32.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_32.Location = New System.Drawing.Point(394, 105)
Me.Econ_32.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_32.Name = "Econ_32"
Me.Econ_32.Size = New System.Drawing.Size(46, 23)
Me.Econ_32.TabIndex = 174
'
'Label60
'
Me.Label60.AutoSize = true
Me.Label60.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label60.Location = New System.Drawing.Point(345, 75)
Me.Label60.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label60.Name = "Label60"
Me.Label60.Size = New System.Drawing.Size(39, 16)
Me.Label60.TabIndex = 173
Me.Label60.Text = "輸入2"
'
'Econ_31
'
Me.Econ_31.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_31.Location = New System.Drawing.Point(394, 68)
Me.Econ_31.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_31.Name = "Econ_31"
Me.Econ_31.Size = New System.Drawing.Size(46, 23)
Me.Econ_31.TabIndex = 172
'
'Label80
'
Me.Label80.AutoSize = true
Me.Label80.Location = New System.Drawing.Point(499, 570)
Me.Label80.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label80.Name = "Label80"
Me.Label80.Size = New System.Drawing.Size(30, 16)
Me.Label80.TabIndex = 171
Me.Label80.Text = "CST"
'
'CstID
'
Me.CstID.Location = New System.Drawing.Point(572, 562)
Me.CstID.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.CstID.Name = "CstID"
Me.CstID.Size = New System.Drawing.Size(100, 23)
Me.CstID.TabIndex = 170
'
'Label69
'
Me.Label69.AutoSize = true
Me.Label69.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label69.Location = New System.Drawing.Point(345, 37)
Me.Label69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label69.Name = "Label69"
Me.Label69.Size = New System.Drawing.Size(39, 16)
Me.Label69.TabIndex = 169
Me.Label69.Text = "輸入1"
'
'Label70
'
Me.Label70.AutoSize = true
Me.Label70.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label70.Location = New System.Drawing.Point(259, 375)
Me.Label70.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label70.Name = "Label70"
Me.Label70.Size = New System.Drawing.Size(30, 16)
Me.Label70.TabIndex = 168
Me.Label70.Text = "CST"
'
'Econ_30
'
Me.Econ_30.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_30.Location = New System.Drawing.Point(394, 30)
Me.Econ_30.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_30.Name = "Econ_30"
Me.Econ_30.Size = New System.Drawing.Size(46, 23)
Me.Econ_30.TabIndex = 167
'
'Econ_29
'
Me.Econ_29.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_29.Location = New System.Drawing.Point(294, 368)
Me.Econ_29.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_29.Name = "Econ_29"
Me.Econ_29.Size = New System.Drawing.Size(46, 23)
Me.Econ_29.TabIndex = 166
'
'Label71
'
Me.Label71.AutoSize = true
Me.Label71.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label71.Location = New System.Drawing.Point(259, 338)
Me.Label71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label71.Name = "Label71"
Me.Label71.Size = New System.Drawing.Size(30, 16)
Me.Label71.TabIndex = 165
Me.Label71.Text = "CST"
'
'Econ_28
'
Me.Econ_28.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_28.Location = New System.Drawing.Point(294, 330)
Me.Econ_28.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_28.Name = "Econ_28"
Me.Econ_28.Size = New System.Drawing.Size(46, 23)
Me.Econ_28.TabIndex = 164
'
'Label73
'
Me.Label73.AutoSize = true
Me.Label73.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label73.Location = New System.Drawing.Point(259, 300)
Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label73.Name = "Label73"
Me.Label73.Size = New System.Drawing.Size(30, 16)
Me.Label73.TabIndex = 162
Me.Label73.Text = "CST"
'
'Label74
'
Me.Label74.AutoSize = true
Me.Label74.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label74.Location = New System.Drawing.Point(259, 262)
Me.Label74.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label74.Name = "Label74"
Me.Label74.Size = New System.Drawing.Size(30, 16)
Me.Label74.TabIndex = 161
Me.Label74.Text = "CST"
'
'Label75
'
Me.Label75.AutoSize = true
Me.Label75.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label75.Location = New System.Drawing.Point(259, 225)
Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label75.Name = "Label75"
Me.Label75.Size = New System.Drawing.Size(19, 16)
Me.Label75.TabIndex = 160
Me.Label75.Text = "th"
'
'Label76
'
Me.Label76.AutoSize = true
Me.Label76.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label76.Location = New System.Drawing.Point(259, 188)
Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label76.Name = "Label76"
Me.Label76.Size = New System.Drawing.Size(15, 16)
Me.Label76.TabIndex = 159
Me.Label76.Text = "Y"
'
'Label77
'
Me.Label77.AutoSize = true
Me.Label77.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label77.Location = New System.Drawing.Point(259, 150)
Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label77.Name = "Label77"
Me.Label77.Size = New System.Drawing.Size(16, 16)
Me.Label77.TabIndex = 158
Me.Label77.Text = "X"
'
'Label78
'
Me.Label78.AutoSize = true
Me.Label78.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label78.Location = New System.Drawing.Point(259, 112)
Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label78.Name = "Label78"
Me.Label78.Size = New System.Drawing.Size(32, 16)
Me.Label78.TabIndex = 157
Me.Label78.Text = "保留"
'
'Label79
'
Me.Label79.AutoSize = true
Me.Label79.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label79.Location = New System.Drawing.Point(259, 75)
Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label79.Name = "Label79"
Me.Label79.Size = New System.Drawing.Size(32, 16)
Me.Label79.TabIndex = 156
Me.Label79.Text = "溫度"
'
'Econ_27
'
Me.Econ_27.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_27.Location = New System.Drawing.Point(294, 292)
Me.Econ_27.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_27.Name = "Econ_27"
Me.Econ_27.Size = New System.Drawing.Size(46, 23)
Me.Econ_27.TabIndex = 154
'
'Econ_26
'
Me.Econ_26.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_26.Location = New System.Drawing.Point(294, 255)
Me.Econ_26.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_26.Name = "Econ_26"
Me.Econ_26.Size = New System.Drawing.Size(46, 23)
Me.Econ_26.TabIndex = 153
'
'Econ_25
'
Me.Econ_25.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_25.Location = New System.Drawing.Point(294, 217)
Me.Econ_25.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_25.Name = "Econ_25"
Me.Econ_25.Size = New System.Drawing.Size(46, 23)
Me.Econ_25.TabIndex = 152
'
'Econ_24
'
Me.Econ_24.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_24.Location = New System.Drawing.Point(294, 180)
Me.Econ_24.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_24.Name = "Econ_24"
Me.Econ_24.Size = New System.Drawing.Size(46, 23)
Me.Econ_24.TabIndex = 151
'
'Econ_23
'
Me.Econ_23.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_23.Location = New System.Drawing.Point(294, 143)
Me.Econ_23.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_23.Name = "Econ_23"
Me.Econ_23.Size = New System.Drawing.Size(46, 23)
Me.Econ_23.TabIndex = 150
'
'Econ_22
'
Me.Econ_22.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_22.Location = New System.Drawing.Point(294, 105)
Me.Econ_22.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_22.Name = "Econ_22"
Me.Econ_22.Size = New System.Drawing.Size(46, 23)
Me.Econ_22.TabIndex = 149
'
'Econ_21
'
Me.Econ_21.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_21.Location = New System.Drawing.Point(294, 68)
Me.Econ_21.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_21.Name = "Econ_21"
Me.Econ_21.Size = New System.Drawing.Size(46, 23)
Me.Econ_21.TabIndex = 148
'
'Label55
'
Me.Label55.AutoSize = true
Me.Label55.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label55.Location = New System.Drawing.Point(135, 375)
Me.Label55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label55.Name = "Label55"
Me.Label55.Size = New System.Drawing.Size(57, 16)
Me.Label55.TabIndex = 147
Me.Label55.Text = "AGV警報"
'
'Label54
'
Me.Label54.AutoSize = true
Me.Label54.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label54.Location = New System.Drawing.Point(135, 338)
Me.Label54.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label54.Name = "Label54"
Me.Label54.Size = New System.Drawing.Size(56, 16)
Me.Label54.TabIndex = 146
Me.Label54.Text = "上位異常"
'
'Econ_19
'
Me.Econ_19.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_19.Location = New System.Drawing.Point(203, 368)
Me.Econ_19.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_19.Name = "Econ_19"
Me.Econ_19.Size = New System.Drawing.Size(46, 23)
Me.Econ_19.TabIndex = 145
'
'Econ_18
'
Me.Econ_18.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_18.Location = New System.Drawing.Point(203, 330)
Me.Econ_18.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_18.Name = "Econ_18"
Me.Econ_18.Size = New System.Drawing.Size(46, 23)
Me.Econ_18.TabIndex = 144
'
'Label52
'
Me.Label52.AutoSize = true
Me.Label52.Location = New System.Drawing.Point(499, 532)
Me.Label52.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label52.Name = "Label52"
Me.Label52.Size = New System.Drawing.Size(61, 16)
Me.Label52.TabIndex = 143
Me.Label52.Text = "Temp_To"
'
'txtTemp_to
'
Me.txtTemp_to.Location = New System.Drawing.Point(572, 525)
Me.txtTemp_to.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtTemp_to.Name = "txtTemp_to"
Me.txtTemp_to.Size = New System.Drawing.Size(100, 23)
Me.txtTemp_to.TabIndex = 142
'
'Label51
'
Me.Label51.AutoSize = true
Me.Label51.Location = New System.Drawing.Point(9, 570)
Me.Label51.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label51.Name = "Label51"
Me.Label51.Size = New System.Drawing.Size(56, 16)
Me.Label51.TabIndex = 141
Me.Label51.Text = "路徑保留"
'
'strReserve_txt
'
Me.strReserve_txt.Location = New System.Drawing.Point(77, 562)
Me.strReserve_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.strReserve_txt.Name = "strReserve_txt"
Me.strReserve_txt.Size = New System.Drawing.Size(410, 23)
Me.strReserve_txt.TabIndex = 140
'
'Label50
'
Me.Label50.AutoSize = true
Me.Label50.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label50.Location = New System.Drawing.Point(898, 37)
Me.Label50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label50.Name = "Label50"
Me.Label50.Size = New System.Drawing.Size(56, 16)
Me.Label50.TabIndex = 139
Me.Label50.Text = "上位異常"
'
'Label48
'
Me.Label48.AutoSize = true
Me.Label48.Location = New System.Drawing.Point(499, 495)
Me.Label48.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label48.Name = "Label48"
Me.Label48.Size = New System.Drawing.Size(23, 16)
Me.Label48.TabIndex = 138
Me.Label48.Text = "To"
'
'Label49
'
Me.Label49.AutoSize = true
Me.Label49.Location = New System.Drawing.Point(499, 458)
Me.Label49.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label49.Name = "Label49"
Me.Label49.Size = New System.Drawing.Size(37, 16)
Me.Label49.TabIndex = 137
Me.Label49.Text = "From"
'
'txtFrom
'
Me.txtFrom.Location = New System.Drawing.Point(572, 450)
Me.txtFrom.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtFrom.Name = "txtFrom"
Me.txtFrom.Size = New System.Drawing.Size(100, 23)
Me.txtFrom.TabIndex = 136
'
'txtTo
'
Me.txtTo.Location = New System.Drawing.Point(572, 487)
Me.txtTo.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtTo.Name = "txtTo"
Me.txtTo.Size = New System.Drawing.Size(100, 23)
Me.txtTo.TabIndex = 135
'
'txtToAGV20
'
Me.txtToAGV20.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV20.Location = New System.Drawing.Point(968, 30)
Me.txtToAGV20.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV20.Name = "txtToAGV20"
Me.txtToAGV20.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV20.TabIndex = 134
'
'Label41
'
Me.Label41.AutoSize = true
Me.Label41.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label41.Location = New System.Drawing.Point(777, 375)
Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label41.Name = "Label41"
Me.Label41.Size = New System.Drawing.Size(56, 16)
Me.Label41.TabIndex = 133
Me.Label41.Text = "手動後進"
'
'Label42
'
Me.Label42.AutoSize = true
Me.Label42.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label42.Location = New System.Drawing.Point(777, 338)
Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label42.Name = "Label42"
Me.Label42.Size = New System.Drawing.Size(56, 16)
Me.Label42.TabIndex = 132
Me.Label42.Text = "手動前進"
'
'Label43
'
Me.Label43.AutoSize = true
Me.Label43.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label43.Location = New System.Drawing.Point(777, 300)
Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label43.Name = "Label43"
Me.Label43.Size = New System.Drawing.Size(32, 16)
Me.Label43.TabIndex = 131
Me.Label43.Text = "保留"
'
'Label44
'
Me.Label44.AutoSize = true
Me.Label44.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label44.Location = New System.Drawing.Point(777, 262)
Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label44.Name = "Label44"
Me.Label44.Size = New System.Drawing.Size(32, 16)
Me.Label44.TabIndex = 130
Me.Label44.Text = "保留"
'
'Label45
'
Me.Label45.AutoSize = true
Me.Label45.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label45.Location = New System.Drawing.Point(777, 225)
Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label45.Name = "Label45"
Me.Label45.Size = New System.Drawing.Size(57, 16)
Me.Label45.TabIndex = 129
Me.Label45.Text = "命令AGV"
'
'Label36
'
Me.Label36.AutoSize = true
Me.Label36.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label36.Location = New System.Drawing.Point(777, 188)
Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label36.Name = "Label36"
Me.Label36.Size = New System.Drawing.Size(56, 16)
Me.Label36.TabIndex = 128
Me.Label36.Text = "下達路徑"
'
'Label37
'
Me.Label37.AutoSize = true
Me.Label37.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label37.Location = New System.Drawing.Point(777, 150)
Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label37.Name = "Label37"
Me.Label37.Size = New System.Drawing.Size(56, 16)
Me.Label37.TabIndex = 127
Me.Label37.Text = "路徑地圖"
'
'Label38
'
Me.Label38.AutoSize = true
Me.Label38.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label38.Location = New System.Drawing.Point(777, 112)
Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label38.Name = "Label38"
Me.Label38.Size = New System.Drawing.Size(32, 16)
Me.Label38.TabIndex = 126
Me.Label38.Text = "保留"
'
'Label39
'
Me.Label39.AutoSize = true
Me.Label39.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label39.Location = New System.Drawing.Point(777, 75)
Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label39.Name = "Label39"
Me.Label39.Size = New System.Drawing.Size(32, 16)
Me.Label39.TabIndex = 125
Me.Label39.Text = "保留"
'
'Label40
'
Me.Label40.AutoSize = true
Me.Label40.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label40.Location = New System.Drawing.Point(777, 37)
Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label40.Name = "Label40"
Me.Label40.Size = New System.Drawing.Size(32, 16)
Me.Label40.TabIndex = 124
Me.Label40.Text = "保留"
'
'Label25
'
Me.Label25.AutoSize = true
Me.Label25.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label25.Location = New System.Drawing.Point(644, 375)
Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label25.Name = "Label25"
Me.Label25.Size = New System.Drawing.Size(30, 16)
Me.Label25.TabIndex = 123
Me.Label25.Text = "CST"
'
'Label26
'
Me.Label26.AutoSize = true
Me.Label26.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label26.Location = New System.Drawing.Point(644, 338)
Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label26.Name = "Label26"
Me.Label26.Size = New System.Drawing.Size(30, 16)
Me.Label26.TabIndex = 122
Me.Label26.Text = "CST"
'
'Label33
'
Me.Label33.AutoSize = true
Me.Label33.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label33.Location = New System.Drawing.Point(644, 300)
Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label33.Name = "Label33"
Me.Label33.Size = New System.Drawing.Size(30, 16)
Me.Label33.TabIndex = 121
Me.Label33.Text = "CST"
'
'Label34
'
Me.Label34.AutoSize = true
Me.Label34.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label34.Location = New System.Drawing.Point(644, 262)
Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label34.Name = "Label34"
Me.Label34.Size = New System.Drawing.Size(56, 16)
Me.Label34.TabIndex = 120
Me.Label34.Text = "搬送命令"
'
'Label35
'
Me.Label35.AutoSize = true
Me.Label35.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label35.Location = New System.Drawing.Point(644, 225)
Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label35.Name = "Label35"
Me.Label35.Size = New System.Drawing.Size(61, 16)
Me.Label35.TabIndex = 119
Me.Label35.Text = "自動/手動"
'
'txtToAGV18
'
Me.txtToAGV18.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV18.Location = New System.Drawing.Point(842, 330)
Me.txtToAGV18.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV18.Name = "txtToAGV18"
Me.txtToAGV18.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV18.TabIndex = 118
'
'txtToAGV19
'
Me.txtToAGV19.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV19.Location = New System.Drawing.Point(842, 368)
Me.txtToAGV19.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV19.Name = "txtToAGV19"
Me.txtToAGV19.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV19.TabIndex = 117
'
'txtToAGV17
'
Me.txtToAGV17.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV17.Location = New System.Drawing.Point(842, 292)
Me.txtToAGV17.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV17.Name = "txtToAGV17"
Me.txtToAGV17.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV17.TabIndex = 116
'
'txtToAGV16
'
Me.txtToAGV16.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV16.Location = New System.Drawing.Point(842, 255)
Me.txtToAGV16.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV16.Name = "txtToAGV16"
Me.txtToAGV16.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV16.TabIndex = 115
'
'txtToAGV15
'
Me.txtToAGV15.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV15.Location = New System.Drawing.Point(842, 217)
Me.txtToAGV15.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV15.Name = "txtToAGV15"
Me.txtToAGV15.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV15.TabIndex = 114
'
'txtToAGV13
'
Me.txtToAGV13.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV13.Location = New System.Drawing.Point(842, 143)
Me.txtToAGV13.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV13.Name = "txtToAGV13"
Me.txtToAGV13.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV13.TabIndex = 113
'
'txtToAGV14
'
Me.txtToAGV14.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV14.Location = New System.Drawing.Point(842, 180)
Me.txtToAGV14.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV14.Name = "txtToAGV14"
Me.txtToAGV14.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV14.TabIndex = 112
'
'txtToAGV12
'
Me.txtToAGV12.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV12.Location = New System.Drawing.Point(842, 105)
Me.txtToAGV12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV12.Name = "txtToAGV12"
Me.txtToAGV12.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV12.TabIndex = 111
'
'txtToAGV11
'
Me.txtToAGV11.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV11.Location = New System.Drawing.Point(842, 68)
Me.txtToAGV11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV11.Name = "txtToAGV11"
Me.txtToAGV11.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV11.TabIndex = 110
'
'txtToAGV10
'
Me.txtToAGV10.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV10.Location = New System.Drawing.Point(842, 30)
Me.txtToAGV10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV10.Name = "txtToAGV10"
Me.txtToAGV10.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV10.TabIndex = 109
'
'txtToAGV9
'
Me.txtToAGV9.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV9.Location = New System.Drawing.Point(716, 368)
Me.txtToAGV9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV9.Name = "txtToAGV9"
Me.txtToAGV9.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV9.TabIndex = 108
'
'txtToAGV0
'
Me.txtToAGV0.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV0.Location = New System.Drawing.Point(716, 30)
Me.txtToAGV0.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV0.Name = "txtToAGV0"
Me.txtToAGV0.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV0.TabIndex = 107
'
'txtToAGV8
'
Me.txtToAGV8.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV8.Location = New System.Drawing.Point(716, 330)
Me.txtToAGV8.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV8.Name = "txtToAGV8"
Me.txtToAGV8.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV8.TabIndex = 106
'
'txtToAGV7
'
Me.txtToAGV7.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV7.Location = New System.Drawing.Point(716, 292)
Me.txtToAGV7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV7.Name = "txtToAGV7"
Me.txtToAGV7.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV7.TabIndex = 105
'
'txtToAGV6
'
Me.txtToAGV6.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV6.Location = New System.Drawing.Point(716, 255)
Me.txtToAGV6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV6.Name = "txtToAGV6"
Me.txtToAGV6.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV6.TabIndex = 104
'
'Label32
'
Me.Label32.AutoSize = true
Me.Label32.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label32.Location = New System.Drawing.Point(135, 300)
Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label32.Name = "Label32"
Me.Label32.Size = New System.Drawing.Size(56, 16)
Me.Label32.TabIndex = 103
Me.Label32.Text = "架台編號"
'
'Econ_17
'
Me.Econ_17.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_17.Location = New System.Drawing.Point(203, 292)
Me.Econ_17.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_17.Name = "Econ_17"
Me.Econ_17.Size = New System.Drawing.Size(46, 23)
Me.Econ_17.TabIndex = 102
'
'Label29
'
Me.Label29.AutoSize = true
Me.Label29.Location = New System.Drawing.Point(9, 532)
Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label29.Name = "Label29"
Me.Label29.Size = New System.Drawing.Size(35, 16)
Me.Label29.TabIndex = 101
Me.Label29.Text = "Cmd"
'
'WorkList
'
Me.WorkList.Location = New System.Drawing.Point(77, 525)
Me.WorkList.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.WorkList.Name = "WorkList"
Me.WorkList.Size = New System.Drawing.Size(410, 23)
Me.WorkList.TabIndex = 100
'
'Label27
'
Me.Label27.AutoSize = true
Me.Label27.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label27.Location = New System.Drawing.Point(644, 188)
Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label27.Name = "Label27"
Me.Label27.Size = New System.Drawing.Size(32, 16)
Me.Label27.TabIndex = 99
Me.Label27.Text = "保留"
'
'Label28
'
Me.Label28.AutoSize = true
Me.Label28.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label28.Location = New System.Drawing.Point(644, 150)
Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label28.Name = "Label28"
Me.Label28.Size = New System.Drawing.Size(32, 16)
Me.Label28.TabIndex = 98
Me.Label28.Text = "保留"
'
'txtToAGV4
'
Me.txtToAGV4.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV4.Location = New System.Drawing.Point(716, 180)
Me.txtToAGV4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV4.Name = "txtToAGV4"
Me.txtToAGV4.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV4.TabIndex = 97
'
'txtToAGV5
'
Me.txtToAGV5.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV5.Location = New System.Drawing.Point(716, 217)
Me.txtToAGV5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV5.Name = "txtToAGV5"
Me.txtToAGV5.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV5.TabIndex = 96
'
'Label23
'
Me.Label23.AutoSize = true
Me.Label23.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label23.Location = New System.Drawing.Point(644, 112)
Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label23.Name = "Label23"
Me.Label23.Size = New System.Drawing.Size(32, 16)
Me.Label23.TabIndex = 95
Me.Label23.Text = "保留"
'
'Label22
'
Me.Label22.AutoSize = true
Me.Label22.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label22.Location = New System.Drawing.Point(644, 75)
Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label22.Name = "Label22"
Me.Label22.Size = New System.Drawing.Size(32, 16)
Me.Label22.TabIndex = 94
Me.Label22.Text = "目的"
'
'Label21
'
Me.Label21.AutoSize = true
Me.Label21.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label21.Location = New System.Drawing.Point(644, 37)
Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label21.Name = "Label21"
Me.Label21.Size = New System.Drawing.Size(50, 16)
Me.Label21.TabIndex = 93
Me.Label21.Text = "Hart bit"
'
'txtToAGV3
'
Me.txtToAGV3.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV3.Location = New System.Drawing.Point(716, 143)
Me.txtToAGV3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV3.Name = "txtToAGV3"
Me.txtToAGV3.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV3.TabIndex = 92
'
'txtToAGV2
'
Me.txtToAGV2.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV2.Location = New System.Drawing.Point(716, 105)
Me.txtToAGV2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV2.Name = "txtToAGV2"
Me.txtToAGV2.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV2.TabIndex = 91
'
'txtToAGV1
'
Me.txtToAGV1.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.txtToAGV1.Location = New System.Drawing.Point(716, 68)
Me.txtToAGV1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtToAGV1.Name = "txtToAGV1"
Me.txtToAGV1.Size = New System.Drawing.Size(46, 23)
Me.txtToAGV1.TabIndex = 90
'
'Label12
'
Me.Label12.AutoSize = true
Me.Label12.Location = New System.Drawing.Point(9, 495)
Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label12.Name = "Label12"
Me.Label12.Size = New System.Drawing.Size(32, 16)
Me.Label12.TabIndex = 87
Me.Label12.Text = "動作"
'
'Label11
'
Me.Label11.AutoSize = true
Me.Label11.Location = New System.Drawing.Point(9, 458)
Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label11.Name = "Label11"
Me.Label11.Size = New System.Drawing.Size(41, 16)
Me.Label11.TabIndex = 86
Me.Label11.Text = "TagId"
'
'TextBox2
'
Me.TextBox2.Location = New System.Drawing.Point(77, 487)
Me.TextBox2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TextBox2.Name = "TextBox2"
Me.TextBox2.Size = New System.Drawing.Size(410, 23)
Me.TextBox2.TabIndex = 85
'
'TextBox1
'
Me.TextBox1.Location = New System.Drawing.Point(77, 450)
Me.TextBox1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TextBox1.Name = "TextBox1"
Me.TextBox1.Size = New System.Drawing.Size(410, 23)
Me.TextBox1.TabIndex = 84
'
'Label13
'
Me.Label13.AutoSize = true
Me.Label13.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label13.Location = New System.Drawing.Point(259, 37)
Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label13.Name = "Label13"
Me.Label13.Size = New System.Drawing.Size(32, 16)
Me.Label13.TabIndex = 77
Me.Label13.Text = "異常"
'
'Label14
'
Me.Label14.AutoSize = true
Me.Label14.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label14.Location = New System.Drawing.Point(135, 262)
Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label14.Name = "Label14"
Me.Label14.Size = New System.Drawing.Size(56, 16)
Me.Label14.TabIndex = 76
Me.Label14.Text = "目前位置"
'
'Label15
'
Me.Label15.AutoSize = true
Me.Label15.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label15.Location = New System.Drawing.Point(135, 225)
Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label15.Name = "Label15"
Me.Label15.Size = New System.Drawing.Size(57, 16)
Me.Label15.TabIndex = 75
Me.Label15.Text = "AGV狀態"
'
'Label16
'
Me.Label16.AutoSize = true
Me.Label16.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label16.Location = New System.Drawing.Point(135, 188)
Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label16.Name = "Label16"
Me.Label16.Size = New System.Drawing.Size(56, 16)
Me.Label16.TabIndex = 74
Me.Label16.Text = "目前命令"
'
'Label17
'
Me.Label17.AutoSize = true
Me.Label17.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label17.Location = New System.Drawing.Point(135, 150)
Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label17.Name = "Label17"
Me.Label17.Size = New System.Drawing.Size(56, 16)
Me.Label17.TabIndex = 73
Me.Label17.Text = "地圖傳送"
'
'Label18
'
Me.Label18.AutoSize = true
Me.Label18.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label18.Location = New System.Drawing.Point(135, 112)
Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label18.Name = "Label18"
Me.Label18.Size = New System.Drawing.Size(49, 16)
Me.Label18.TabIndex = 72
Me.Label18.Text = "里程km"
'
'Label19
'
Me.Label19.AutoSize = true
Me.Label19.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label19.Location = New System.Drawing.Point(135, 75)
Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label19.Name = "Label19"
Me.Label19.Size = New System.Drawing.Size(43, 16)
Me.Label19.TabIndex = 71
Me.Label19.Text = "里程m"
'
'Label20
'
Me.Label20.AutoSize = true
Me.Label20.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label20.Location = New System.Drawing.Point(135, 37)
Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label20.Name = "Label20"
Me.Label20.Size = New System.Drawing.Size(56, 16)
Me.Label20.TabIndex = 70
Me.Label20.Text = "電池電壓"
'
'Econ_20
'
Me.Econ_20.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_20.Location = New System.Drawing.Point(294, 30)
Me.Econ_20.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_20.Name = "Econ_20"
Me.Econ_20.Size = New System.Drawing.Size(46, 23)
Me.Econ_20.TabIndex = 69
'
'Econ_16
'
Me.Econ_16.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_16.Location = New System.Drawing.Point(203, 255)
Me.Econ_16.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_16.Name = "Econ_16"
Me.Econ_16.Size = New System.Drawing.Size(46, 23)
Me.Econ_16.TabIndex = 68
'
'Econ_15
'
Me.Econ_15.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_15.Location = New System.Drawing.Point(203, 217)
Me.Econ_15.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_15.Name = "Econ_15"
Me.Econ_15.Size = New System.Drawing.Size(46, 23)
Me.Econ_15.TabIndex = 67
'
'Econ_14
'
Me.Econ_14.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_14.Location = New System.Drawing.Point(203, 180)
Me.Econ_14.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_14.Name = "Econ_14"
Me.Econ_14.Size = New System.Drawing.Size(46, 23)
Me.Econ_14.TabIndex = 66
'
'Econ_13
'
Me.Econ_13.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_13.Location = New System.Drawing.Point(203, 143)
Me.Econ_13.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_13.Name = "Econ_13"
Me.Econ_13.Size = New System.Drawing.Size(46, 23)
Me.Econ_13.TabIndex = 65
'
'Econ_12
'
Me.Econ_12.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_12.Location = New System.Drawing.Point(203, 105)
Me.Econ_12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_12.Name = "Econ_12"
Me.Econ_12.Size = New System.Drawing.Size(46, 23)
Me.Econ_12.TabIndex = 64
'
'Econ_11
'
Me.Econ_11.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_11.Location = New System.Drawing.Point(203, 68)
Me.Econ_11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_11.Name = "Econ_11"
Me.Econ_11.Size = New System.Drawing.Size(46, 23)
Me.Econ_11.TabIndex = 63
'
'Econ_10
'
Me.Econ_10.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_10.Location = New System.Drawing.Point(203, 30)
Me.Econ_10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_10.Name = "Econ_10"
Me.Econ_10.Size = New System.Drawing.Size(46, 23)
Me.Econ_10.TabIndex = 62
'
'Label10
'
Me.Label10.AutoSize = true
Me.Label10.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label10.Location = New System.Drawing.Point(7, 375)
Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label10.Name = "Label10"
Me.Label10.Size = New System.Drawing.Size(32, 16)
Me.Label10.TabIndex = 61
Me.Label10.Text = "交握"
'
'Label9
'
Me.Label9.AutoSize = true
Me.Label9.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label9.Location = New System.Drawing.Point(7, 338)
Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label9.Name = "Label9"
Me.Label9.Size = New System.Drawing.Size(40, 16)
Me.Label9.TabIndex = 60
Me.Label9.Text = "頂PIN"
'
'Label5
'
Me.Label5.AutoSize = true
Me.Label5.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label5.Location = New System.Drawing.Point(7, 300)
Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label5.Name = "Label5"
Me.Label5.Size = New System.Drawing.Size(56, 16)
Me.Label5.TabIndex = 59
Me.Label5.Text = "物料感應"
'
'Label6
'
Me.Label6.AutoSize = true
Me.Label6.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label6.Location = New System.Drawing.Point(7, 262)
Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label6.Name = "Label6"
Me.Label6.Size = New System.Drawing.Size(56, 16)
Me.Label6.TabIndex = 58
Me.Label6.Text = "搬送命令"
'
'Label7
'
Me.Label7.AutoSize = true
Me.Label7.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label7.Location = New System.Drawing.Point(7, 225)
Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label7.Name = "Label7"
Me.Label7.Size = New System.Drawing.Size(61, 16)
Me.Label7.TabIndex = 57
Me.Label7.Text = "自動/手動"
'
'Label8
'
Me.Label8.AutoSize = true
Me.Label8.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label8.Location = New System.Drawing.Point(7, 188)
Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label8.Name = "Label8"
Me.Label8.Size = New System.Drawing.Size(44, 16)
Me.Label8.TabIndex = 56
Me.Label8.Text = "障礙物"
'
'Label4
'
Me.Label4.AutoSize = true
Me.Label4.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label4.Location = New System.Drawing.Point(7, 150)
Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label4.Name = "Label4"
Me.Label4.Size = New System.Drawing.Size(56, 16)
Me.Label4.TabIndex = 55
Me.Label4.Text = "走行速度"
'
'Label3
'
Me.Label3.AutoSize = true
Me.Label3.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label3.Location = New System.Drawing.Point(7, 112)
Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label3.Name = "Label3"
Me.Label3.Size = New System.Drawing.Size(56, 16)
Me.Label3.TabIndex = 54
Me.Label3.Text = "走行動作"
'
'Label2
'
Me.Label2.AutoSize = true
Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label2.Location = New System.Drawing.Point(7, 75)
Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label2.Name = "Label2"
Me.Label2.Size = New System.Drawing.Size(56, 16)
Me.Label2.TabIndex = 53
Me.Label2.Text = "走行方向"
'
'Label1
'
Me.Label1.AutoSize = true
Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Label1.Location = New System.Drawing.Point(7, 37)
Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(50, 16)
Me.Label1.TabIndex = 52
Me.Label1.Text = "Hart bit"
'
'Econ_9
'
Me.Econ_9.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_9.Location = New System.Drawing.Point(77, 368)
Me.Econ_9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_9.Name = "Econ_9"
Me.Econ_9.Size = New System.Drawing.Size(46, 23)
Me.Econ_9.TabIndex = 51
'
'Econ_8
'
Me.Econ_8.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_8.Location = New System.Drawing.Point(77, 330)
Me.Econ_8.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_8.Name = "Econ_8"
Me.Econ_8.Size = New System.Drawing.Size(46, 23)
Me.Econ_8.TabIndex = 50
'
'Econ_7
'
Me.Econ_7.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_7.Location = New System.Drawing.Point(77, 292)
Me.Econ_7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_7.Name = "Econ_7"
Me.Econ_7.Size = New System.Drawing.Size(46, 23)
Me.Econ_7.TabIndex = 49
'
'Econ_6
'
Me.Econ_6.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_6.Location = New System.Drawing.Point(77, 255)
Me.Econ_6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_6.Name = "Econ_6"
Me.Econ_6.Size = New System.Drawing.Size(46, 23)
Me.Econ_6.TabIndex = 48
'
'Econ_5
'
Me.Econ_5.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_5.Location = New System.Drawing.Point(77, 217)
Me.Econ_5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_5.Name = "Econ_5"
Me.Econ_5.Size = New System.Drawing.Size(46, 23)
Me.Econ_5.TabIndex = 47
'
'Econ_4
'
Me.Econ_4.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_4.Location = New System.Drawing.Point(77, 180)
Me.Econ_4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_4.Name = "Econ_4"
Me.Econ_4.Size = New System.Drawing.Size(46, 23)
Me.Econ_4.TabIndex = 46
'
'Econ_3
'
Me.Econ_3.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_3.Location = New System.Drawing.Point(77, 143)
Me.Econ_3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_3.Name = "Econ_3"
Me.Econ_3.Size = New System.Drawing.Size(46, 23)
Me.Econ_3.TabIndex = 45
'
'Econ_2
'
Me.Econ_2.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_2.Location = New System.Drawing.Point(77, 105)
Me.Econ_2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_2.Name = "Econ_2"
Me.Econ_2.Size = New System.Drawing.Size(46, 23)
Me.Econ_2.TabIndex = 44
'
'Econ_1
'
Me.Econ_1.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_1.Location = New System.Drawing.Point(77, 68)
Me.Econ_1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_1.Name = "Econ_1"
Me.Econ_1.Size = New System.Drawing.Size(46, 23)
Me.Econ_1.TabIndex = 43
'
'Econ_0
'
Me.Econ_0.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Econ_0.Location = New System.Drawing.Point(77, 30)
Me.Econ_0.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Econ_0.Name = "Econ_0"
Me.Econ_0.Size = New System.Drawing.Size(46, 23)
Me.Econ_0.TabIndex = 42
Me.Econ_0.Text = "-1"
'
'TabPage5
'
Me.TabPage5.Controls.Add(Me.Button15)
Me.TabPage5.Controls.Add(Me.Button1)
Me.TabPage5.Controls.Add(Me.Label53)
Me.TabPage5.Controls.Add(Me.Door_Data_txt)
Me.TabPage5.Controls.Add(Me.Door_idx)
Me.TabPage5.Controls.Add(Me.Button21)
Me.TabPage5.Controls.Add(Me.Button3)
Me.TabPage5.Controls.Add(Me.Button6)
Me.TabPage5.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage5.Location = New System.Drawing.Point(4, 24)
Me.TabPage5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage5.Name = "TabPage5"
Me.TabPage5.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage5.Size = New System.Drawing.Size(1606, 732)
Me.TabPage5.TabIndex = 4
Me.TabPage5.Text = "開門資訊"
Me.TabPage5.UseVisualStyleBackColor = true
'
'Button15
'
Me.Button15.Location = New System.Drawing.Point(623, 190)
Me.Button15.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button15.Name = "Button15"
Me.Button15.Size = New System.Drawing.Size(86, 35)
Me.Button15.TabIndex = 108
Me.Button15.Text = "DoorDOWN"
Me.Button15.UseVisualStyleBackColor = true
'
'Button1
'
Me.Button1.Location = New System.Drawing.Point(623, 130)
Me.Button1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button1.Name = "Button1"
Me.Button1.Size = New System.Drawing.Size(86, 35)
Me.Button1.TabIndex = 106
Me.Button1.Text = "DoorUP"
Me.Button1.UseVisualStyleBackColor = true
'
'Label53
'
Me.Label53.AutoSize = true
Me.Label53.Location = New System.Drawing.Point(40, 94)
Me.Label53.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label53.Name = "Label53"
Me.Label53.Size = New System.Drawing.Size(37, 16)
Me.Label53.TabIndex = 105
Me.Label53.Text = "Door"
'
'Door_Data_txt
'
Me.Door_Data_txt.Location = New System.Drawing.Point(19, 130)
Me.Door_Data_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Door_Data_txt.Multiline = true
Me.Door_Data_txt.Name = "Door_Data_txt"
Me.Door_Data_txt.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.Door_Data_txt.Size = New System.Drawing.Size(597, 309)
Me.Door_Data_txt.TabIndex = 104
'
'Door_idx
'
Me.Door_idx.FormattingEnabled = true
Me.Door_idx.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"})
Me.Door_idx.Location = New System.Drawing.Point(119, 90)
Me.Door_idx.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Door_idx.Name = "Door_idx"
Me.Door_idx.Size = New System.Drawing.Size(139, 24)
Me.Door_idx.TabIndex = 103
Me.Door_idx.Text = "0"
'
'Button21
'
Me.Button21.Location = New System.Drawing.Point(266, 26)
Me.Button21.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button21.Name = "Button21"
Me.Button21.Size = New System.Drawing.Size(117, 35)
Me.Button21.TabIndex = 18
Me.Button21.Text = "手動轉自動"
Me.Button21.UseVisualStyleBackColor = true
'
'Button3
'
Me.Button3.Location = New System.Drawing.Point(142, 26)
Me.Button3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button3.Name = "Button3"
Me.Button3.Size = New System.Drawing.Size(117, 35)
Me.Button3.TabIndex = 17
Me.Button3.Text = "手動後退"
Me.Button3.UseVisualStyleBackColor = true
'
'Button6
'
Me.Button6.Location = New System.Drawing.Point(19, 26)
Me.Button6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button6.Name = "Button6"
Me.Button6.Size = New System.Drawing.Size(117, 35)
Me.Button6.TabIndex = 16
Me.Button6.Text = "手動前進"
Me.Button6.UseVisualStyleBackColor = true
'
'TabPage4
'
Me.TabPage4.Controls.Add(Me.AGVIO4_15)
Me.TabPage4.Controls.Add(Me.AGVIO4_14)
Me.TabPage4.Controls.Add(Me.AGVIO4_13)
Me.TabPage4.Controls.Add(Me.AGVIO4_12)
Me.TabPage4.Controls.Add(Me.AGVIO4_11)
Me.TabPage4.Controls.Add(Me.AGVIO4_10)
Me.TabPage4.Controls.Add(Me.AGVIO4_09)
Me.TabPage4.Controls.Add(Me.AGVIO4_08)
Me.TabPage4.Controls.Add(Me.AGVIO4_07)
Me.TabPage4.Controls.Add(Me.AGVIO4_06)
Me.TabPage4.Controls.Add(Me.AGVIO4_05)
Me.TabPage4.Controls.Add(Me.AGVIO4_04)
Me.TabPage4.Controls.Add(Me.AGVIO4_03)
Me.TabPage4.Controls.Add(Me.AGVIO4_02)
Me.TabPage4.Controls.Add(Me.AGVIO4_01)
Me.TabPage4.Controls.Add(Me.AGVIO4_00)
Me.TabPage4.Controls.Add(Me.AGVIO3_15)
Me.TabPage4.Controls.Add(Me.AGVIO3_14)
Me.TabPage4.Controls.Add(Me.AGVIO3_13)
Me.TabPage4.Controls.Add(Me.AGVIO3_12)
Me.TabPage4.Controls.Add(Me.AGVIO3_11)
Me.TabPage4.Controls.Add(Me.AGVIO3_10)
Me.TabPage4.Controls.Add(Me.AGVIO3_09)
Me.TabPage4.Controls.Add(Me.AGVIO3_08)
Me.TabPage4.Controls.Add(Me.AGVIO3_07)
Me.TabPage4.Controls.Add(Me.AGVIO3_06)
Me.TabPage4.Controls.Add(Me.AGVIO3_05)
Me.TabPage4.Controls.Add(Me.AGVIO3_04)
Me.TabPage4.Controls.Add(Me.AGVIO3_03)
Me.TabPage4.Controls.Add(Me.AGVIO3_02)
Me.TabPage4.Controls.Add(Me.AGVIO3_01)
Me.TabPage4.Controls.Add(Me.AGVIO3_00)
Me.TabPage4.Controls.Add(Me.AGVIO2_15)
Me.TabPage4.Controls.Add(Me.AGVIO2_14)
Me.TabPage4.Controls.Add(Me.AGVIO2_13)
Me.TabPage4.Controls.Add(Me.AGVIO2_12)
Me.TabPage4.Controls.Add(Me.AGVIO2_11)
Me.TabPage4.Controls.Add(Me.AGVIO2_10)
Me.TabPage4.Controls.Add(Me.AGVIO2_09)
Me.TabPage4.Controls.Add(Me.AGVIO2_08)
Me.TabPage4.Controls.Add(Me.AGVIO2_07)
Me.TabPage4.Controls.Add(Me.AGVIO2_06)
Me.TabPage4.Controls.Add(Me.AGVIO2_05)
Me.TabPage4.Controls.Add(Me.AGVIO2_04)
Me.TabPage4.Controls.Add(Me.AGVIO2_03)
Me.TabPage4.Controls.Add(Me.AGVIO2_02)
Me.TabPage4.Controls.Add(Me.AGVIO2_01)
Me.TabPage4.Controls.Add(Me.AGVIO2_00)
Me.TabPage4.Controls.Add(Me.AGVIO1_15)
Me.TabPage4.Controls.Add(Me.AGVIO1_10)
Me.TabPage4.Controls.Add(Me.AGVIO1_14)
Me.TabPage4.Controls.Add(Me.AGVIO1_13)
Me.TabPage4.Controls.Add(Me.AGVIO1_12)
Me.TabPage4.Controls.Add(Me.AGVIO1_11)
Me.TabPage4.Controls.Add(Me.AGVIO1_09)
Me.TabPage4.Controls.Add(Me.AGVIO1_08)
Me.TabPage4.Controls.Add(Me.AGVIO1_07)
Me.TabPage4.Controls.Add(Me.AGVIO1_06)
Me.TabPage4.Controls.Add(Me.AGVIO1_05)
Me.TabPage4.Controls.Add(Me.AGVIO1_04)
Me.TabPage4.Controls.Add(Me.AGVIO1_03)
Me.TabPage4.Controls.Add(Me.AGVIO1_02)
Me.TabPage4.Controls.Add(Me.AGVIO1_01)
Me.TabPage4.Controls.Add(Me.AGVIO1_00)
Me.TabPage4.Controls.Add(Me.LFT_name)
Me.TabPage4.Controls.Add(Me.Car_text)
Me.TabPage4.Controls.Add(Me.step_text)
Me.TabPage4.Controls.Add(Me.opendata)
Me.TabPage4.Controls.Add(Me.Button23)
Me.TabPage4.Controls.Add(Me.Button22)
Me.TabPage4.Controls.Add(Me.LFT_idx)
Me.TabPage4.Controls.Add(Me.LFT_W15)
Me.TabPage4.Controls.Add(Me.LFT_W14)
Me.TabPage4.Controls.Add(Me.LFT_W13)
Me.TabPage4.Controls.Add(Me.LFT_W12)
Me.TabPage4.Controls.Add(Me.LFT_W11)
Me.TabPage4.Controls.Add(Me.LFT_W10)
Me.TabPage4.Controls.Add(Me.LFT_W9)
Me.TabPage4.Controls.Add(Me.LFT_W8)
Me.TabPage4.Controls.Add(Me.LFT_W7)
Me.TabPage4.Controls.Add(Me.LFT_W6)
Me.TabPage4.Controls.Add(Me.LFT_W5)
Me.TabPage4.Controls.Add(Me.LFT_W4)
Me.TabPage4.Controls.Add(Me.LFT_W3)
Me.TabPage4.Controls.Add(Me.LFT_W2)
Me.TabPage4.Controls.Add(Me.LFT_W1)
Me.TabPage4.Controls.Add(Me.LFT_W0)
Me.TabPage4.Controls.Add(Me.LFT_FLOOR)
Me.TabPage4.Controls.Add(Me.LFT_R15)
Me.TabPage4.Controls.Add(Me.LFT_R14)
Me.TabPage4.Controls.Add(Me.LFT_R13)
Me.TabPage4.Controls.Add(Me.LFT_R12)
Me.TabPage4.Controls.Add(Me.LFT_R11)
Me.TabPage4.Controls.Add(Me.LFT_R10)
Me.TabPage4.Controls.Add(Me.LFT_R9)
Me.TabPage4.Controls.Add(Me.LFT_R8)
Me.TabPage4.Controls.Add(Me.LFT_R7)
Me.TabPage4.Controls.Add(Me.LFT_R6)
Me.TabPage4.Controls.Add(Me.LFT_R5)
Me.TabPage4.Controls.Add(Me.LFT_R4)
Me.TabPage4.Controls.Add(Me.LFT_R3)
Me.TabPage4.Controls.Add(Me.LFT_R2)
Me.TabPage4.Controls.Add(Me.LFT_R1)
Me.TabPage4.Controls.Add(Me.LFT_R0)
Me.TabPage4.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage4.Location = New System.Drawing.Point(4, 24)
Me.TabPage4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage4.Name = "TabPage4"
Me.TabPage4.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage4.Size = New System.Drawing.Size(1606, 732)
Me.TabPage4.TabIndex = 5
Me.TabPage4.Text = "IO訊號"
Me.TabPage4.UseVisualStyleBackColor = true
'
'AGVIO4_15
'
Me.AGVIO4_15.Location = New System.Drawing.Point(716, 634)
Me.AGVIO4_15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_15.Name = "AGVIO4_15"
Me.AGVIO4_15.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_15.TabIndex = 244
Me.AGVIO4_15.Text = "右-Complete"
'
'AGVIO4_14
'
Me.AGVIO4_14.Location = New System.Drawing.Point(716, 598)
Me.AGVIO4_14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_14.Name = "AGVIO4_14"
Me.AGVIO4_14.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_14.TabIndex = 243
Me.AGVIO4_14.Text = "右-Busy"
'
'AGVIO4_13
'
Me.AGVIO4_13.Location = New System.Drawing.Point(716, 564)
Me.AGVIO4_13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_13.Name = "AGVIO4_13"
Me.AGVIO4_13.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_13.TabIndex = 242
Me.AGVIO4_13.Text = "右-TR Req"
'
'AGVIO4_12
'
Me.AGVIO4_12.Location = New System.Drawing.Point(716, 530)
Me.AGVIO4_12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_12.Name = "AGVIO4_12"
Me.AGVIO4_12.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_12.TabIndex = 241
Me.AGVIO4_12.Text = "右-Vaild Signal"
'
'AGVIO4_11
'
Me.AGVIO4_11.Location = New System.Drawing.Point(716, 494)
Me.AGVIO4_11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_11.Name = "AGVIO4_11"
Me.AGVIO4_11.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_11.TabIndex = 240
Me.AGVIO4_11.Text = "左-Complete"
'
'AGVIO4_10
'
Me.AGVIO4_10.Location = New System.Drawing.Point(716, 458)
Me.AGVIO4_10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_10.Name = "AGVIO4_10"
Me.AGVIO4_10.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_10.TabIndex = 239
Me.AGVIO4_10.Text = "左-Busy"
'
'AGVIO4_09
'
Me.AGVIO4_09.Location = New System.Drawing.Point(716, 424)
Me.AGVIO4_09.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_09.Name = "AGVIO4_09"
Me.AGVIO4_09.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_09.TabIndex = 238
Me.AGVIO4_09.Text = "左-TR Req"
'
'AGVIO4_08
'
Me.AGVIO4_08.Location = New System.Drawing.Point(716, 390)
Me.AGVIO4_08.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_08.Name = "AGVIO4_08"
Me.AGVIO4_08.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_08.TabIndex = 237
Me.AGVIO4_08.Text = "左Vaild"
'
'AGVIO4_07
'
Me.AGVIO4_07.Location = New System.Drawing.Point(716, 359)
Me.AGVIO4_07.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_07.Name = "AGVIO4_07"
Me.AGVIO4_07.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_07.TabIndex = 236
Me.AGVIO4_07.Text = "Fork軸剎車釋放"
'
'AGVIO4_06
'
Me.AGVIO4_06.Location = New System.Drawing.Point(716, 323)
Me.AGVIO4_06.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_06.Name = "AGVIO4_06"
Me.AGVIO4_06.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_06.TabIndex = 235
Me.AGVIO4_06.Text = "Turm軸剎車釋放"
'
'AGVIO4_05
'
Me.AGVIO4_05.Location = New System.Drawing.Point(716, 288)
Me.AGVIO4_05.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_05.Name = "AGVIO4_05"
Me.AGVIO4_05.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_05.TabIndex = 234
Me.AGVIO4_05.Text = "升降軸剎車釋放"
'
'AGVIO4_04
'
Me.AGVIO4_04.Location = New System.Drawing.Point(716, 253)
Me.AGVIO4_04.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_04.Name = "AGVIO4_04"
Me.AGVIO4_04.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_04.TabIndex = 233
Me.AGVIO4_04.Text = "橫移軸剎車釋放"
'
'AGVIO4_03
'
Me.AGVIO4_03.Location = New System.Drawing.Point(716, 217)
Me.AGVIO4_03.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_03.Name = "AGVIO4_03"
Me.AGVIO4_03.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_03.TabIndex = 232
Me.AGVIO4_03.Text = "桿燈-蜂鳴器"
'
'AGVIO4_02
'
Me.AGVIO4_02.Location = New System.Drawing.Point(716, 181)
Me.AGVIO4_02.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_02.Name = "AGVIO4_02"
Me.AGVIO4_02.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_02.TabIndex = 231
Me.AGVIO4_02.Text = "桿燈-綠"
'
'AGVIO4_01
'
Me.AGVIO4_01.Location = New System.Drawing.Point(716, 145)
Me.AGVIO4_01.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_01.Name = "AGVIO4_01"
Me.AGVIO4_01.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_01.TabIndex = 230
Me.AGVIO4_01.Text = "桿燈-黃"
'
'AGVIO4_00
'
Me.AGVIO4_00.Location = New System.Drawing.Point(716, 112)
Me.AGVIO4_00.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO4_00.Name = "AGVIO4_00"
Me.AGVIO4_00.Size = New System.Drawing.Size(100, 18)
Me.AGVIO4_00.TabIndex = 229
Me.AGVIO4_00.Text = "桿燈-紅"
'
'AGVIO3_15
'
Me.AGVIO3_15.Location = New System.Drawing.Point(611, 634)
Me.AGVIO3_15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_15.Name = "AGVIO3_15"
Me.AGVIO3_15.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_15.TabIndex = 228
Me.AGVIO3_15.Text = "保留點位"
'
'AGVIO3_14
'
Me.AGVIO3_14.Location = New System.Drawing.Point(611, 598)
Me.AGVIO3_14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_14.Name = "AGVIO3_14"
Me.AGVIO3_14.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_14.TabIndex = 227
Me.AGVIO3_14.Text = "保留點位"
'
'AGVIO3_13
'
Me.AGVIO3_13.Location = New System.Drawing.Point(611, 564)
Me.AGVIO3_13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_13.Name = "AGVIO3_13"
Me.AGVIO3_13.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_13.TabIndex = 226
Me.AGVIO3_13.Text = "保留點位"
'
'AGVIO3_12
'
Me.AGVIO3_12.Location = New System.Drawing.Point(611, 530)
Me.AGVIO3_12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_12.Name = "AGVIO3_12"
Me.AGVIO3_12.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_12.TabIndex = 225
Me.AGVIO3_12.Text = "保留點位"
'
'AGVIO3_11
'
Me.AGVIO3_11.Location = New System.Drawing.Point(611, 494)
Me.AGVIO3_11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_11.Name = "AGVIO3_11"
Me.AGVIO3_11.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_11.TabIndex = 224
Me.AGVIO3_11.Text = "保留點位"
'
'AGVIO3_10
'
Me.AGVIO3_10.Location = New System.Drawing.Point(611, 458)
Me.AGVIO3_10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_10.Name = "AGVIO3_10"
Me.AGVIO3_10.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_10.TabIndex = 223
Me.AGVIO3_10.Text = "保留點位"
'
'AGVIO3_09
'
Me.AGVIO3_09.Location = New System.Drawing.Point(611, 424)
Me.AGVIO3_09.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_09.Name = "AGVIO3_09"
Me.AGVIO3_09.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_09.TabIndex = 222
Me.AGVIO3_09.Text = "保留點位"
'
'AGVIO3_08
'
Me.AGVIO3_08.Location = New System.Drawing.Point(611, 390)
Me.AGVIO3_08.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_08.Name = "AGVIO3_08"
Me.AGVIO3_08.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_08.TabIndex = 221
Me.AGVIO3_08.Text = "右側PIO Go"
'
'AGVIO3_07
'
Me.AGVIO3_07.Location = New System.Drawing.Point(611, 359)
Me.AGVIO3_07.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_07.Name = "AGVIO3_07"
Me.AGVIO3_07.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_07.TabIndex = 220
Me.AGVIO3_07.Text = "左側PIO Go"
'
'AGVIO3_06
'
Me.AGVIO3_06.Location = New System.Drawing.Point(611, 323)
Me.AGVIO3_06.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_06.Name = "AGVIO3_06"
Me.AGVIO3_06.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_06.TabIndex = 219
Me.AGVIO3_06.Text = "-"
'
'AGVIO3_05
'
Me.AGVIO3_05.Location = New System.Drawing.Point(611, 288)
Me.AGVIO3_05.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_05.Name = "AGVIO3_05"
Me.AGVIO3_05.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_05.TabIndex = 218
Me.AGVIO3_05.Text = "REQ-Ready"
'
'AGVIO3_04
'
Me.AGVIO3_04.Location = New System.Drawing.Point(611, 253)
Me.AGVIO3_04.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_04.Name = "AGVIO3_04"
Me.AGVIO3_04.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_04.TabIndex = 217
Me.AGVIO3_04.Text = "REQ-U_Req"
'
'AGVIO3_03
'
Me.AGVIO3_03.Location = New System.Drawing.Point(611, 217)
Me.AGVIO3_03.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_03.Name = "AGVIO3_03"
Me.AGVIO3_03.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_03.TabIndex = 216
Me.AGVIO3_03.Text = "REQ-L_Req"
'
'AGVIO3_02
'
Me.AGVIO3_02.Location = New System.Drawing.Point(611, 181)
Me.AGVIO3_02.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_02.Name = "AGVIO3_02"
Me.AGVIO3_02.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_02.TabIndex = 215
Me.AGVIO3_02.Text = "LEQ-Ready"
'
'AGVIO3_01
'
Me.AGVIO3_01.Location = New System.Drawing.Point(611, 145)
Me.AGVIO3_01.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_01.Name = "AGVIO3_01"
Me.AGVIO3_01.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_01.TabIndex = 214
Me.AGVIO3_01.Text = "LEQ-U_Req"
'
'AGVIO3_00
'
Me.AGVIO3_00.Location = New System.Drawing.Point(611, 112)
Me.AGVIO3_00.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO3_00.Name = "AGVIO3_00"
Me.AGVIO3_00.Size = New System.Drawing.Size(100, 18)
Me.AGVIO3_00.TabIndex = 213
Me.AGVIO3_00.Text = "LEQ-L_Req"
'
'AGVIO2_15
'
Me.AGVIO2_15.Location = New System.Drawing.Point(483, 634)
Me.AGVIO2_15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_15.Name = "AGVIO2_15"
Me.AGVIO2_15.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_15.TabIndex = 212
Me.AGVIO2_15.Text = "保留點位"
'
'AGVIO2_14
'
Me.AGVIO2_14.Location = New System.Drawing.Point(483, 598)
Me.AGVIO2_14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_14.Name = "AGVIO2_14"
Me.AGVIO2_14.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_14.TabIndex = 211
Me.AGVIO2_14.Text = "保留點位"
'
'AGVIO2_13
'
Me.AGVIO2_13.Location = New System.Drawing.Point(483, 564)
Me.AGVIO2_13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_13.Name = "AGVIO2_13"
Me.AGVIO2_13.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_13.TabIndex = 210
Me.AGVIO2_13.Text = "保留點位"
'
'AGVIO2_12
'
Me.AGVIO2_12.Location = New System.Drawing.Point(483, 530)
Me.AGVIO2_12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_12.Name = "AGVIO2_12"
Me.AGVIO2_12.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_12.TabIndex = 209
Me.AGVIO2_12.Text = "安全模組輸出"
'
'AGVIO2_11
'
Me.AGVIO2_11.Location = New System.Drawing.Point(483, 494)
Me.AGVIO2_11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_11.Name = "AGVIO2_11"
Me.AGVIO2_11.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_11.TabIndex = 208
Me.AGVIO2_11.Text = "雷射測距<右>"
'
'AGVIO2_10
'
Me.AGVIO2_10.Location = New System.Drawing.Point(483, 458)
Me.AGVIO2_10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_10.Name = "AGVIO2_10"
Me.AGVIO2_10.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_10.TabIndex = 207
Me.AGVIO2_10.Text = "Stage在席2"
'
'AGVIO2_09
'
Me.AGVIO2_09.Location = New System.Drawing.Point(483, 424)
Me.AGVIO2_09.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_09.Name = "AGVIO2_09"
Me.AGVIO2_09.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_09.TabIndex = 206
Me.AGVIO2_09.Text = "Stage在席1"
'
'AGVIO2_08
'
Me.AGVIO2_08.Location = New System.Drawing.Point(483, 390)
Me.AGVIO2_08.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_08.Name = "AGVIO2_08"
Me.AGVIO2_08.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_08.TabIndex = 205
Me.AGVIO2_08.Text = "雷射測距<左>"
'
'AGVIO2_07
'
Me.AGVIO2_07.Location = New System.Drawing.Point(483, 359)
Me.AGVIO2_07.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_07.Name = "AGVIO2_07"
Me.AGVIO2_07.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_07.TabIndex = 204
Me.AGVIO2_07.Text = "反射式在荷"
'
'AGVIO2_06
'
Me.AGVIO2_06.Location = New System.Drawing.Point(483, 323)
Me.AGVIO2_06.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_06.Name = "AGVIO2_06"
Me.AGVIO2_06.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_06.TabIndex = 203
Me.AGVIO2_06.Text = "Fork在荷2<SICK>"
'
'AGVIO2_05
'
Me.AGVIO2_05.Location = New System.Drawing.Point(483, 288)
Me.AGVIO2_05.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_05.Name = "AGVIO2_05"
Me.AGVIO2_05.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_05.TabIndex = 202
Me.AGVIO2_05.Text = "Fork在荷1<SICK>"
'
'AGVIO2_04
'
Me.AGVIO2_04.Location = New System.Drawing.Point(483, 253)
Me.AGVIO2_04.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_04.Name = "AGVIO2_04"
Me.AGVIO2_04.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_04.TabIndex = 201
Me.AGVIO2_04.Text = "Fork軸Zone"
'
'AGVIO2_03
'
Me.AGVIO2_03.Location = New System.Drawing.Point(483, 217)
Me.AGVIO2_03.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_03.Name = "AGVIO2_03"
Me.AGVIO2_03.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_03.TabIndex = 200
Me.AGVIO2_03.Text = "Fork軸前限"
'
'AGVIO2_02
'
Me.AGVIO2_02.Location = New System.Drawing.Point(483, 181)
Me.AGVIO2_02.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_02.Name = "AGVIO2_02"
Me.AGVIO2_02.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_02.TabIndex = 199
Me.AGVIO2_02.Text = "Fork軸原點"
'
'AGVIO2_01
'
Me.AGVIO2_01.Location = New System.Drawing.Point(483, 145)
Me.AGVIO2_01.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_01.Name = "AGVIO2_01"
Me.AGVIO2_01.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_01.TabIndex = 198
Me.AGVIO2_01.Text = " Fork軸後限"
'
'AGVIO2_00
'
Me.AGVIO2_00.Location = New System.Drawing.Point(483, 112)
Me.AGVIO2_00.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO2_00.Name = "AGVIO2_00"
Me.AGVIO2_00.Size = New System.Drawing.Size(100, 18)
Me.AGVIO2_00.TabIndex = 197
Me.AGVIO2_00.Text = "手持人機Dead Lock"
'
'AGVIO1_15
'
Me.AGVIO1_15.Location = New System.Drawing.Point(378, 634)
Me.AGVIO1_15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_15.Name = "AGVIO1_15"
Me.AGVIO1_15.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_15.TabIndex = 196
Me.AGVIO1_15.Text = "保留"
'
'AGVIO1_10
'
Me.AGVIO1_10.Location = New System.Drawing.Point(378, 460)
Me.AGVIO1_10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_10.Name = "AGVIO1_10"
Me.AGVIO1_10.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_10.TabIndex = 195
Me.AGVIO1_10.Text = "保留"
'
'AGVIO1_14
'
Me.AGVIO1_14.Location = New System.Drawing.Point(378, 600)
Me.AGVIO1_14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_14.Name = "AGVIO1_14"
Me.AGVIO1_14.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_14.TabIndex = 194
Me.AGVIO1_14.Text = "Turn軸左限"
'
'AGVIO1_13
'
Me.AGVIO1_13.Location = New System.Drawing.Point(378, 566)
Me.AGVIO1_13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_13.Name = "AGVIO1_13"
Me.AGVIO1_13.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_13.TabIndex = 193
Me.AGVIO1_13.Text = "Turn軸原點"
'
'AGVIO1_12
'
Me.AGVIO1_12.Location = New System.Drawing.Point(378, 530)
Me.AGVIO1_12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_12.Name = "AGVIO1_12"
Me.AGVIO1_12.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_12.TabIndex = 192
Me.AGVIO1_12.Text = "Turn軸右限"
'
'AGVIO1_11
'
Me.AGVIO1_11.Location = New System.Drawing.Point(378, 494)
Me.AGVIO1_11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_11.Name = "AGVIO1_11"
Me.AGVIO1_11.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_11.TabIndex = 191
Me.AGVIO1_11.Text = "升降軸上定位"
'
'AGVIO1_09
'
Me.AGVIO1_09.Location = New System.Drawing.Point(378, 424)
Me.AGVIO1_09.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_09.Name = "AGVIO1_09"
Me.AGVIO1_09.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_09.TabIndex = 190
Me.AGVIO1_09.Text = "升降軸上限"
'
'AGVIO1_08
'
Me.AGVIO1_08.Location = New System.Drawing.Point(378, 390)
Me.AGVIO1_08.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_08.Name = "AGVIO1_08"
Me.AGVIO1_08.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_08.TabIndex = 189
Me.AGVIO1_08.Text = "升降軸原點"
'
'AGVIO1_07
'
Me.AGVIO1_07.Location = New System.Drawing.Point(378, 359)
Me.AGVIO1_07.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_07.Name = "AGVIO1_07"
Me.AGVIO1_07.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_07.TabIndex = 188
Me.AGVIO1_07.Text = "升降軸下限"
'
'AGVIO1_06
'
Me.AGVIO1_06.Location = New System.Drawing.Point(378, 323)
Me.AGVIO1_06.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_06.Name = "AGVIO1_06"
Me.AGVIO1_06.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_06.TabIndex = 187
Me.AGVIO1_06.Text = "橫移軸後限"
'
'AGVIO1_05
'
Me.AGVIO1_05.Location = New System.Drawing.Point(378, 288)
Me.AGVIO1_05.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_05.Name = "AGVIO1_05"
Me.AGVIO1_05.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_05.TabIndex = 186
Me.AGVIO1_05.Text = "橫移軸原點"
'
'AGVIO1_04
'
Me.AGVIO1_04.Location = New System.Drawing.Point(378, 253)
Me.AGVIO1_04.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_04.Name = "AGVIO1_04"
Me.AGVIO1_04.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_04.TabIndex = 185
Me.AGVIO1_04.Text = "橫移軸前限"
'
'AGVIO1_03
'
Me.AGVIO1_03.Location = New System.Drawing.Point(378, 217)
Me.AGVIO1_03.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_03.Name = "AGVIO1_03"
Me.AGVIO1_03.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_03.TabIndex = 184
Me.AGVIO1_03.Text = "保留"
'
'AGVIO1_02
'
Me.AGVIO1_02.Location = New System.Drawing.Point(378, 181)
Me.AGVIO1_02.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_02.Name = "AGVIO1_02"
Me.AGVIO1_02.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_02.TabIndex = 183
Me.AGVIO1_02.Text = "急停PB<後側"
'
'AGVIO1_01
'
Me.AGVIO1_01.Location = New System.Drawing.Point(378, 145)
Me.AGVIO1_01.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_01.Name = "AGVIO1_01"
Me.AGVIO1_01.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_01.TabIndex = 182
Me.AGVIO1_01.Text = "急停PB<前側>"
'
'AGVIO1_00
'
Me.AGVIO1_00.Location = New System.Drawing.Point(378, 112)
Me.AGVIO1_00.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.AGVIO1_00.Name = "AGVIO1_00"
Me.AGVIO1_00.Size = New System.Drawing.Size(100, 18)
Me.AGVIO1_00.TabIndex = 181
Me.AGVIO1_00.Text = "自動啟動PB"
'
'LFT_name
'
Me.LFT_name.AutoSize = true
Me.LFT_name.Location = New System.Drawing.Point(217, 32)
Me.LFT_name.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_name.Name = "LFT_name"
Me.LFT_name.Size = New System.Drawing.Size(64, 16)
Me.LFT_name.TabIndex = 180
Me.LFT_name.Text = "LFT_name"
'
'Car_text
'
Me.Car_text.AutoSize = true
Me.Car_text.Location = New System.Drawing.Point(247, 86)
Me.Car_text.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Car_text.Name = "Car_text"
Me.Car_text.Size = New System.Drawing.Size(32, 16)
Me.Car_text.TabIndex = 179
Me.Car_text.Text = "CAR"
'
'step_text
'
Me.step_text.AutoSize = true
Me.step_text.Location = New System.Drawing.Point(161, 86)
Me.step_text.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.step_text.Name = "step_text"
Me.step_text.Size = New System.Drawing.Size(36, 16)
Me.step_text.TabIndex = 178
Me.step_text.Text = "STEP"
'
'opendata
'
Me.opendata.AutoSize = true
Me.opendata.Location = New System.Drawing.Point(107, 86)
Me.opendata.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.opendata.Name = "opendata"
Me.opendata.Size = New System.Drawing.Size(26, 16)
Me.opendata.TabIndex = 177
Me.opendata.Text = "?樓"
'
'Button23
'
Me.Button23.Location = New System.Drawing.Point(140, 666)
Me.Button23.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button23.Name = "Button23"
Me.Button23.Size = New System.Drawing.Size(86, 35)
Me.Button23.TabIndex = 176
Me.Button23.Text = "清除"
Me.Button23.UseVisualStyleBackColor = true
'
'Button22
'
Me.Button22.Location = New System.Drawing.Point(44, 666)
Me.Button22.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button22.Name = "Button22"
Me.Button22.Size = New System.Drawing.Size(86, 35)
Me.Button22.TabIndex = 172
Me.Button22.Text = "重新連線"
Me.Button22.UseVisualStyleBackColor = true
'
'LFT_idx
'
Me.LFT_idx.FormattingEnabled = true
Me.LFT_idx.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6"})
Me.LFT_idx.Location = New System.Drawing.Point(44, 32)
Me.LFT_idx.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.LFT_idx.Name = "LFT_idx"
Me.LFT_idx.Size = New System.Drawing.Size(139, 24)
Me.LFT_idx.TabIndex = 170
Me.LFT_idx.Text = "0"
'
'LFT_W15
'
Me.LFT_W15.AutoSize = true
Me.LFT_W15.Location = New System.Drawing.Point(203, 634)
Me.LFT_W15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W15.Name = "LFT_W15"
Me.LFT_W15.Size = New System.Drawing.Size(56, 16)
Me.LFT_W15.TabIndex = 169
Me.LFT_W15.Text = "保留點位"
'
'LFT_W14
'
Me.LFT_W14.AutoSize = true
Me.LFT_W14.Location = New System.Drawing.Point(203, 598)
Me.LFT_W14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W14.Name = "LFT_W14"
Me.LFT_W14.Size = New System.Drawing.Size(56, 16)
Me.LFT_W14.TabIndex = 168
Me.LFT_W14.Text = "保留點位"
'
'LFT_W13
'
Me.LFT_W13.AutoSize = true
Me.LFT_W13.Location = New System.Drawing.Point(203, 564)
Me.LFT_W13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W13.Name = "LFT_W13"
Me.LFT_W13.Size = New System.Drawing.Size(56, 16)
Me.LFT_W13.TabIndex = 167
Me.LFT_W13.Text = "保留點位"
'
'LFT_W12
'
Me.LFT_W12.AutoSize = true
Me.LFT_W12.Location = New System.Drawing.Point(203, 530)
Me.LFT_W12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W12.Name = "LFT_W12"
Me.LFT_W12.Size = New System.Drawing.Size(56, 16)
Me.LFT_W12.TabIndex = 166
Me.LFT_W12.Text = "電梯關門"
'
'LFT_W11
'
Me.LFT_W11.AutoSize = true
Me.LFT_W11.Location = New System.Drawing.Point(203, 494)
Me.LFT_W11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W11.Name = "LFT_W11"
Me.LFT_W11.Size = New System.Drawing.Size(56, 16)
Me.LFT_W11.TabIndex = 165
Me.LFT_W11.Text = "電梯開門"
'
'LFT_W10
'
Me.LFT_W10.AutoSize = true
Me.LFT_W10.Location = New System.Drawing.Point(203, 458)
Me.LFT_W10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W10.Name = "LFT_W10"
Me.LFT_W10.Size = New System.Drawing.Size(13, 16)
Me.LFT_W10.TabIndex = 164
Me.LFT_W10.Text = "-"
'
'LFT_W9
'
Me.LFT_W9.AutoSize = true
Me.LFT_W9.Location = New System.Drawing.Point(203, 424)
Me.LFT_W9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W9.Name = "LFT_W9"
Me.LFT_W9.Size = New System.Drawing.Size(13, 16)
Me.LFT_W9.TabIndex = 163
Me.LFT_W9.Text = "-"
'
'LFT_W8
'
Me.LFT_W8.AutoSize = true
Me.LFT_W8.Location = New System.Drawing.Point(203, 390)
Me.LFT_W8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W8.Name = "LFT_W8"
Me.LFT_W8.Size = New System.Drawing.Size(69, 16)
Me.LFT_W8.TabIndex = 162
Me.LFT_W8.Text = "7F電梯叫車"
'
'LFT_W7
'
Me.LFT_W7.AutoSize = true
Me.LFT_W7.Location = New System.Drawing.Point(203, 359)
Me.LFT_W7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W7.Name = "LFT_W7"
Me.LFT_W7.Size = New System.Drawing.Size(69, 16)
Me.LFT_W7.TabIndex = 161
Me.LFT_W7.Text = "6F電梯叫車"
'
'LFT_W6
'
Me.LFT_W6.AutoSize = true
Me.LFT_W6.Location = New System.Drawing.Point(203, 323)
Me.LFT_W6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W6.Name = "LFT_W6"
Me.LFT_W6.Size = New System.Drawing.Size(69, 16)
Me.LFT_W6.TabIndex = 160
Me.LFT_W6.Text = "5F電梯叫車"
'
'LFT_W5
'
Me.LFT_W5.AutoSize = true
Me.LFT_W5.Location = New System.Drawing.Point(203, 288)
Me.LFT_W5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W5.Name = "LFT_W5"
Me.LFT_W5.Size = New System.Drawing.Size(69, 16)
Me.LFT_W5.TabIndex = 159
Me.LFT_W5.Text = "4F電梯叫車"
'
'LFT_W4
'
Me.LFT_W4.AutoSize = true
Me.LFT_W4.Location = New System.Drawing.Point(203, 253)
Me.LFT_W4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W4.Name = "LFT_W4"
Me.LFT_W4.Size = New System.Drawing.Size(69, 16)
Me.LFT_W4.TabIndex = 158
Me.LFT_W4.Text = "3F電梯叫車"
'
'LFT_W3
'
Me.LFT_W3.AutoSize = true
Me.LFT_W3.Location = New System.Drawing.Point(203, 217)
Me.LFT_W3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W3.Name = "LFT_W3"
Me.LFT_W3.Size = New System.Drawing.Size(69, 16)
Me.LFT_W3.TabIndex = 157
Me.LFT_W3.Text = "2F電梯叫車"
'
'LFT_W2
'
Me.LFT_W2.AutoSize = true
Me.LFT_W2.Location = New System.Drawing.Point(203, 181)
Me.LFT_W2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W2.Name = "LFT_W2"
Me.LFT_W2.Size = New System.Drawing.Size(69, 16)
Me.LFT_W2.TabIndex = 156
Me.LFT_W2.Text = "1F電梯叫車"
'
'LFT_W1
'
Me.LFT_W1.AutoSize = true
Me.LFT_W1.Location = New System.Drawing.Point(203, 145)
Me.LFT_W1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W1.Name = "LFT_W1"
Me.LFT_W1.Size = New System.Drawing.Size(76, 16)
Me.LFT_W1.TabIndex = 155
Me.LFT_W1.Text = "B1F電梯叫車"
'
'LFT_W0
'
Me.LFT_W0.AutoSize = true
Me.LFT_W0.Location = New System.Drawing.Point(203, 112)
Me.LFT_W0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_W0.Name = "LFT_W0"
Me.LFT_W0.Size = New System.Drawing.Size(81, 16)
Me.LFT_W0.TabIndex = 154
Me.LFT_W0.Text = "電梯専用REQ"
'
'LFT_FLOOR
'
Me.LFT_FLOOR.AutoSize = true
Me.LFT_FLOOR.Location = New System.Drawing.Point(42, 86)
Me.LFT_FLOOR.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_FLOOR.Name = "LFT_FLOOR"
Me.LFT_FLOOR.Size = New System.Drawing.Size(26, 16)
Me.LFT_FLOOR.TabIndex = 153
Me.LFT_FLOOR.Text = "?樓"
'
'LFT_R15
'
Me.LFT_R15.AutoSize = true
Me.LFT_R15.Location = New System.Drawing.Point(42, 634)
Me.LFT_R15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R15.Name = "LFT_R15"
Me.LFT_R15.Size = New System.Drawing.Size(124, 16)
Me.LFT_R15.TabIndex = 152
Me.LFT_R15.Text = "樓層BCD碼A4  (MSB)"
'
'LFT_R14
'
Me.LFT_R14.AutoSize = true
Me.LFT_R14.Location = New System.Drawing.Point(42, 598)
Me.LFT_R14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R14.Name = "LFT_R14"
Me.LFT_R14.Size = New System.Drawing.Size(83, 16)
Me.LFT_R14.TabIndex = 151
Me.LFT_R14.Text = "樓層BCD碼A3"
'
'LFT_R13
'
Me.LFT_R13.AutoSize = true
Me.LFT_R13.Location = New System.Drawing.Point(42, 564)
Me.LFT_R13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R13.Name = "LFT_R13"
Me.LFT_R13.Size = New System.Drawing.Size(83, 16)
Me.LFT_R13.TabIndex = 150
Me.LFT_R13.Text = "樓層BCD碼A2"
'
'LFT_R12
'
Me.LFT_R12.AutoSize = true
Me.LFT_R12.Location = New System.Drawing.Point(42, 530)
Me.LFT_R12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R12.Name = "LFT_R12"
Me.LFT_R12.Size = New System.Drawing.Size(114, 16)
Me.LFT_R12.TabIndex = 149
Me.LFT_R12.Text = "樓層BCD碼A1 (LSB)"
'
'LFT_R11
'
Me.LFT_R11.AutoSize = true
Me.LFT_R11.Location = New System.Drawing.Point(42, 494)
Me.LFT_R11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R11.Name = "LFT_R11"
Me.LFT_R11.Size = New System.Drawing.Size(113, 16)
Me.LFT_R11.TabIndex = 148
Me.LFT_R11.Text = "樓層BCD碼A0 (+/-)"
'
'LFT_R10
'
Me.LFT_R10.AutoSize = true
Me.LFT_R10.Location = New System.Drawing.Point(42, 458)
Me.LFT_R10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R10.Name = "LFT_R10"
Me.LFT_R10.Size = New System.Drawing.Size(92, 16)
Me.LFT_R10.TabIndex = 147
Me.LFT_R10.Text = "乘場門關閉完成"
'
'LFT_R9
'
Me.LFT_R9.AutoSize = true
Me.LFT_R9.Location = New System.Drawing.Point(42, 424)
Me.LFT_R9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R9.Name = "LFT_R9"
Me.LFT_R9.Size = New System.Drawing.Size(92, 16)
Me.LFT_R9.TabIndex = 146
Me.LFT_R9.Text = "乘場門開啟完成"
'
'LFT_R8
'
Me.LFT_R8.AutoSize = true
Me.LFT_R8.Location = New System.Drawing.Point(42, 390)
Me.LFT_R8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R8.Name = "LFT_R8"
Me.LFT_R8.Size = New System.Drawing.Size(92, 16)
Me.LFT_R8.TabIndex = 145
Me.LFT_R8.Text = "車廂門關閉完成"
'
'LFT_R7
'
Me.LFT_R7.AutoSize = true
Me.LFT_R7.Location = New System.Drawing.Point(42, 359)
Me.LFT_R7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R7.Name = "LFT_R7"
Me.LFT_R7.Size = New System.Drawing.Size(92, 16)
Me.LFT_R7.TabIndex = 144
Me.LFT_R7.Text = "車廂門開啟完成"
'
'LFT_R6
'
Me.LFT_R6.AutoSize = true
Me.LFT_R6.Location = New System.Drawing.Point(42, 323)
Me.LFT_R6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R6.Name = "LFT_R6"
Me.LFT_R6.Size = New System.Drawing.Size(80, 16)
Me.LFT_R6.TabIndex = 143
Me.LFT_R6.Text = "電梯下行指示"
'
'LFT_R5
'
Me.LFT_R5.AutoSize = true
Me.LFT_R5.Location = New System.Drawing.Point(42, 288)
Me.LFT_R5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R5.Name = "LFT_R5"
Me.LFT_R5.Size = New System.Drawing.Size(80, 16)
Me.LFT_R5.TabIndex = 142
Me.LFT_R5.Text = "電梯上行指示"
'
'LFT_R4
'
Me.LFT_R4.AutoSize = true
Me.LFT_R4.Location = New System.Drawing.Point(42, 253)
Me.LFT_R4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R4.Name = "LFT_R4"
Me.LFT_R4.Size = New System.Drawing.Size(80, 16)
Me.LFT_R4.TabIndex = 141
Me.LFT_R4.Text = "紅外線感應器"
'
'LFT_R3
'
Me.LFT_R3.AutoSize = true
Me.LFT_R3.Location = New System.Drawing.Point(42, 217)
Me.LFT_R3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R3.Name = "LFT_R3"
Me.LFT_R3.Size = New System.Drawing.Size(46, 16)
Me.LFT_R3.TabIndex = 140
Me.LFT_R3.Text = "Label8"
'
'LFT_R2
'
Me.LFT_R2.AutoSize = true
Me.LFT_R2.Location = New System.Drawing.Point(42, 181)
Me.LFT_R2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R2.Name = "LFT_R2"
Me.LFT_R2.Size = New System.Drawing.Size(56, 16)
Me.LFT_R2.TabIndex = 139
Me.LFT_R2.Text = "電梯水平"
'
'LFT_R1
'
Me.LFT_R1.AutoSize = true
Me.LFT_R1.Location = New System.Drawing.Point(42, 145)
Me.LFT_R1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R1.Name = "LFT_R1"
Me.LFT_R1.Size = New System.Drawing.Size(56, 16)
Me.LFT_R1.TabIndex = 138
Me.LFT_R1.Text = "電梯正常"
'
'LFT_R0
'
Me.LFT_R0.AutoSize = true
Me.LFT_R0.Location = New System.Drawing.Point(42, 112)
Me.LFT_R0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.LFT_R0.Name = "LFT_R0"
Me.LFT_R0.Size = New System.Drawing.Size(79, 16)
Me.LFT_R0.TabIndex = 137
Me.LFT_R0.Text = "電梯專用ACK"
'
'TabPage6
'
Me.TabPage6.Controls.Add(Me.Group_path_text)
Me.TabPage6.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage6.Location = New System.Drawing.Point(4, 24)
Me.TabPage6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage6.Name = "TabPage6"
Me.TabPage6.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage6.Size = New System.Drawing.Size(1606, 732)
Me.TabPage6.TabIndex = 6
Me.TabPage6.Text = "Group Path"
Me.TabPage6.UseVisualStyleBackColor = true
'
'Group_path_text
'
Me.Group_path_text.Location = New System.Drawing.Point(21, 28)
Me.Group_path_text.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Group_path_text.Multiline = true
Me.Group_path_text.Name = "Group_path_text"
Me.Group_path_text.Size = New System.Drawing.Size(643, 370)
Me.Group_path_text.TabIndex = 109
'
'TabPage7
'
Me.TabPage7.Controls.Add(Me.VerLog)
Me.TabPage7.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage7.Location = New System.Drawing.Point(4, 24)
Me.TabPage7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage7.Name = "TabPage7"
Me.TabPage7.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage7.Size = New System.Drawing.Size(1606, 732)
Me.TabPage7.TabIndex = 7
Me.TabPage7.Text = "Note"
Me.TabPage7.UseVisualStyleBackColor = true
'
'VerLog
'
Me.VerLog.Location = New System.Drawing.Point(7, 10)
Me.VerLog.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.VerLog.Multiline = true
Me.VerLog.Name = "VerLog"
Me.VerLog.Size = New System.Drawing.Size(900, 689)
Me.VerLog.TabIndex = 0
'
'TabPage9
'
Me.TabPage9.Controls.Add(Me.Button5)
Me.TabPage9.Controls.Add(Me.Button4)
Me.TabPage9.Controls.Add(Me.car_info)
Me.TabPage9.Controls.Add(Me.Button9)
Me.TabPage9.Controls.Add(Me.Button7)
Me.TabPage9.Controls.Add(Me.TextBox3)
Me.TabPage9.Controls.Add(Me.Button19)
Me.TabPage9.Controls.Add(Me.Button18)
Me.TabPage9.Controls.Add(Me.Button2)
Me.TabPage9.Controls.Add(Me.car_type)
Me.TabPage9.Controls.Add(Me.Button8)
Me.TabPage9.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage9.Location = New System.Drawing.Point(4, 24)
Me.TabPage9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage9.Name = "TabPage9"
Me.TabPage9.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage9.Size = New System.Drawing.Size(1606, 732)
Me.TabPage9.TabIndex = 9
Me.TabPage9.Text = "進階1"
Me.TabPage9.UseVisualStyleBackColor = true
'
'Button5
'
Me.Button5.Location = New System.Drawing.Point(14, 357)
Me.Button5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button5.Name = "Button5"
Me.Button5.Size = New System.Drawing.Size(135, 37)
Me.Button5.TabIndex = 358
Me.Button5.Text = "測試異常"
'
'Button4
'
Me.Button4.Location = New System.Drawing.Point(14, 312)
Me.Button4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button4.Name = "Button4"
Me.Button4.Size = New System.Drawing.Size(135, 37)
Me.Button4.TabIndex = 357
Me.Button4.Text = "重啟充電站"
'
'car_info
'
Me.car_info.BackColor = System.Drawing.SystemColors.ControlDark
Me.car_info.Location = New System.Drawing.Point(310, 84)
Me.car_info.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.car_info.Name = "car_info"
Me.car_info.Size = New System.Drawing.Size(175, 459)
Me.car_info.TabIndex = 9
'
'Button9
'
Me.Button9.Location = New System.Drawing.Point(14, 255)
Me.Button9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button9.Name = "Button9"
Me.Button9.Size = New System.Drawing.Size(135, 37)
Me.Button9.TabIndex = 92
Me.Button9.Text = "Reset"
'
'Button7
'
Me.Button7.Location = New System.Drawing.Point(14, 210)
Me.Button7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button7.Name = "Button7"
Me.Button7.Size = New System.Drawing.Size(135, 37)
Me.Button7.TabIndex = 91
Me.Button7.Text = "OFFLINE"
'
'TextBox3
'
Me.TextBox3.Location = New System.Drawing.Point(14, 26)
Me.TextBox3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TextBox3.Name = "TextBox3"
Me.TextBox3.Size = New System.Drawing.Size(291, 23)
Me.TextBox3.TabIndex = 337
Me.TextBox3.Text = "1"
'
'Button19
'
Me.Button19.Location = New System.Drawing.Point(309, 26)
Me.Button19.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button19.Name = "Button19"
Me.Button19.Size = New System.Drawing.Size(86, 23)
Me.Button19.TabIndex = 111
Me.Button19.Text = "板車路徑"
Me.Button19.UseVisualStyleBackColor = true
'
'Button18
'
Me.Button18.Location = New System.Drawing.Point(399, 26)
Me.Button18.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button18.Name = "Button18"
Me.Button18.Size = New System.Drawing.Size(86, 23)
Me.Button18.TabIndex = 338
Me.Button18.Text = "一般路徑"
Me.Button18.UseVisualStyleBackColor = true
'
'Button2
'
Me.Button2.Location = New System.Drawing.Point(14, 165)
Me.Button2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button2.Name = "Button2"
Me.Button2.Size = New System.Drawing.Size(135, 37)
Me.Button2.TabIndex = 4
Me.Button2.Text = "STOP"
'
'car_type
'
Me.car_type.FormattingEnabled = true
Me.car_type.Location = New System.Drawing.Point(14, 84)
Me.car_type.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.car_type.Name = "car_type"
Me.car_type.Size = New System.Drawing.Size(291, 24)
Me.car_type.TabIndex = 110
'
'Button8
'
Me.Button8.Location = New System.Drawing.Point(14, 122)
Me.Button8.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button8.Name = "Button8"
Me.Button8.Size = New System.Drawing.Size(135, 35)
Me.Button8.TabIndex = 104
Me.Button8.Text = "全部下線"
Me.Button8.UseVisualStyleBackColor = true
'
'TabPage10
'
Me.TabPage10.Controls.Add(Me.Button10)
Me.TabPage10.Controls.Add(Me.Label117)
Me.TabPage10.Controls.Add(Me.TextBox11)
Me.TabPage10.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.TabPage10.Location = New System.Drawing.Point(4, 24)
Me.TabPage10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage10.Name = "TabPage10"
Me.TabPage10.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage10.Size = New System.Drawing.Size(1606, 732)
Me.TabPage10.TabIndex = 10
Me.TabPage10.Text = "進階2"
Me.TabPage10.UseVisualStyleBackColor = true
'
'Button10
'
Me.Button10.Location = New System.Drawing.Point(826, 84)
Me.Button10.Name = "Button10"
Me.Button10.Size = New System.Drawing.Size(75, 23)
Me.Button10.TabIndex = 364
Me.Button10.Text = "Button10"
Me.Button10.UseVisualStyleBackColor = true
'
'Label117
'
Me.Label117.AutoSize = true
Me.Label117.Location = New System.Drawing.Point(8, 13)
Me.Label117.Name = "Label117"
Me.Label117.Size = New System.Drawing.Size(56, 16)
Me.Label117.TabIndex = 363
Me.Label117.Text = "電池資訊"
'
'TextBox11
'
Me.TextBox11.Location = New System.Drawing.Point(9, 33)
Me.TextBox11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TextBox11.Multiline = true
Me.TextBox11.Name = "TextBox11"
Me.TextBox11.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.TextBox11.Size = New System.Drawing.Size(768, 376)
Me.TextBox11.TabIndex = 355
'
'lbl_SC_Stats
'
Me.lbl_SC_Stats.BackColor = System.Drawing.Color.White
Me.lbl_SC_Stats.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.lbl_SC_Stats.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.lbl_SC_Stats.Location = New System.Drawing.Point(9, 172)
Me.lbl_SC_Stats.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.lbl_SC_Stats.Name = "lbl_SC_Stats"
Me.lbl_SC_Stats.Size = New System.Drawing.Size(252, 44)
Me.lbl_SC_Stats.TabIndex = 23
Me.lbl_SC_Stats.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'
'Button26
'
Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.Button26.Location = New System.Drawing.Point(140, 219)
Me.Button26.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
Me.Button26.Name = "Button26"
Me.Button26.Size = New System.Drawing.Size(120, 48)
Me.Button26.TabIndex = 22
Me.Button26.Text = "PAUSE"
Me.Button26.UseVisualStyleBackColor = true
'
'Button27
'
Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.Button27.Location = New System.Drawing.Point(9, 219)
Me.Button27.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
Me.Button27.Name = "Button27"
Me.Button27.Size = New System.Drawing.Size(120, 48)
Me.Button27.TabIndex = 21
Me.Button27.Text = "Auto"
Me.Button27.UseVisualStyleBackColor = true
'
'btn_OnlineLocal
'
Me.btn_OnlineLocal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.btn_OnlineLocal.Location = New System.Drawing.Point(140, 121)
Me.btn_OnlineLocal.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.btn_OnlineLocal.Name = "btn_OnlineLocal"
Me.btn_OnlineLocal.Size = New System.Drawing.Size(120, 48)
Me.btn_OnlineLocal.TabIndex = 7
Me.btn_OnlineLocal.Text = "On Line Local"
'
'btn_OnLineRemote
'
Me.btn_OnLineRemote.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.btn_OnLineRemote.Location = New System.Drawing.Point(9, 121)
Me.btn_OnLineRemote.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.btn_OnLineRemote.Name = "btn_OnLineRemote"
Me.btn_OnLineRemote.Size = New System.Drawing.Size(120, 48)
Me.btn_OnLineRemote.TabIndex = 6
Me.btn_OnLineRemote.Text = "On Line Remote"
'
'btn_Offline
'
Me.btn_Offline.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.btn_Offline.Location = New System.Drawing.Point(140, 68)
Me.btn_Offline.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.btn_Offline.Name = "btn_Offline"
Me.btn_Offline.Size = New System.Drawing.Size(120, 48)
Me.btn_Offline.TabIndex = 5
Me.btn_Offline.Text = "Off Line"
'
'btn_OnLine
'
Me.btn_OnLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.btn_OnLine.Location = New System.Drawing.Point(9, 68)
Me.btn_OnLine.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.btn_OnLine.Name = "btn_OnLine"
Me.btn_OnLine.Size = New System.Drawing.Size(120, 48)
Me.btn_OnLine.TabIndex = 4
Me.btn_OnLine.Text = "On Line Request"
'
'ToLocList
'
Me.ToLocList.FormattingEnabled = true
Me.ToLocList.Location = New System.Drawing.Point(1700, 712)
Me.ToLocList.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ToLocList.Name = "ToLocList"
Me.ToLocList.Size = New System.Drawing.Size(102, 23)
Me.ToLocList.TabIndex = 354
'
'CSTList
'
Me.CSTList.FormattingEnabled = true
Me.CSTList.Location = New System.Drawing.Point(1631, 712)
Me.CSTList.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.CSTList.Name = "CSTList"
Me.CSTList.Size = New System.Drawing.Size(67, 23)
Me.CSTList.TabIndex = 353
'
'Button24
'
Me.Button24.Location = New System.Drawing.Point(1804, 711)
Me.Button24.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
Me.Button24.Name = "Button24"
Me.Button24.Size = New System.Drawing.Size(70, 25)
Me.Button24.TabIndex = 24
Me.Button24.Text = "SendCmd"
Me.Button24.UseVisualStyleBackColor = true
'
'CommTxt
'
Me.CommTxt.Location = New System.Drawing.Point(11, 7)
Me.CommTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.CommTxt.Multiline = true
Me.CommTxt.Name = "CommTxt"
Me.CommTxt.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.CommTxt.Size = New System.Drawing.Size(1567, 188)
Me.CommTxt.TabIndex = 0
'
'txtCar
'
Me.txtCar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.txtCar.FormattingEnabled = true
Me.txtCar.Location = New System.Drawing.Point(1631, 743)
Me.txtCar.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.txtCar.Name = "txtCar"
Me.txtCar.Size = New System.Drawing.Size(37, 23)
Me.txtCar.TabIndex = 101
'
'SendBtn
'
Me.SendBtn.Font = New System.Drawing.Font("Microsoft JhengHei", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.SendBtn.Location = New System.Drawing.Point(1631, 774)
Me.SendBtn.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.SendBtn.Name = "SendBtn"
Me.SendBtn.Size = New System.Drawing.Size(120, 30)
Me.SendBtn.TabIndex = 93
Me.SendBtn.Text = "派貨"
Me.SendBtn.UseVisualStyleBackColor = true
'
'To_cb
'
Me.To_cb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.To_cb.FormattingEnabled = true
Me.To_cb.Location = New System.Drawing.Point(1743, 743)
Me.To_cb.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.To_cb.Name = "To_cb"
Me.To_cb.Size = New System.Drawing.Size(62, 23)
Me.To_cb.TabIndex = 81
Me.To_cb.Text = "3202"
'
'From_cb
'
Me.From_cb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.From_cb.FormattingEnabled = true
Me.From_cb.Location = New System.Drawing.Point(1675, 743)
Me.From_cb.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.From_cb.Name = "From_cb"
Me.From_cb.Size = New System.Drawing.Size(60, 23)
Me.From_cb.TabIndex = 83
Me.From_cb.Text = "3156"
'
'MainBG_timer
'
Me.MainBG_timer.Interval = 200
'
'cmd_timer
'
Me.cmd_timer.Interval = 500
'
'Log_txt
'
Me.Log_txt.Location = New System.Drawing.Point(1618, 821)
Me.Log_txt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Log_txt.Multiline = true
Me.Log_txt.Name = "Log_txt"
Me.Log_txt.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.Log_txt.Size = New System.Drawing.Size(271, 211)
Me.Log_txt.TabIndex = 82
'
'Button12
'
Me.Button12.Location = New System.Drawing.Point(1846, 821)
Me.Button12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button12.Name = "Button12"
Me.Button12.Size = New System.Drawing.Size(43, 37)
Me.Button12.TabIndex = 87
Me.Button12.Text = "清空"
Me.Button12.UseVisualStyleBackColor = true
'
'ListView1
'
Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Cmdkey, Me.AGVNo, Me.CmdFrom, Me.CmdTo, Me.Pri_Wt, Me.CMD_Status, Me.RequestTime, Me.Requestor, Me.Shelf_Car_No, Me.Shelf_Car_type, Me.Shelf_Car_Size, Me.RollData, Me.ext_cmd, Me.McsCmdKey})
Me.ListView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.ListView1.Location = New System.Drawing.Point(4, 9)
Me.ListView1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ListView1.Name = "ListView1"
Me.ListView1.Size = New System.Drawing.Size(1576, 210)
Me.ListView1.TabIndex = 2
Me.ListView1.UseCompatibleStateImageBehavior = false
Me.ListView1.View = System.Windows.Forms.View.Details
'
'Cmdkey
'
Me.Cmdkey.Tag = "A"
Me.Cmdkey.Text = "Cmdkey"
Me.Cmdkey.Width = 79
'
'AGVNo
'
Me.AGVNo.Tag = "B"
Me.AGVNo.Text = "AGVNo"
Me.AGVNo.Width = 58
'
'CmdFrom
'
Me.CmdFrom.Text = "CmdFrom"
Me.CmdFrom.Width = 62
'
'CmdTo
'
Me.CmdTo.Text = "CmdTo"
Me.CmdTo.Width = 57
'
'Pri_Wt
'
Me.Pri_Wt.Text = "Pri_Wt"
Me.Pri_Wt.Width = 58
'
'CMD_Status
'
Me.CMD_Status.Text = "CMD_Status"
Me.CMD_Status.Width = 76
'
'RequestTime
'
Me.RequestTime.Text = "RequestTime"
Me.RequestTime.Width = 79
'
'Requestor
'
Me.Requestor.Text = "Requestor"
Me.Requestor.Width = 67
'
'Shelf_Car_No
'
Me.Shelf_Car_No.Text = "Shelf_No"
Me.Shelf_Car_No.Width = 73
'
'Shelf_Car_type
'
Me.Shelf_Car_type.Text = "Shelf_type"
Me.Shelf_Car_type.Width = 86
'
'Shelf_Car_Size
'
Me.Shelf_Car_Size.Text = "Shelf_Size"
Me.Shelf_Car_Size.Width = 80
'
'RollData
'
Me.RollData.Text = "RollData"
'
'ext_cmd
'
Me.ext_cmd.Text = "ext_cmd"
'
'McsCmdKey
'
Me.McsCmdKey.Text = "McsCmdKey"
'
'ContextMenuStrip1
'
Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripMenuItem2})
Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
Me.ContextMenuStrip1.Size = New System.Drawing.Size(137, 48)
Me.ContextMenuStrip1.Text = "list"
'
'ToolStripMenuItem1
'
Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
Me.ToolStripMenuItem1.Size = New System.Drawing.Size(136, 22)
Me.ToolStripMenuItem1.Text = "Delete"
'
'ToolStripMenuItem2
'
Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
Me.ToolStripMenuItem2.Size = New System.Drawing.Size(136, 22)
Me.ToolStripMenuItem2.Text = "Add Pri_Wt"
'
'ContextMenuStrip2
'
Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem3})
Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
Me.ContextMenuStrip2.Size = New System.Drawing.Size(99, 26)
'
'ToolStripMenuItem3
'
Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
Me.ToolStripMenuItem3.Size = New System.Drawing.Size(98, 22)
Me.ToolStripMenuItem3.Text = "派貨"
'
'Label24
'
Me.Label24.BackColor = System.Drawing.SystemColors.GradientActiveCaption
Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.Label24.Location = New System.Drawing.Point(1618, 24)
Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label24.Name = "Label24"
Me.Label24.Padding = New System.Windows.Forms.Padding(0, 12, 0, 0)
Me.Label24.Size = New System.Drawing.Size(140, 50)
Me.Label24.TabIndex = 98
Me.Label24.Text = "Error:"
'
'Err_lb
'
Me.Err_lb.BackColor = System.Drawing.SystemColors.GradientActiveCaption
Me.Err_lb.Font = New System.Drawing.Font("PMingLiU", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136,Byte))
Me.Err_lb.ForeColor = System.Drawing.Color.Red
Me.Err_lb.Location = New System.Drawing.Point(1681, 24)
Me.Err_lb.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Err_lb.Name = "Err_lb"
Me.Err_lb.Size = New System.Drawing.Size(210, 50)
Me.Err_lb.TabIndex = 99
'
'door_check
'
'
'door_check_timer
'
Me.door_check_timer.Interval = 2000
'
'LFT_timer
'
Me.LFT_timer.Interval = 2000
'
'LFT_bgwork
'
'
'lbl_SECSConnectState
'
Me.lbl_SECSConnectState.BackColor = System.Drawing.Color.Red
Me.lbl_SECSConnectState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.lbl_SECSConnectState.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.lbl_SECSConnectState.Location = New System.Drawing.Point(9, 26)
Me.lbl_SECSConnectState.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.lbl_SECSConnectState.Name = "lbl_SECSConnectState"
Me.lbl_SECSConnectState.Size = New System.Drawing.Size(252, 44)
Me.lbl_SECSConnectState.TabIndex = 0
Me.lbl_SECSConnectState.Text = "Disconnection"
Me.lbl_SECSConnectState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'
'GroupBox3
'
Me.GroupBox3.Controls.Add(Me.GroupBox4)
Me.GroupBox3.Controls.Add(Me.lbl_SECSConnectState)
Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.GroupBox3.Location = New System.Drawing.Point(1618, 71)
Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox3.Name = "GroupBox3"
Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox3.Size = New System.Drawing.Size(271, 84)
Me.GroupBox3.TabIndex = 343
Me.GroupBox3.TabStop = false
Me.GroupBox3.Text = "SECS Connection State"
'
'GroupBox4
'
Me.GroupBox4.Controls.Add(Me.Label68)
Me.GroupBox4.Location = New System.Drawing.Point(9, 84)
Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox4.Name = "GroupBox4"
Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox4.Size = New System.Drawing.Size(224, 84)
Me.GroupBox4.TabIndex = 5
Me.GroupBox4.TabStop = false
Me.GroupBox4.Text = "Quick GEM init. Result"
'
'Label68
'
Me.Label68.BackColor = System.Drawing.Color.White
Me.Label68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.Label68.Location = New System.Drawing.Point(9, 26)
Me.Label68.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.Label68.Name = "Label68"
Me.Label68.Size = New System.Drawing.Size(205, 37)
Me.Label68.TabIndex = 0
Me.Label68.Text = "Result"
Me.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'
'lbl_CcontrolStats
'
Me.lbl_CcontrolStats.BackColor = System.Drawing.Color.White
Me.lbl_CcontrolStats.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
Me.lbl_CcontrolStats.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.lbl_CcontrolStats.Location = New System.Drawing.Point(9, 20)
Me.lbl_CcontrolStats.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
Me.lbl_CcontrolStats.Name = "lbl_CcontrolStats"
Me.lbl_CcontrolStats.Size = New System.Drawing.Size(252, 44)
Me.lbl_CcontrolStats.TabIndex = 1
Me.lbl_CcontrolStats.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'
'GroupBox9
'
Me.GroupBox9.Controls.Add(Me.lbl_SC_Stats)
Me.GroupBox9.Controls.Add(Me.lbl_CcontrolStats)
Me.GroupBox9.Controls.Add(Me.btn_OnLine)
Me.GroupBox9.Controls.Add(Me.Button26)
Me.GroupBox9.Controls.Add(Me.btn_Offline)
Me.GroupBox9.Controls.Add(Me.btn_OnLineRemote)
Me.GroupBox9.Controls.Add(Me.Button27)
Me.GroupBox9.Controls.Add(Me.btn_OnlineLocal)
Me.GroupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.GroupBox9.Location = New System.Drawing.Point(1618, 149)
Me.GroupBox9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox9.Name = "GroupBox9"
Me.GroupBox9.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.GroupBox9.Size = New System.Drawing.Size(271, 270)
Me.GroupBox9.TabIndex = 342
Me.GroupBox9.TabStop = false
Me.GroupBox9.Text = "Control State "
'
'MCS
'
Me.MCS.Interval = 1000
'
'EQ_BG
'
'
'MenuStrip1
'
Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SystemToolStripMenuItem, Me.QueryToolStripMenuItem, Me.ViewToolStripMenuItem})
Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
Me.MenuStrip1.Name = "MenuStrip1"
Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 1, 0, 1)
Me.MenuStrip1.Size = New System.Drawing.Size(1899, 24)
Me.MenuStrip1.TabIndex = 344
Me.MenuStrip1.Text = "MenuStrip1"
'
'SystemToolStripMenuItem
'
Me.SystemToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SCStateToolStripMenuItem})
Me.SystemToolStripMenuItem.Name = "SystemToolStripMenuItem"
Me.SystemToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
Me.SystemToolStripMenuItem.Text = "system"
'
'SCStateToolStripMenuItem
'
Me.SCStateToolStripMenuItem.Name = "SCStateToolStripMenuItem"
Me.SCStateToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
Me.SCStateToolStripMenuItem.Text = "SC State"
'
'QueryToolStripMenuItem
'
Me.QueryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TransferToolStripMenuItem, Me.CarrierToolStripMenuItem})
Me.QueryToolStripMenuItem.Name = "QueryToolStripMenuItem"
Me.QueryToolStripMenuItem.Size = New System.Drawing.Size(51, 22)
Me.QueryToolStripMenuItem.Text = "Query"
'
'TransferToolStripMenuItem
'
Me.TransferToolStripMenuItem.Name = "TransferToolStripMenuItem"
Me.TransferToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
Me.TransferToolStripMenuItem.Text = "transfer"
'
'CarrierToolStripMenuItem
'
Me.CarrierToolStripMenuItem.Name = "CarrierToolStripMenuItem"
Me.CarrierToolStripMenuItem.Size = New System.Drawing.Size(115, 22)
Me.CarrierToolStripMenuItem.Text = "Carrier"
'
'ViewToolStripMenuItem
'
Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.畫面縮小ToolStripMenuItem, Me.ZoomOutToolStripMenuItem})
Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(45, 22)
Me.ViewToolStripMenuItem.Text = "View"
'
'畫面縮小ToolStripMenuItem
'
Me.畫面縮小ToolStripMenuItem.Name = "畫面縮小ToolStripMenuItem"
Me.畫面縮小ToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
Me.畫面縮小ToolStripMenuItem.Text = "畫面縮小"
'
'ZoomOutToolStripMenuItem
'
Me.ZoomOutToolStripMenuItem.Name = "ZoomOutToolStripMenuItem"
Me.ZoomOutToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
Me.ZoomOutToolStripMenuItem.Text = "Zoom out"
'
'agv_info
'
Me.agv_info.BackColor = System.Drawing.Color.LightSeaGreen
Me.agv_info.Location = New System.Drawing.Point(1618, 420)
Me.agv_info.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
Me.agv_info.Name = "agv_info"
Me.agv_info.Size = New System.Drawing.Size(271, 393)
Me.agv_info.TabIndex = 346
Me.agv_info.TabStop = false
'
'pic_close
'
Me.pic_close.Location = New System.Drawing.Point(1858, 421)
Me.pic_close.Margin = New System.Windows.Forms.Padding(2, 1, 2, 1)
Me.pic_close.Name = "pic_close"
Me.pic_close.Size = New System.Drawing.Size(30, 35)
Me.pic_close.TabIndex = 348
Me.pic_close.Text = "X"
Me.pic_close.UseVisualStyleBackColor = true
'
'rolldateTxt
'
Me.rolldateTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.rolldateTxt.Location = New System.Drawing.Point(1809, 744)
Me.rolldateTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.rolldateTxt.Name = "rolldateTxt"
Me.rolldateTxt.Size = New System.Drawing.Size(65, 24)
Me.rolldateTxt.TabIndex = 353
'
'Button16
'
Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.Button16.Location = New System.Drawing.Point(1756, 774)
Me.Button16.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Button16.Name = "Button16"
Me.Button16.Size = New System.Drawing.Size(120, 30)
Me.Button16.TabIndex = 356
Me.Button16.Text = "Lock"
Me.Button16.UseVisualStyleBackColor = true
'
'TabControl2
'
Me.TabControl2.Controls.Add(Me.TabPage11)
Me.TabControl2.Controls.Add(Me.TabPage12)
Me.TabControl2.Controls.Add(Me.TabPage13)
Me.TabControl2.Controls.Add(Me.TabPage14)
Me.TabControl2.Location = New System.Drawing.Point(5, 783)
Me.TabControl2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabControl2.Name = "TabControl2"
Me.TabControl2.SelectedIndex = 0
Me.TabControl2.Size = New System.Drawing.Size(1606, 260)
Me.TabControl2.TabIndex = 354
'
'TabPage11
'
Me.TabPage11.Controls.Add(Me.ListView1)
Me.TabPage11.Location = New System.Drawing.Point(4, 24)
Me.TabPage11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage11.Name = "TabPage11"
Me.TabPage11.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage11.Size = New System.Drawing.Size(1598, 232)
Me.TabPage11.TabIndex = 0
Me.TabPage11.Text = "CmdList"
Me.TabPage11.UseVisualStyleBackColor = true
'
'TabPage12
'
Me.TabPage12.Controls.Add(Me.alarm_list)
Me.TabPage12.Location = New System.Drawing.Point(4, 24)
Me.TabPage12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage12.Name = "TabPage12"
Me.TabPage12.Padding = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.TabPage12.Size = New System.Drawing.Size(1598, 232)
Me.TabPage12.TabIndex = 1
Me.TabPage12.Text = "Alarm"
Me.TabPage12.UseVisualStyleBackColor = true
'
'alarm_list
'
Me.alarm_list.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10})
Me.alarm_list.Location = New System.Drawing.Point(7, 10)
Me.alarm_list.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.alarm_list.Name = "alarm_list"
Me.alarm_list.Size = New System.Drawing.Size(1475, 210)
Me.alarm_list.TabIndex = 361
Me.alarm_list.UseCompatibleStateImageBehavior = false
Me.alarm_list.View = System.Windows.Forms.View.Details
'
'ColumnHeader1
'
Me.ColumnHeader1.Tag = "A"
Me.ColumnHeader1.Text = "cmd_idx"
Me.ColumnHeader1.Width = 79
'
'ColumnHeader2
'
Me.ColumnHeader2.Tag = "B"
Me.ColumnHeader2.Text = "AGV"
Me.ColumnHeader2.Width = 86
'
'ColumnHeader3
'
Me.ColumnHeader3.Text = "HAPPEN_DATE"
Me.ColumnHeader3.Width = 160
'
'ColumnHeader4
'
Me.ColumnHeader4.Text = "CLEAR_DATE"
Me.ColumnHeader4.Width = 160
'
'ColumnHeader5
'
Me.ColumnHeader5.Text = "ALM_ID"
Me.ColumnHeader5.Width = 84
'
'ColumnHeader6
'
Me.ColumnHeader6.Text = "ALM_MSG"
Me.ColumnHeader6.Width = 260
'
'ColumnHeader7
'
Me.ColumnHeader7.Text = "SUB_LOC"
Me.ColumnHeader7.Width = 79
'
'ColumnHeader8
'
Me.ColumnHeader8.Text = "CarrierID"
Me.ColumnHeader8.Width = 67
'
'ColumnHeader9
'
Me.ColumnHeader9.Text = "CmdFrom"
Me.ColumnHeader9.Width = 90
'
'ColumnHeader10
'
Me.ColumnHeader10.Text = "CmdTo"
Me.ColumnHeader10.Width = 90
'
'TabPage13
'
Me.TabPage13.Controls.Add(Me.ListView2)
Me.TabPage13.Location = New System.Drawing.Point(4, 24)
Me.TabPage13.Name = "TabPage13"
Me.TabPage13.Padding = New System.Windows.Forms.Padding(3)
Me.TabPage13.Size = New System.Drawing.Size(1598, 232)
Me.TabPage13.TabIndex = 2
Me.TabPage13.Text = "CMD"
Me.TabPage13.UseVisualStyleBackColor = true
'
'ListView2
'
Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.CarrierID, Me.CmdId, Me.Pwt, Me.CurZone, Me.CurLoc, Me.ToZone, Me.State, Me.ColumnHeader16, Me.ColumnHeader11, Me.ColumnHeader12, Me.soure, Me.ColumnHeader13})
Me.ListView2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.ListView2.Location = New System.Drawing.Point(-3, 11)
Me.ListView2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.ListView2.Name = "ListView2"
Me.ListView2.Size = New System.Drawing.Size(1196, 230)
Me.ListView2.TabIndex = 3
Me.ListView2.UseCompatibleStateImageBehavior = false
Me.ListView2.View = System.Windows.Forms.View.Details
'
'CarrierID
'
Me.CarrierID.Tag = "A"
Me.CarrierID.Text = "CarrierID"
Me.CarrierID.Width = 79
'
'CmdId
'
Me.CmdId.Tag = "B"
Me.CmdId.Text = "CmdId"
Me.CmdId.Width = 58
'
'Pwt
'
Me.Pwt.Text = "Pwt"
Me.Pwt.Width = 62
'
'CurZone
'
Me.CurZone.Text = "CurZone"
Me.CurZone.Width = 90
'
'CurLoc
'
Me.CurLoc.Text = "CurLoc"
Me.CurLoc.Width = 90
'
'ToZone
'
Me.ToZone.Text = "ToZone"
Me.ToZone.Width = 90
'
'State
'
Me.State.Text = "State"
Me.State.Width = 120
'
'ColumnHeader16
'
Me.ColumnHeader16.Text = "Requestor"
Me.ColumnHeader16.Width = 80
'
'ColumnHeader11
'
Me.ColumnHeader11.Text = "SerialNo"
'
'ColumnHeader12
'
Me.ColumnHeader12.Text = "PROCESSID"
'
'soure
'
Me.soure.Text = "soure"
'
'ColumnHeader13
'
Me.ColumnHeader13.Text = "Distance"
'
'TabPage14
'
Me.TabPage14.Controls.Add(Me.CommTxt)
Me.TabPage14.Location = New System.Drawing.Point(4, 24)
Me.TabPage14.Name = "TabPage14"
Me.TabPage14.Padding = New System.Windows.Forms.Padding(3)
Me.TabPage14.Size = New System.Drawing.Size(1598, 232)
Me.TabPage14.TabIndex = 3
Me.TabPage14.Text = "MCSLog"
Me.TabPage14.UseVisualStyleBackColor = true
'
'ContextMenuStrip3
'
Me.ContextMenuStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteToolStripMenuItem, Me.AddpwtToolStripMenuItem})
Me.ContextMenuStrip3.Name = "ContextMenuStrip3"
Me.ContextMenuStrip3.Size = New System.Drawing.Size(134, 48)
'
'DeleteToolStripMenuItem
'
Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
Me.DeleteToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
Me.DeleteToolStripMenuItem.Text = "Delete"
'
'AddpwtToolStripMenuItem
'
Me.AddpwtToolStripMenuItem.Name = "AddpwtToolStripMenuItem"
Me.AddpwtToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
Me.AddpwtToolStripMenuItem.Text = "Add_PriWt"
'
'BG_Update
'
'
'Hik_Car
'
Me.Hik_Car.Interval = 1000
'
'HIK_BG
'
'
'Form1
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(7!, 15!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.ClientSize = New System.Drawing.Size(1899, 1041)
Me.Controls.Add(Me.ToLocList)
Me.Controls.Add(Me.CSTList)
Me.Controls.Add(Me.TabControl2)
Me.Controls.Add(Me.Button16)
Me.Controls.Add(Me.Button24)
Me.Controls.Add(Me.rolldateTxt)
Me.Controls.Add(Me.SendBtn)
Me.Controls.Add(Me.txtCar)
Me.Controls.Add(Me.To_cb)
Me.Controls.Add(Me.From_cb)
Me.Controls.Add(Me.pic_close)
Me.Controls.Add(Me.agv_info)
Me.Controls.Add(Me.MenuStrip1)
Me.Controls.Add(Me.GroupBox3)
Me.Controls.Add(Me.GroupBox9)
Me.Controls.Add(Me.Err_lb)
Me.Controls.Add(Me.Label24)
Me.Controls.Add(Me.Button12)
Me.Controls.Add(Me.Log_txt)
Me.Controls.Add(Me.TabControl1)
Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
Me.MainMenuStrip = Me.MenuStrip1
Me.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
Me.Name = "Form1"
Me.Text = "IMBS HIK 1.0.1"
Me.TabControl1.ResumeLayout(false)
Me.TabPage1.ResumeLayout(false)
Me.TabPage1.PerformLayout
CType(Me.PictureBox1,System.ComponentModel.ISupportInitialize).EndInit
Me.TabPage2.ResumeLayout(false)
Me.TabPage2.PerformLayout
Me.GroupBox5.ResumeLayout(false)
Me.GroupBox5.PerformLayout
Me.GroupBox2.ResumeLayout(false)
Me.GroupBox2.PerformLayout
Me.GroupBox1.ResumeLayout(false)
Me.GroupBox1.PerformLayout
Me.TabPage3.ResumeLayout(false)
Me.TabPage3.PerformLayout
Me.TabPage5.ResumeLayout(false)
Me.TabPage5.PerformLayout
Me.TabPage4.ResumeLayout(false)
Me.TabPage4.PerformLayout
Me.TabPage6.ResumeLayout(false)
Me.TabPage6.PerformLayout
Me.TabPage7.ResumeLayout(false)
Me.TabPage7.PerformLayout
Me.TabPage9.ResumeLayout(false)
Me.TabPage9.PerformLayout
Me.TabPage10.ResumeLayout(false)
Me.TabPage10.PerformLayout
Me.ContextMenuStrip1.ResumeLayout(false)
Me.ContextMenuStrip2.ResumeLayout(false)
Me.GroupBox3.ResumeLayout(false)
Me.GroupBox4.ResumeLayout(false)
Me.GroupBox9.ResumeLayout(false)
Me.MenuStrip1.ResumeLayout(false)
Me.MenuStrip1.PerformLayout
CType(Me.agv_info,System.ComponentModel.ISupportInitialize).EndInit
Me.TabControl2.ResumeLayout(false)
Me.TabPage11.ResumeLayout(false)
Me.TabPage12.ResumeLayout(false)
Me.TabPage13.ResumeLayout(false)
Me.TabPage14.ResumeLayout(false)
Me.TabPage14.PerformLayout
Me.ContextMenuStrip3.ResumeLayout(false)
Me.ResumeLayout(false)
Me.PerformLayout

End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As System.Windows.Forms.Button

    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Econ_20 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_16 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_15 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_14 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_13 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_12 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_11 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_10 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Econ_9 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_8 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_7 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_6 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_5 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_4 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_3 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_2 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_1 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_0 As System.Windows.Forms.TextBox
    Friend WithEvents MainBG_timer As System.Windows.Forms.Timer
    Friend WithEvents cmd_timer As System.Windows.Forms.Timer
    Friend WithEvents car_info As System.Windows.Forms.Label
    Friend WithEvents To_cb As System.Windows.Forms.ComboBox
    Friend WithEvents Log_txt As System.Windows.Forms.TextBox
    Friend WithEvents From_cb As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents Cmdkey As System.Windows.Forms.ColumnHeader
    Friend WithEvents AGVNo As System.Windows.Forms.ColumnHeader
    Friend WithEvents CmdFrom As System.Windows.Forms.ColumnHeader
    Friend WithEvents CmdTo As System.Windows.Forms.ColumnHeader
    Friend WithEvents CMD_Status As System.Windows.Forms.ColumnHeader
    Friend WithEvents Pri_Wt As System.Windows.Forms.ColumnHeader
    Friend WithEvents RequestTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents Requestor As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV3 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV2 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV1 As System.Windows.Forms.TextBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV4 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV5 As System.Windows.Forms.TextBox
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents WorkList As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Agvc_shelfcheck As System.Windows.Forms.CheckBox
    Friend WithEvents SendBtn As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Econ_17 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents Shelf_Car_Pic9 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic8 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic7 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic6 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic5 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic4 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic3 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic2 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic1 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic0 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_type As System.Windows.Forms.ColumnHeader
    Friend WithEvents Shelf_Car_No As System.Windows.Forms.ColumnHeader
    Friend WithEvents Shelf_Car_Size As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Err_lb As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic10 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV18 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV19 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV17 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV16 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV15 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV13 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV14 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV12 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV11 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV10 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV9 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV0 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV8 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV7 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV6 As System.Windows.Forms.TextBox
    Friend WithEvents door_check As System.ComponentModel.BackgroundWorker
    Friend WithEvents door_check_timer As System.Windows.Forms.Timer
    Friend WithEvents MyDB_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV20 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents txtFrom As System.Windows.Forms.TextBox
    Friend WithEvents txtTo As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtCar As System.Windows.Forms.ComboBox
    Friend WithEvents strReserve_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents txtTemp_to As System.Windows.Forms.TextBox
    Friend WithEvents Shelf_Car_Pic21 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic20 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic19 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic18 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic17 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic16 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic15 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic14 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic13 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic12 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic11 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic25 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic24 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic23 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic22 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Door_Data_txt As System.Windows.Forms.TextBox
    Friend WithEvents Door_idx As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Econ_19 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_18 As System.Windows.Forms.TextBox
    Friend WithEvents LPort As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Loading_Check As System.Windows.Forms.CheckBox
    Friend WithEvents Shelf_Car_Pic40 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic39 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic38 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic37 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic36 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic35 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic34 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic33 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic32 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic31 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic30 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic29 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic28 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic27 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic26 As System.Windows.Forms.Label
    Friend WithEvents LFT3 As System.Windows.Forms.Label
    Friend WithEvents LFT2 As System.Windows.Forms.Label
    Friend WithEvents LFT1 As System.Windows.Forms.Label
    Friend WithEvents LFT0 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents LFT_idx As System.Windows.Forms.ComboBox
    Friend WithEvents LFT_W15 As System.Windows.Forms.Label
    Friend WithEvents LFT_W14 As System.Windows.Forms.Label
    Friend WithEvents LFT_W13 As System.Windows.Forms.Label
    Friend WithEvents LFT_W12 As System.Windows.Forms.Label
    Friend WithEvents LFT_W11 As System.Windows.Forms.Label
    Friend WithEvents LFT_W10 As System.Windows.Forms.Label
    Friend WithEvents LFT_W9 As System.Windows.Forms.Label
    Friend WithEvents LFT_W8 As System.Windows.Forms.Label
    Friend WithEvents LFT_W7 As System.Windows.Forms.Label
    Friend WithEvents LFT_W6 As System.Windows.Forms.Label
    Friend WithEvents LFT_W5 As System.Windows.Forms.Label
    Friend WithEvents LFT_W4 As System.Windows.Forms.Label
    Friend WithEvents LFT_W3 As System.Windows.Forms.Label
    Friend WithEvents LFT_W2 As System.Windows.Forms.Label
    Friend WithEvents LFT_W1 As System.Windows.Forms.Label
    Friend WithEvents LFT_W0 As System.Windows.Forms.Label
    Friend WithEvents LFT_FLOOR As System.Windows.Forms.Label
    Friend WithEvents LFT_R15 As System.Windows.Forms.Label
    Friend WithEvents LFT_R14 As System.Windows.Forms.Label
    Friend WithEvents LFT_R13 As System.Windows.Forms.Label
    Friend WithEvents LFT_R12 As System.Windows.Forms.Label
    Friend WithEvents LFT_R11 As System.Windows.Forms.Label
    Friend WithEvents LFT_R10 As System.Windows.Forms.Label
    Friend WithEvents LFT_R9 As System.Windows.Forms.Label
    Friend WithEvents LFT_R8 As System.Windows.Forms.Label
    Friend WithEvents LFT_R7 As System.Windows.Forms.Label
    Friend WithEvents LFT_R6 As System.Windows.Forms.Label
    Friend WithEvents LFT_R5 As System.Windows.Forms.Label
    Friend WithEvents LFT_R4 As System.Windows.Forms.Label
    Friend WithEvents LFT_R3 As System.Windows.Forms.Label
    Friend WithEvents LFT_R2 As System.Windows.Forms.Label
    Friend WithEvents LFT_R1 As System.Windows.Forms.Label
    Friend WithEvents LFT_R0 As System.Windows.Forms.Label
    Friend WithEvents LFT_timer As System.Windows.Forms.Timer
    Friend WithEvents LFT_bgwork As System.ComponentModel.BackgroundWorker
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents opendata As System.Windows.Forms.Label
    Friend WithEvents Car_text As System.Windows.Forms.Label
    Friend WithEvents step_text As System.Windows.Forms.Label
    Friend WithEvents IR_check As System.Windows.Forms.CheckBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Group_path_text As System.Windows.Forms.TextBox
    Friend WithEvents RollData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ALL_Loading_check As System.Windows.Forms.CheckBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic90 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic89 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic88 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic87 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic86 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic85 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic84 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic83 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic82 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic81 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic80 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic79 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic78 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic77 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic76 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic75 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic74 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic73 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic72 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic71 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic70 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic69 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic68 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic67 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic66 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic65 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic64 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic63 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic62 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic61 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic60 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic59 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic58 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic57 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic56 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic55 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic54 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic53 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic52 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic51 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic50 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic49 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic48 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic47 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic46 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic45 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic44 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic43 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic42 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic41 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic280 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic279 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic278 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic277 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic276 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic275 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic274 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic273 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic272 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic271 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic270 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic269 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic268 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic267 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic266 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic265 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic263 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic264 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic262 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic261 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic260 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic259 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic258 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic257 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic256 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic255 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic254 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic253 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic252 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic251 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic250 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic249 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic248 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic247 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic246 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic245 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic244 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic243 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic242 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic241 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic240 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic239 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic238 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic237 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic236 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic235 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic234 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic233 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic232 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic231 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic230 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic229 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic228 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic227 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic226 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic225 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic224 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic223 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic222 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic221 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic220 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic219 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic218 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic217 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic216 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic215 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic214 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic213 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic212 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic211 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic210 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic209 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic208 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic207 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic206 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic205 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic204 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic203 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic202 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic201 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic200 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic199 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic198 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic197 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic196 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic195 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic194 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic193 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic192 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic191 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic190 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic189 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic188 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic187 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic186 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic185 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic184 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic183 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic182 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic181 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic180 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic179 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic178 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic177 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic176 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic175 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic174 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic173 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic172 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic171 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic170 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic169 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic168 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic167 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic166 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic165 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic164 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic163 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic162 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic161 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic160 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic159 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic158 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic157 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic156 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic155 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic154 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic153 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic152 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic151 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic150 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic149 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic148 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic147 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic146 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic145 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic144 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic143 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic142 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic141 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic140 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic139 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic138 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic137 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic136 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic135 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic134 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic133 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic132 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic131 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic130 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic129 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic128 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic127 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic126 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic125 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic124 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic123 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic122 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic121 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic120 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic119 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic118 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic117 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic116 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic115 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic114 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic113 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic112 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic111 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic110 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic109 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic108 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic107 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic106 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic105 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic104 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic103 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic102 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic101 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic100 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic99 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic98 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic97 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic96 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic95 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic94 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic93 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic92 As System.Windows.Forms.Label
    Friend WithEvents Shelf_Car_Pic91 As System.Windows.Forms.Label
    Friend WithEvents LFT6 As System.Windows.Forms.Label
    Friend WithEvents LFT5 As System.Windows.Forms.Label
    Friend WithEvents LFT4 As System.Windows.Forms.Label
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents LFT_name As System.Windows.Forms.Label
    Friend WithEvents car_type As System.Windows.Forms.ComboBox
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents ext_cmd As System.Windows.Forms.ColumnHeader
    Friend WithEvents IP As System.Windows.Forms.TextBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents user_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents password_txt As System.Windows.Forms.TextBox
    Friend WithEvents DebugMode As System.Windows.Forms.CheckBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents VerLog As System.Windows.Forms.TextBox
    Friend WithEvents DoorSetLenTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents AgvTimeout As System.Windows.Forms.TextBox
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents CommTxt As System.Windows.Forms.TextBox
    Friend WithEvents lbl_SECSConnectState As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents lbl_CcontrolStats As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents lbl_SC_Stats As System.Windows.Forms.Label
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents btn_OnlineLocal As System.Windows.Forms.Button
    Friend WithEvents btn_OnLineRemote As System.Windows.Forms.Button
    Friend WithEvents btn_Offline As System.Windows.Forms.Button
    Friend WithEvents btn_OnLine As System.Windows.Forms.Button
    Friend WithEvents MCS As System.Windows.Forms.Timer
    Friend WithEvents EQ_BG As System.ComponentModel.BackgroundWorker
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SystemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SCStateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QueryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransferToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CarrierToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents McsCmdKey As System.Windows.Forms.ColumnHeader
    Friend WithEvents agv_info As System.Windows.Forms.PictureBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Econ_30 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_29 As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Econ_28 As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Econ_27 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_26 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_25 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_24 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_23 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_22 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_21 As System.Windows.Forms.TextBox
    Friend WithEvents pic_close As System.Windows.Forms.Button
    Friend WithEvents ratio As System.Windows.Forms.TextBox
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents rolldateTxt As System.Windows.Forms.TextBox
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents CstID As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Econ_39 As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Econ_38 As System.Windows.Forms.TextBox
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Econ_37 As System.Windows.Forms.TextBox
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Econ_36 As System.Windows.Forms.TextBox
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Econ_35 As System.Windows.Forms.TextBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Econ_34 As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Econ_33 As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Econ_32 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Econ_31 As System.Windows.Forms.TextBox
    Friend WithEvents AGVIO2_15 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_14 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_13 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_12 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_11 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_10 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_09 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_08 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_07 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_06 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_05 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_04 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_03 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_02 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_01 As System.Windows.Forms.Label
    Friend WithEvents AGVIO2_00 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_15 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_10 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_14 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_13 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_12 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_11 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_09 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_08 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_07 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_06 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_05 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_04 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_03 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_02 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_01 As System.Windows.Forms.Label
    Friend WithEvents AGVIO1_00 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_15 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_14 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_13 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_12 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_11 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_10 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_09 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_08 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_07 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_06 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_05 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_04 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_03 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_02 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_01 As System.Windows.Forms.Label
    Friend WithEvents AGVIO4_00 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_15 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_14 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_13 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_12 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_11 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_10 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_09 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_08 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_07 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_06 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_05 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_04 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_03 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_02 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_01 As System.Windows.Forms.Label
    Friend WithEvents AGVIO3_00 As System.Windows.Forms.Label
    Friend WithEvents McsPortTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents alarm_list As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Err211 As System.Windows.Forms.CheckBox
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Econ_49 As System.Windows.Forms.TextBox
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Econ_48 As System.Windows.Forms.TextBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Econ_47 As System.Windows.Forms.TextBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Econ_46 As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Econ_45 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Econ_44 As System.Windows.Forms.TextBox
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Econ_43 As System.Windows.Forms.TextBox
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Econ_42 As System.Windows.Forms.TextBox
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Econ_41 As System.Windows.Forms.TextBox
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Econ_40 As System.Windows.Forms.TextBox
    Friend WithEvents SOCTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label100 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents ToLocList As System.Windows.Forms.ComboBox
    Friend WithEvents CSTList As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage13 As System.Windows.Forms.TabPage
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents CarrierID As System.Windows.Forms.ColumnHeader
    Friend WithEvents CmdId As System.Windows.Forms.ColumnHeader
    Friend WithEvents Pwt As System.Windows.Forms.ColumnHeader
    Friend WithEvents CurZone As System.Windows.Forms.ColumnHeader
    Friend WithEvents CurLoc As System.Windows.Forms.ColumnHeader
    Friend WithEvents ToZone As System.Windows.Forms.ColumnHeader
    Friend WithEvents State As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents BlockPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label101 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Recharge_volt As System.Windows.Forms.TextBox
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents AGV_SetNo As System.Windows.Forms.ComboBox
    Friend WithEvents SetOffset_X As System.Windows.Forms.TextBox
    Friend WithEvents Label110 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Recharge_SOC As System.Windows.Forms.TextBox
    Friend WithEvents Setheight As System.Windows.Forms.TextBox
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Recharge_Point As System.Windows.Forms.TextBox
    Friend WithEvents Setwidth As System.Windows.Forms.TextBox
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents wait_point As System.Windows.Forms.TextBox
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents block_point As System.Windows.Forms.TextBox
    Friend WithEvents ReverseXY As System.Windows.Forms.TextBox
    Friend WithEvents Label112 As System.Windows.Forms.Label
    Friend WithEvents SetOffset_Y As System.Windows.Forms.TextBox
    Friend WithEvents Label111 As System.Windows.Forms.Label
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents RePath As System.Windows.Forms.TextBox
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents MaxPath As System.Windows.Forms.TextBox
    Friend WithEvents Label113 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents MapY As System.Windows.Forms.TextBox
    Friend WithEvents MapX As System.Windows.Forms.TextBox
    Friend WithEvents ContextMenuStrip3 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddpwtToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage14 As System.Windows.Forms.TabPage
    Friend WithEvents Label114 As System.Windows.Forms.Label
    Friend WithEvents block_Path As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents SiteTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label115 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents RetreatPath As System.Windows.Forms.TextBox
    Friend WithEvents Label116 As System.Windows.Forms.Label
    Friend WithEvents soure As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label117 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents BG_Update As System.ComponentModel.BackgroundWorker
    Friend WithEvents 畫面縮小ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Hik_Car As System.Windows.Forms.Timer
    Friend WithEvents HIK_BG As System.ComponentModel.BackgroundWorker

End Class
