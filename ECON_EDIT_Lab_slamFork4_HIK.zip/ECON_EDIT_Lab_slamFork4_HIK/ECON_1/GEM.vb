﻿Imports System.IO
Public Class GEM
    Public Const SC_NONE As Integer = 0
    Public Const SC_INIT As Integer = 1
    Public Const SC_PAUSED As Integer = 2
    Public Const SC_AUTO As Integer = 3
    Public Const SC_PAUSING As Integer = 4

    Public Const SC_NOALARM As Integer = 8
    Public Const SC_ALARMS As Integer = 7

    Public Const OfflineEQval As Integer = 1
    Public Const OfflineAttemptOnLineval As Integer = 2
    Public Const OfflineHostOfflineval As Integer = 3
    Public Const OnlineLoaclval As Integer = 4
    Public Const OnlineRemoteval As Integer = 5

    Public Const CS_NONE As Integer = 0
    Public Const CS_WAITIN As Integer = 1
    Public Const CS_WAITOUT As Integer = 2
    Public Const CS_TRANSFERRING As Integer = 3
    Public Const CS_STOREDCOMPLETED As Integer = 4
    Public Const CS_STOREDALTERMATE As Integer = 5
    Public Const CS_BLOCKED As Integer = 6
    Public Const CS_Prohibition As Integer = 7

    Public Const ZONE_TYPE_SHELF As Integer = 1
    Public Const ZONE_TYPE_PORT As Integer = 2
    Public Const ZONE_TYPE_Other As Integer = 3


    Public Const TransferState_Queued = 1
    Public Const TransferState_Transferring = 2
    Public Const TransferState_Paused = 3
    Public Const TransferState_Canceling = 4
    Public Const TransferState_Aborting = 5

    Public reportlist() As report
    Public SVList() As VID
    Public DVList() As VID
    Public EqConstantList() As ECList

    Public LinkReport(100) As LinkEvenReport
    Dim McsReport(100) As GEM.report
    'VID adress define
    Private comQSWrapper As New SECSComm
    Private SendID As Integer = 0
    Private Sendtime As Date = Now()
    Private SendSF As String = ""
    Event QGEvent(lID As Integer, s As Integer, f As Integer, w_Bit As Integer, systemBytes As UInteger, rawData As Object, length As Integer)
    Public CST(200) As Carrier
    Public ShelfData(500) As shelf
    Public EqPort(200) As Eqp
    Public Zone(5) As ActiveZone

    Public Eqpname As String

    Public Const EVENT_TransferInitiated = 108
    Public Const EVENT_TransferCanselInitiated = 106
    Public Const EVENT_TransferCancelCompleted = 104
    Public Const EVENT_TransferCancelFailed = 105
    Public Const EVENT_TransferPaused = 109
    Public Const EVENT_TransferResumed = 110
    Public Const EVENT_TransferCompleted = 107
    Public Const EVENT_TransferAbortInitiated = 103
    Public Const EVENT_TransferAbortCompleted = 101
    Public Const EVENT_TransferAbortFailed = 102
    Public Const EVENT_CarrierWaitIn = 158
    Public Const EVENT_CarrierTransferring = 157
    Public Const EVENT_CarrierStored = 155
    Public Const EVENT_CarrierWaitOut = 159
    Public Const EVENT_CarrierRemoved = 153
    Public Const EVENT_CarrierStoredAlt = 156
    Public Const EVENT_CarrierResumed = 154
    Public Const EVENT_CarrierInstallCompleted = 151
    Public Const EVENT_CarrierRemoveCompleted = 152
    Public Const EVENT_CraneActive = 201
    Public Const EVENT_CraneIdle = 202
    Public Const EVENT_ZoneCapacityCange = 160
    Public Const EVENT_CarrierIDRead = 251
    Public Const EVENT_IDReadError = 253
    Public Const EVENT_EquipmentOffline = 1
    Public Const EVENT_OnlineLocal = 2
    Public Const EVENT_OnlineRemote = 3
    Public Const EVENT_STKCAutoInitiated = 54
    Public Const EVENT_STKCAutoCompleted = 53
    Public Const EVENT_STKCPauseInitiated = 57
    Public Const EVENT_STKCPaused = 56
    Public Const EVENT_STKCPauseCompleted = 55
    Public Const EVENT_AlarmSet = 52
    Public Const EVENT_AlarmCleared = 51
    Public Const EVENT_PortInService = 301
    Public Const EVENT_PortOutOfService = 302
    Public Const EVENT_PortTypeChanged = 3015
    Public Const EVENT_LoadRequestReport = 3280
    Public Const EVENT_PortTypeChanging = 3010
    Public Const EVENT_UnitAlarmCleared = 503
    Public Const EVENT_UnitAlarmSet = 504
    Public Const EVENT_DisableLocationChange = 3700

    Function ReplySECS(ByVal S As Byte, ByVal F As Byte, ByVal wBit As Byte, ByVal ulSystemBytes As Long, ByVal rawdata() As Byte, ByRef outputdata() As Byte) As Long
        ReplySECS = 0

    End Function
    Structure ActiveZone
        Dim ZoneName As String
        Dim ZoneCapacity As UInt16
        Dim ZoneSize As UInt16
        Dim ZoneType As UInt16
        Dim DisabledLocations As String
        Dim pre_ZoneCapacity As UInt16
        Dim CST_count As UInt16

    End Structure
    Structure shelf
        Dim STK_Name As String
        Dim Shelf_Loc As String
        Dim Shelf_Bank As Integer
        Dim Shelf_Column As Integer
        Dim Shelf_Level As Integer
        Dim Zone_Name As String
        Dim Shelf_Status As String
        Dim AVAIL_FLAG As String

        Dim CarrierID As String
        Dim UPDATE_REASON As String
        Dim AXIS_X As Integer
        Dim AXIS_Y As Integer

        Dim tag_id As Integer
        Dim SHELF_STN_NO As Integer
    End Structure
    Structure Eqp
        Dim PortID As String
        Dim LoadAvail As Integer
        Dim UnLoadAvail As Integer
        Dim PortTransferState As UInt16
        Dim ip As String
        Dim port As Integer
        Dim adr As Integer
        Dim ONLINE As Byte
        Dim ERR As Byte
        Dim READY As Byte
        Dim LOADED As Byte

        Dim AXIS_X As Integer
        Dim AXIS_Y As Integer
        Dim tag_id As Integer

        Dim state As String
        Dim PreState As String
        Dim PreStateTime As String
    End Structure

    Structure report
        Dim flag As Boolean
        Dim reportid As UInt32
        'Dim len As Integer
        Dim vid() As UInt32
        Dim CEID As Integer 'event id
        Dim EventName As String
        Dim Description As String
    End Structure
    Structure VID
        Dim vid As UInt32
        Dim VarName As String
        Dim VarClass As String
        Dim format As Integer
        Dim val As Object
        Dim Description As String
    End Structure
    Structure LinkEvenReport
        Dim CEID As UInt32
        Dim RPTID() As UInt32
        Dim EventName As String
        Dim Description As String
    End Structure

    Structure ECList
        Dim ECID As Integer
        Dim ECNAME As String
        Dim ECMIN As Object
        Dim ECMAN As Object
        Dim ECDEF As String
        Dim UNITS As String
        Dim ECV As Object
        Dim format As Integer
    End Structure
    Structure ALARM
        Dim ALCD As Byte
        'bit7 State bit0~6 Classification
        Dim ALID As UInt32
        '1 Occurrence/Release by Operator
        '2 Occurrence/Release by EQ
        '5 Recovery Impossible
        '6 warning 
        '7 Caution 
        '8 other
        Dim ALTX As String
        Function GetALCD(ByVal State As Byte, ByVal Classification As Byte)
            GetALCD = (State > 7) + Classification
        End Function

    End Structure
    Structure Carrier
        Dim CommandID As String '58
        Dim CarrierID As String '54
        Dim CarrierLoc As String '56
        Dim CarrierZoneName As String '370

        Dim handoftype As UInt16 '64
        Dim StockerCraneID As String '450
        Dim IDReadStatus As UInt16 '65
        Dim InstallTime As String '340
        Dim Pre_CarrierState As UInt16 '310
        Dim CarrierState As UInt16 '310
        Dim CarrierType As String  '5000

        Dim ResultCode As UInt16 '69
        Dim EmptyCarrier As UInt16
        Dim NEXTDest As String
        Dim SOURCE As String
        Dim DEST As String
        ' Dim EMPTYFLAG As String
        Dim PROCESSID As String
        Dim PRIORITY As UInt16
        Dim TransferState As UInt16 '1:Queued 2Transferring 3Paused 4Canceling 5 Aborting
        Dim note As String
        Dim tagid As Integer
        Dim EQ_Retry As Integer
        Dim mcstime As Long
        Dim distance As Long

        Sub del()
            CommandID = ""
            CarrierID = ""
            CarrierLoc = ""
            CarrierZoneName = ""
            handoftype = 0
            StockerCraneID = ""
            IDReadStatus = 0
            InstallTime = ""
            CarrierState = 0
            CarrierType = ""
            ResultCode = 0
            EmptyCarrier = 0
            NEXTDest = ""
            SOURCE = ""
            PROCESSID = ""
            PRIORITY = 0
            TransferState = 0
            note = ""
            EQ_Retry = 0
        End Sub

        Function GetValByVid(ByVal vid As Integer) As Object
            GetValByVid = Nothing
            Select Case vid
                Case 58
                    GetValByVid = CommandID
                Case 54
                    GetValByVid = CarrierID
                Case 56
                    GetValByVid = CarrierLoc
                Case 370
                    GetValByVid = CarrierZoneName
                Case 5000
                    GetValByVid = CarrierType
                Case 64
                    GetValByVid = handoftype
                Case 450
                    GetValByVid = StockerCraneID
                Case 65
                    GetValByVid = IDReadStatus

                Case 60
                    GetValByVid = DEST
                Case 61
                    GetValByVid = DEST
                Case 69
                    GetValByVid = ResultCode
                Case 310
                    GetValByVid = CarrierState
                Case 340
                    GetValByVid = InstallTime
                Case 5000
                    GetValByVid = CarrierType
            End Select

        End Function

        Sub SetValByName(ByVal VidName As String, ByVal val As Object)
            Try
                Select Case VidName
                    Case "COMMANDID"
                        CommandID = val
                    Case "PRIORITY"
                        PRIORITY = val(0)
                    Case "CARRIERID"
                        CarrierID = val
                    Case "SOURCE"
                        SOURCE = val
                    Case "DEST"
                        DEST = val
                    Case "NEXT"
                        NEXTDest = val
                    Case "CARRIERTYPE"
                        CarrierType = val
                    Case "EMPTYFLAG"
                        If val = "Y" Then
                            EmptyCarrier = 0
                        Else
                            EmptyCarrier = 1
                        End If


                    Case "PROCESSID"
                        PROCESSID = val
                End Select
            Catch ex As Exception

            End Try
        End Sub
    End Structure
    Function gettime() As String
        gettime = Now().ToString("yyyyMMddHHmmss00")
    End Function
    Function getinstalltime() As String
        getinstalltime = Now().ToString("yyyyMMddHHmmss")
    End Function
    Function CST_SearchByCSTID(ByVal CarrierID As String)
        CST_SearchByCSTID = -1
        For i As Integer = 0 To CST.Length - 1
            '  MsgBox(CST(i).CarrierID.Length.ToString + " " + CarrierID.Length.ToString)

            If CST(i).CarrierID = CarrierID And Not CST(i).CarrierLoc Is Nothing And Not CST(i).CarrierZoneName Is Nothing Then
                CST_SearchByCSTID = i
                Return i
            End If
        Next
    End Function
    Function CST_Add(ByVal CarrierID As String, ByVal CarrierZoneName As String, ByVal CarrierLoc As String, Optional ByVal CarrierState As UShort = 4, Optional ByVal installtime As String = "")
        Dim idx As Integer = -1
        CST_Add = -1
        For i As Integer = 0 To CST.Length - 1
            If CarrierID = CST(i).CarrierID Then
                idx = i
                Exit For
            End If
        Next
        If idx > -1 Then

            CST(idx).CarrierID = CarrierID
            CST(idx).CarrierZoneName = CarrierZoneName
            CST(idx).CarrierLoc = CarrierLoc
            CST(idx).CarrierState = CarrierState
            CST(idx).InstallTime = installtime
            EventReportSendOb(GEM.EVENT_CarrierInstallCompleted, CST(idx))
            For j As Integer = 0 To Zone.Length - 1
                If CST(idx).CarrierLoc = Zone(j).ZoneName Then
                    Zone(j).CST_count += 1
                End If
            Next
            For j As Integer = 0 To ShelfData.Length - 1
                If ShelfData(j).Zone_Name = CarrierZoneName And CarrierLoc = ShelfData(j).Shelf_Loc Then
                    ShelfData(j).CarrierID = CarrierID
                    Exit For
                End If
            Next
            CST_Add = idx
        Else
            For i As Integer = 0 To CST.Length - 1
                '  MsgBox(CST(i).CarrierID.Length.ToString + " " + CarrierID.Length.ToString)

                If CST(i).CarrierID = "" Then
                    If installtime = "" Then
                        installtime = getinstalltime()
                    End If
                    CST(i).CarrierID = CarrierID
                    CST(i).CarrierZoneName = CarrierZoneName
                    CST(i).CarrierLoc = CarrierLoc
                    CST(i).CarrierState = CarrierState
                    CST(i).InstallTime = installtime
                    EventReportSendOb(GEM.EVENT_CarrierInstallCompleted, CST(i))
                    For j As Integer = 0 To Zone.Length - 1
                        If CST(i).CarrierLoc = Zone(j).ZoneName Then
                            Zone(j).CST_count += 1
                        End If
                    Next
                    For j As Integer = 0 To ShelfData.Length - 1
                        If ShelfData(j).Zone_Name = CarrierZoneName And CarrierLoc = ShelfData(j).Shelf_Loc Then
                            ShelfData(j).CarrierID = CarrierID
                            Exit For
                        End If
                    Next
                    CST_Add = i
                    Exit For
                End If
            Next
        End If

    End Function
    Sub CST_Change(ByVal CarrierID As String, ByVal CarrierZoneName As String, ByVal CarrierLoc As String, ByVal CarrierState As String, Optional ByVal EVENT_ID As Integer = GEM.EVENT_CarrierInstallCompleted)
        For i As Integer = 0 To CST.Length - 1
            If CST(i).CarrierID = CarrierID Then
                CST(i).CarrierZoneName = CarrierZoneName
                CST(i).CarrierLoc = CarrierLoc
                CST(i).CarrierState = CInt(CarrierState)
                EventReportSendOb(EVENT_ID, CST(i))

                For j As Integer = 0 To ShelfData.Length - 1

                    If ShelfData(j).Zone_Name = CarrierZoneName And CarrierLoc = ShelfData(j).Shelf_Loc Then
                        ShelfData(j).CarrierID = CarrierID
                        If CarrierState = GEM.CS_BLOCKED Then
                            ShelfData(j).Shelf_Status = "X"
                        End If
                    ElseIf ShelfData(j).CarrierID = CarrierID And Not ShelfData(j).Zone_Name = CarrierZoneName And Not CarrierLoc = ShelfData(j).Shelf_Loc Then
                        ShelfData(j).CarrierID = ""
                    End If

                Next
                Exit For
            End If
        Next
    End Sub

    Sub CST_REMOVE(ByVal CarrierID As String)
        For i As Integer = 0 To CST.Length - 1
            If CST(i).CarrierID = CarrierID Then

                CST(i).CarrierZoneName = ""
                CST(i).CarrierLoc = ""
                CST(i).CarrierState = 0
                EventReportSendOb(GEM.EVENT_CarrierRemoveCompleted, CST(i))
                For j As Integer = 0 To ShelfData.Length - 1
                    If ShelfData(j).CarrierID = CarrierID Then
                        ShelfData(j).CarrierID = ""
                    End If
                Next
                CST(i).CarrierID = ""
                Exit For
            End If
        Next
    End Sub


    Function CST_SearchByLoc(ByVal Loc As String)
        CST_SearchByLoc = -1
        For i As Integer = 0 To CST.Length - 1
            If CST(i).CarrierLoc = Loc And Not CST(i).CarrierID = "" Then
                CST_SearchByLoc = i
                Exit For
            End If
        Next
    End Function
    Function Initialize(ByVal InitPath As String) As Integer
        Initialize = 0
        Dim readfile As StreamReader = New StreamReader(InitPath + "\EqpInitData\DefineReport.txt")
        ReDim reportlist(1000)
        ReDim SVList(200)
        While (Not readfile.EndOfStream)
            Dim str As String = readfile.ReadLine
            If str.StartsWith("RPID:") Then
                Dim list() As String = str.Substring(5).Split(",")
                Dim reportid As UInt32 = CUInt(list(0))
                Dim vid As UInt32
                reportlist(reportid).flag = True
                reportlist(reportid).reportid = reportid
                Array.Resize(reportlist(reportid).vid, CInt(list(1)))
                For j As Integer = 0 To CInt(list(1)) - 1
                    vid = CUInt(readfile.ReadLine)
                    reportlist(reportid).vid(j) = vid
                    reportlist(reportid).CEID = CUInt(list(2))
                    reportlist(reportid).EventName = list(3)
                Next
            End If
        End While
        readfile.Close()
        Dim i As Integer = 0
        'DVSV
        readfile = New StreamReader(InitPath + "\EqpInitData\EqpSV.csv")
        While (Not readfile.EndOfStream)
            Dim str As String = readfile.ReadLine
            If Not str.StartsWith("//") Then
                Dim list() As String = str.Split(",")
                SVList(i).vid = CInt(list(1))
                If list(2) = "ASCII" Then
                    SVList(i).format = SECSComm.ASCII_TYPE
                    SVList(i).val = ""
                ElseIf list(2) = "UINT_2" Then
                    SVList(i).format = SECSComm.UINT_2_TYPE
                    SVList(i).val = 0
                ElseIf list(2) = "UINT_4" Then
                    SVList(i).format = SECSComm.UINT_4_TYPE
                    SVList(i).val = 0
                ElseIf list(2) = "LIST" Then
                    SVList(i).format = SECSComm.LIST_TYPE
                    SVList(i).val = ""
                    If Not list(4) = "" Then
                        SVList(i).val = list(4).Split(";")
                    End If

                End If
                SVList(i).VarName = list(0)
                SVList(i).VarClass = list(3)
                i += 1
            End If
        End While
        readfile.Close()
        Array.Resize(SVList, i)
        i = 0
        ReDim EqConstantList(100)
        readfile = New StreamReader(InitPath + "\EqpInitData\EqpEC.csv")
        While (Not readfile.EndOfStream)
            Dim str As String = readfile.ReadLine
            If Not str.StartsWith("//") Then
                Dim list() As String = str.Split(",")
                EqConstantList(i).ECNAME = list(0)
                EqConstantList(i).ECID = CInt(list(1))
                If list(2) = "ASCII" Then
                    EqConstantList(i).format = SECSComm.ASCII_TYPE
                    EqConstantList(i).ECV = list(5)
                    EqConstantList(i).ECMIN = list(3)
                    EqConstantList(i).ECMAN = list(4)
                ElseIf list(2) = "UINT_2" Then
                    EqConstantList(i).format = SECSComm.UINT_4_TYPE
                    EqConstantList(i).ECV = CInt(list(5))
                    EqConstantList(i).ECMIN = CInt(list(3))
                    EqConstantList(i).ECMAN = CInt(list(4))
                End If

                EqConstantList(i).UNITS = list(6)
                EqConstantList(i).ECDEF = list(7)
                i += 1
            End If
        End While
        Array.Resize(EqConstantList, i)
        readfile.Close()

        UpdateSV(10, "E88-030")
        For i = 0 To CST.Length - 1
            CST(i).CarrierID = ""
            CST(i).CarrierLoc = ""
            CST(i).CarrierZoneName = ""
            CST(i).InstallTime = ""
            CST(i).CarrierState = 0
            CST(i).CarrierType = ""
            CST(i).CommandID = ""
            CST(i).DEST = ""
            CST(i).EmptyCarrier = 0
            CST(i).NEXTDest = ""
            CST(i).PROCESSID = ""
            CST(i).StockerCraneID = ""
            CST(i).SOURCE = ""

        Next


        GetEC(62, SECSComm.ASCII_TYPE, Eqpname)

        UpdateSV(GEM_SC_STATE, GEM.SC_PAUSED)
        UpdateSV(GEM_CONTROL_STATE, GEM.OnlineLoaclval)


    End Function

    Function AlarmReportSend(ByVal AlarmID As Integer, ByVal AlarmCD As Integer) As Integer

    End Function
    Function Close() As Integer

    End Function
    Function Command(ByVal CmdID As Integer, ByRef Param1 As Object, ByRef Param2 As Object) As Integer

    End Function
    Function DisableComm() As Integer

    End Function
    Function EnableComm() As Integer

    End Function
    Function EventReportSendOb(ByVal EventID As Integer, ByRef obj As Object) As Integer
        Dim OutputRawData(1000) As Byte
        Dim S As Integer = 6
        Dim F As Integer = 11
        Dim temp(0) As UInteger
        Dim datatype As Integer
        Dim val As Object = New Object
        Dim B1(0) As Byte
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        Dim DataItemOutLen As Integer = 0
        Dim typename As String = obj.GetType.Name




        For i As Integer = 0 To reportlist.Length - 1
            If reportlist(i).CEID = EventID And reportlist(i).flag Then
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, 0, DataItemOutLen) 'DataID
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, reportlist(i).CEID, DataItemOutLen) 'CEID EVENTID
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)

                'If reportlist(i).CEID = 3280 Then
                'temp(0) = 35
                'comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp) 'Report ID 
                'ElseIf reportlist(i).CEID = 160 Then
                '  temp(0) = 40
                ' comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp) 'Report ID 

                'Else
                temp(0) = reportlist(i).reportid
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp, DataItemOutLen) 'Report ID 
                'End If


                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, reportlist(i).vid.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen) '列出項目 
                'CST 相關事件




                If typename = "Carrier" Then
                    Dim CarrierData As Carrier = obj

                    For j As Integer = 0 To reportlist(i).vid.Length - 1
                        Dim val2(0) As Object
                        GetSV(reportlist(i).vid(j), datatype, val) '如果是LIST 的話就 接手處理 
                        '字串 LIST other 
                        If datatype = SECS.SECSComm.ASCII_TYPE Then '字串另外處理
                            Dim str As String = CarrierData.GetValByVid(reportlist(i).vid(j))
                            If str Is Nothing Then
                                str = ""
                            End If
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, str, DataItemOutLen)
                        ElseIf datatype = SECS.SECSComm.LIST_TYPE Then
                            Dim vididx() As String = val
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, vididx.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen) 'Lb

                            For k As Integer = 0 To vididx.Length - 1
                                GetSV(CInt(vididx(k)), datatype, val) '
                                If datatype = SECS.SECSComm.ASCII_TYPE Then
                                    Dim str As String = CarrierData.GetValByVid(CInt(vididx(k)))
                                    If str Is Nothing Then
                                        str = ""
                                    End If
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, str, DataItemOutLen)
                                Else
                                    val2(0) = CarrierData.GetValByVid(CInt(vididx(k)))
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, val2, DataItemOutLen)
                                End If
                            Next

                        Else
                            val2(0) = CarrierData.GetValByVid(reportlist(i).vid(j))
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, val2, DataItemOutLen)
                        End If

                    Next


                ElseIf typename = "String" Then
                    Dim str_list() As String = CStr(obj).Split(",")
                    Dim idx As Integer = 0
                    For j As Integer = 0 To reportlist(i).vid.Length - 1
                        '字串 LIST other 
                        GetSV(reportlist(i).vid(j), datatype, val) '如果是LIST 的話就 接手處理 
                        If datatype = SECS.SECSComm.LIST_TYPE Then
                            Dim vididx() As String = val
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, vididx.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen) 'Lb
                            For k As Integer = 0 To vididx.Length - 1
                                GetSV(CInt(vididx(k)), datatype, val) '
                                If datatype = SECS.SECSComm.ASCII_TYPE Then
                                    Dim str As String = str_list(idx)
                                    idx += 1
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, str, DataItemOutLen)
                                ElseIf datatype = SECS.SECSComm.UINT_2_TYPE Then
                                    U2(0) = CShort(str_list(idx))

                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, U2, DataItemOutLen)
                                    idx += 1
                                End If
                            Next
                        ElseIf datatype = SECS.SECSComm.ASCII_TYPE Then
                            Dim str As String = str_list(idx)
                            idx += 1
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, str, DataItemOutLen)
                        ElseIf datatype = SECS.SECSComm.UINT_2_TYPE Then

                            U2(0) = CShort(str_list(idx))
                            idx += 1
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, U2, DataItemOutLen)
                        End If

                    Next
                End If



                RaiseEvent QGEvent(1, S, F, 1, 0, OutputRawData, DataItemOutLen)
                Return 0
            End If
        Next

        Return 1
    End Function
    Function EventReportSend(ByVal EventID As Integer) As Integer
        Dim OutputRawData(1000) As Byte
        Dim S As Integer = 6
        Dim F As Integer = 11
        Dim temp(0) As UInteger
        Dim datatype As Integer
        Dim val As Object = New Object
        Dim flag As Boolean = False
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        Dim B1(0) As Byte
        Dim DataItemOutLen As Integer = 0

        For i As Integer = 0 To reportlist.Length - 1

            If reportlist(i).CEID = EventID Then
                flag = True
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                temp(0) = 0 'DATAID =0 (FIX)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp, DataItemOutLen) 'DataID
                temp(0) = reportlist(i).CEID
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp, DataItemOutLen) 'CEID EVENTID
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                temp(0) = reportlist(i).reportid
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp, DataItemOutLen) 'Report ID 
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, reportlist(i).vid.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                For j As Integer = 0 To reportlist(i).vid.Length - 1
                    GetSV(reportlist(i).vid(j), datatype, val) '如果是LIST 的話就 接手處理 
                    If datatype = SECS.SECSComm.ASCII_TYPE Then '字串另外處理
                        Dim str As String = val
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, val, DataItemOutLen)
                    ElseIf datatype = SECS.SECSComm.LIST_TYPE Then
                        Dim vididx() As String = val
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, vididx.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen) 'Lb
                        For k As Integer = 0 To vididx.Length - 1
                            Dim val2(0) As Object
                            GetSV(CInt(vididx(k)), datatype, val2(0)) '如果是LIST 的話就 接手處理 
                            If datatype = SECS.SECSComm.ASCII_TYPE Then
                                Dim str As String = val2(0)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, str.Length, datatype, str, DataItemOutLen)
                            Else
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, val2, DataItemOutLen)
                            End If
                        Next
                    Else
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, datatype, val, DataItemOutLen)
                    End If
                Next
                RaiseEvent QGEvent(1, S, F, 1, 0, OutputRawData, DataItemOutLen)
                Return 0
            End If
        Next
        If flag = False Then
            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECS.SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
            U2(0) = 0
            U4(0) = EventID

            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECS.SECSComm.UINT_2_TYPE, U2, DataItemOutLen)
            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECS.SECSComm.UINT_4_TYPE, U4, DataItemOutLen)
            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 0, SECS.SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
            RaiseEvent QGEvent(1, S, F, 1, 0, OutputRawData, DataItemOutLen)
        End If
        Return 1
    End Function
    Function GetCurrentCommState() As Integer

    End Function
    Function GetEC(ByVal ECID As Integer, ByRef Format As Integer, ByRef Value As Object) As Integer
        For i As Integer = 0 To EqConstantList.Length - 1
            If EqConstantList(i).ECID = ECID Then
                Value = EqConstantList(i).ECV
                Return 0
            End If
        Next
        Return 1
    End Function
    Function SetEC(ByVal ECID As Integer, ByVal Value As Object) As Integer
        For i As Integer = 0 To EqConstantList.Length - 1
            If EqConstantList(i).ECID = ECID Then
                EqConstantList(i).ECV = Value
                Return 0
            End If
        Next
        Return 1
    End Function
    Function GetInternalStatus(ByRef sText As String) As Integer

    End Function
    Function GetSV(ByVal SVID As Integer, ByRef Format As Integer, ByRef Value As Object) As Integer
        For i As Integer = 0 To SVList.Length - 1
            If SVList(i).vid = SVID Then
                Value = SVList(i).val
                Format = SVList(i).format
                Return 0
            End If
        Next
        Return 1
    End Function
    Function OnLineRequest() As Integer
        Dim a As UInteger = 0
        UpdateSV(GEM_CONTROL_STATE, OnlineLoaclval)

        'comQSWrapper.SendSECSIIMessage(1, 17, 1, a, Nothing)
        RaiseEvent QGEvent(1, 1, 17, 1, 0, Nothing, 0)
    End Function
    Function OffLine() As Integer
        Dim a As UInteger = 0
        ' comQSWrapper.SendSECSIIMessage(1, 15, 1, a, Nothing)
        UpdateSV(GEM_CONTROL_STATE, OfflineEQval)
        'ko
        RaiseEvent QGEvent(1, 1, 17, 1, 0, Nothing, 0)

    End Function
    Function OnLineLocal() As Integer

        UpdateSV(GEM_CONTROL_STATE, OnlineLoaclval)
        '觸發事件   
        Dim OutputRawData(1000) As Byte
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        U2(0) = 0
        U4(0) = 2
        UpdateSV(GEM_CONTROL_STATE, OnlineRemoteval)
        '觸發事件
        Dim DataItemOutLen As Integer = 0
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, U2, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, U4, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 0, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        RaiseEvent QGEvent(1, 6, 11, 1, 0, OutputRawData, DataItemOutLen)
    End Function
    Function OnLineRemote() As Integer
        Dim OutputRawData(1000) As Byte
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        Dim DataItemOutLen As Integer = 0
        U2(0) = 0
        U4(0) = 3
        UpdateSV(GEM_CONTROL_STATE, OnlineRemoteval)
        '觸發事件

        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, U2, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, U4, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 0, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        RaiseEvent QGEvent(1, 6, 11, 1, 0, OutputRawData, DataItemOutLen)
    End Function
    Function ToAuto() As Integer
        UpdateSV(GEM_SC_STATE, SC_AUTO)
        Dim OutputRawData(1000) As Byte
        Dim DataItemOutLen As Integer = 0
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        U2(0) = 0
        U4(0) = 53

        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, U2, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, U4, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 0, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        RaiseEvent QGEvent(1, 6, 11, 1, 0, OutputRawData, DataItemOutLen)
    End Function
    Function ToPAUSED() As Integer
        UpdateSV(GEM_SC_STATE, SC_PAUSING)
        Dim OutputRawData(1000) As Byte
        Dim DataItemOutLen As Integer = 0
        Dim U2(0) As UInt16
        Dim U4(0) As UInt32
        U2(0) = 0
        U4(0) = 57

        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, U2, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, U4, DataItemOutLen)
        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 0, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
        RaiseEvent QGEvent(1, 6, 11, 1, 0, OutputRawData, DataItemOutLen)
    End Function
    Function ProcessMessage(ByVal lMsgID As Integer, ByVal S As Integer, ByVal F As Integer, ByVal W_Bit As Integer, ByVal ulSystemBytes As UInteger, ByRef RawData As Object, ByRef Head As Object, ByVal EventText As String) As Integer
        Dim OutputRawData(10000) As Byte
        Dim lOffset As Integer = 0
        Dim lItemNum As Integer = 0
        Dim ItemData As Object = New Object
        Dim Ans(0) As Byte

        Dim B1(0) As Byte
        Dim val As Object = New Object
        Dim TypeCode As Integer
        Dim DataItemOutLen As Integer = 0
        Ans(0) = 0

        If lMsgID = 1 Then
            ' settext(pEventText & vbNewLine)
            Dim a() As Byte

            a = CType(RawData, Byte())

            ' settext(vbNewLine)
            For i As Integer = 10 To a.Length - 1
                ' settext(Hex(a(i)).PadLeft(2, "0") & " ")

            Next
            ' settext("S" + S.ToString + "F" + F.ToString + " DataLen:")
            ' ShowSECSIIMessage(RawData)

            If S = 1 And F = 1 And W_Bit = 1 Then
                Dim SoftName As String = ""
                Dim datetype As Integer = 0
                Dim ver As String = ""

                GetEC(62, datetype, SoftName)
                GetEC(1040, datetype, ver)

                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, SoftName.Length, SECSComm.ASCII_TYPE, SoftName, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, ver.Length, SECSComm.ASCII_TYPE, ver, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 1 And F = 3 And W_Bit = 1 Then
                lOffset = 0
                'ItemData
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                Dim len As Integer = lItemNum
                Dim outlen As Integer = 0

                Dim Svid(len - 1) As UInteger

                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, lItemNum, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                For i As Integer = 0 To len - 1

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, lItemNum, ItemData)
                    ' settext(ItemData(0).ToString)

                    GetSV(ItemData(0), TypeCode, val)
                    If ItemData(0) = 390 Then
                        '拋出CST資料
                        Dim cst_len As Integer = 0

                        For j As Integer = 0 To CST.Length - 1
                            If Not CST(j).CarrierID = "" And CST(j).CarrierZoneName.StartsWith(Eqpname) Then
                                cst_len += 1

                            End If
                        Next
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, cst_len, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)

                        For j As Integer = 0 To CST.Length - 1
                            If Not CST(j).CarrierID = "" And CST(j).CarrierZoneName.StartsWith(Eqpname) Then

                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 5, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CarrierID.Length, SECSComm.ASCII_TYPE, CST(j).CarrierID, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CarrierLoc.Length, SECSComm.ASCII_TYPE, CST(j).CarrierLoc, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CarrierZoneName.Length, SECSComm.ASCII_TYPE, CST(j).CarrierZoneName, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).InstallTime.Length, SECSComm.ASCII_TYPE, CST(j).InstallTime, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, CST(j).CarrierState, DataItemOutLen)

                            End If
                        Next
                       
                    ElseIf ItemData(0) = 410 Then
                        '拋出傳送資料
                        Dim cast_len As Integer = 0
                        For j As Integer = 0 To CST.Length - 1
                            If Not CST(j).CommandID = "" Then
                                cast_len += 1

                            End If
                        Next

                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, cast_len, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                        If cast_len > 0 Then
                            For j As Integer = 0 To CST.Length - 1
                                If Not CST(j).CommandID = "" Then
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, CST(j).TransferState, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CommandID.Length, SECSComm.ASCII_TYPE, CST(j).CommandID, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, CST(j).PRIORITY, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CarrierID.Length, SECSComm.ASCII_TYPE, CST(j).CarrierID, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).CarrierLoc.Length, SECSComm.ASCII_TYPE, CST(j).CarrierLoc, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(j).DEST.Length, SECSComm.ASCII_TYPE, CST(j).DEST, DataItemOutLen)
                                End If
                            Next
                        End If
                    ElseIf ItemData(0) = 490 Then
                        '拋出ZONE的資料

                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, Zone.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen) '幾個ZONE
                        For j As Integer = 0 To Zone.Length - 1
                            Dim cast_len As Integer = 0
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 5, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, Zone(j).ZoneName.Length, SECSComm.ASCII_TYPE, Zone(j).ZoneName, DataItemOutLen)


                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, Zone(j).ZoneCapacity, DataItemOutLen)

                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, Zone(j).ZoneSize, DataItemOutLen)

                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, Zone(j).ZoneType, DataItemOutLen)
                            cast_len = 0
                            For k As Integer = 0 To CST.Length - 1
                                If CST(k).CarrierState = 6 And CST(k).CarrierZoneName = Zone(j).ZoneName Then
                                    cast_len += 1
                                End If
                            Next
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, cast_len, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                            For k As Integer = 0 To CST.Length - 1
                                If CST(k).CarrierState = 6 And CST(k).CarrierZoneName = Zone(j).ZoneName Then
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(k).CarrierLoc.Length, SECSComm.ASCII_TYPE, CST(k).CarrierLoc, DataItemOutLen)
                                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, CST(k).CarrierID.Length, SECSComm.ASCII_TYPE, CST(k).CarrierID, DataItemOutLen)

                                End If
                            Next
                        Next

                    ElseIf ItemData(0) = 202 Then
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, EqPort.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                        For j As Integer = 0 To EqPort.Length - 1
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, EqPort(j).PortID.Length, SECSComm.ASCII_TYPE, EqPort(j).PortID, DataItemOutLen)

                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, EqPort(j).PortTransferState, DataItemOutLen)
                        Next
                    ElseIf ItemData(0) = 206 Then
                        'Port input or output 
                        Dim len_cnt As Integer = 0
                        For j As Integer = 0 To EqPort.Length - 1
                            If EqPort(j).PortID.StartsWith("ID") Then
                                len_cnt += 1
                            End If

                        Next
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, len_cnt, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                        For j As Integer = 0 To EqPort.Length - 1
                            If EqPort(j).PortID.StartsWith("ID") Then
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, EqPort(j).PortID.Length, SECSComm.ASCII_TYPE, EqPort(j).PortID, DataItemOutLen)
                                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, 1, DataItemOutLen)
                            End If

                        Next
                    ElseIf ItemData(0) = 208 Then
                        'Port input or output 
                        'Dim len_cnt As Integer = 0
                        'For j As Integer = 0 To EqPort.Length - 1
                        '    If EqPort(j).PortID.StartsWith("C") Then
                        '        len_cnt += 1
                        '    End If

                        'Next
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, EqPort.Length, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                        For j As Integer = 0 To EqPort.Length - 1
                            ' If EqPort(j).PortID.StartsWith("C") Then
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, EqPort(j).PortID.Length, SECSComm.ASCII_TYPE, EqPort(j).PortID, DataItemOutLen)
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, EqPort(j).LoadAvail, DataItemOutLen)
                            DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_2_TYPE, EqPort(j).UnLoadAvail, DataItemOutLen)
                            ' End If

                        Next
                    Else
                        If TypeCode = SECSComm.ASCII_TYPE Then
                            outlen = val.ToString.Length

                        Else
                            outlen = 1
                        End If
                        DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, outlen, TypeCode, val, DataItemOutLen)
                    End If

                Next





                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 1 And F = 11 And W_Bit = 1 Then
                lOffset = 0
                'ItemData
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                Dim len As Integer = lItemNum
                Dim Svid(len - 1) As UInteger
                Dim SVNAME(len - 1) As String
                Dim UNITS(len - 1) As String
                For i As Integer = 0 To len - 1

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, lItemNum, ItemData)
                    'settext(ItemData(0).ToString)
                    Svid(i) = ItemData(0)
                Next


                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, len, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                For i As Integer = 0 To len - 1
                    Dim temp(0) As UInteger
                    temp(0) = Svid(i)
                    SVNAME(i) = "AGV" + i.ToString
                    UNITS(i) = "No."
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 3, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.UINT_4_TYPE, temp, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, SVNAME(i).Length, SECSComm.ASCII_TYPE, SVNAME(i), DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, UNITS(i).Length, SECSComm.ASCII_TYPE, UNITS(i), DataItemOutLen)
                Next
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 1 And F = 13 And W_Bit = 1 Then
                Dim SoftName As String = ""
                Dim Ver As String = ""
                GetEC(62, SECSComm.ASCII_TYPE, SoftName)
                GetEC(1040, SECSComm.ASCII_TYPE, Ver)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, 0, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, SoftName.Length, SECSComm.ASCII_TYPE, SoftName, DataItemOutLen)
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, Ver.Length, SECSComm.ASCII_TYPE, Ver, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 1 And F = 15 And W_Bit = 1 Then
                'MCS OFFLine Req
                Dim b As Byte = 0
                '0 Normal 1 pnline not permitted 2 alreadt online 
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, b, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 1 And F = 17 And W_Bit = 1 Then
                'MCS onLine Req
                Dim b(0) As Byte
                b(0) = 0
                '0 Normal 1 pnline not permitted 2 alreadt online 
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, b, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 2 And F = 13 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 2 And F = 15 And W_Bit = 1 Then
                Dim len As Integer
                Dim ECID(0) As UInt32
                Dim ECV As Object = New Object

                B1(0) = 0

                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                For i As Integer = 0 To lItemNum - 1
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, len, Nothing)
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, len, ECID) 'ECID
                    TypeCode = comQSWrapper.GetDataItemType(RawData, lOffset)
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, TypeCode, len, ECV) 'ECV
                    B1(0) += SetEC(ECID(0), ECV)
                Next

                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, B1, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 2 And F = 17 And W_Bit = 1 Then


                Dim temp As String = Now.ToString("yyyyMMddhhmmssff")

                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, temp.Length, SECSComm.ASCII_TYPE, temp, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)
            ElseIf S = 2 And F = 29 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 2 And F = 31 And W_Bit = 1 Then
                ' MCS time setting
                Dim temp As String = ""

                lOffset = 0
                'ItemData
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, temp)
                'settext("MCS 時間:" + temp)

                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, Ans, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 2 And F = 33 And W_Bit = 1 Then
                'define report
                ' L2 U2 La L2 U4 Lb
                lOffset = 0
                'ItemData
                Dim temp As Object = New Object
                Dim NoOfReport As Integer
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_2_TYPE, lItemNum, temp)
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, NoOfReport, Nothing)
                Array.Resize(McsReport, NoOfReport)
                '要先搜尋有沒有重複的

                For i As Integer = 0 To NoOfReport - 1
                    Dim NoOfVid As Integer
                    'L2 U4 Lb
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, lItemNum, temp)
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, NoOfVid, Nothing)
                    Array.Resize(McsReport(i).vid, NoOfVid)
                    For j As Integer = 0 To NoOfVid - 1
                        Dim b As Integer
                        lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, b, McsReport(i).vid)
                    Next
                Next


                lOffset = 0
                'ItemData
                Ans(0) = 0
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, Ans, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 2 And F = 35 And W_Bit = 1 Then
                'LinkReport()
                lOffset = 0
                'ItemData
                Dim temp As Object = New Object
                Dim NoOfReport As Integer
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_2_TYPE, lItemNum, temp) 'DATAID U2
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, NoOfReport, Nothing) 'La
                Array.Resize(LinkReport, NoOfReport)
                '要先搜尋有沒有重複的

                For i As Integer = 0 To NoOfReport - 1
                    Dim NoOfVid As Integer
                    'L2 U4 Lb
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, lItemNum, temp)  'CEID
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, NoOfVid, Nothing)  'Lb
                    Array.Resize(LinkReport(i).RPTID, NoOfVid)
                    LinkReport(i).CEID = temp(0)
                    For j As Integer = 0 To NoOfVid - 1
                        Dim b As Integer
                        lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, b, LinkReport(i).RPTID) 'U4 RPTID
                    Next
                Next



                lOffset = 0
                'ItemData
                Ans(0) = 0
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, Ans, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 2 And F = 37 And W_Bit = 1 Then
                'Message for for Even Enable/Disable
                Dim temp As Object = New Object
                Dim flag As Boolean = False
                Dim EvenNo As Integer = 0
                Dim len As Integer
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.BOOLEAN_TYPE, lItemNum, temp) 'DATAID U2

                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, EvenNo, Nothing) 'Ln
                If temp(0) = 1 Then
                    flag = True
                Else
                    flag = False
                End If


                For i As Integer = 0 To EvenNo - 1
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_4_TYPE, len, temp) 'Ln
                    For j As Integer = 0 To reportlist.Length - 1
                        If reportlist(j).CEID = temp(0) Then
                            reportlist(j).flag = flag
                        End If

                    Next
                Next

                Ans(0) = 0
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, Ans, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)

            ElseIf S = 2 And F = 41 And W_Bit = 1 Then
                'RCMD ABORT CANCEL PAUSE  RESUME REMOVE PRIORITYUPDATE處理命令 
                'INSTALL 上報CARRIERID  CARRIERTYPESET
                'PORTMODECHANGE
                'SCAN

                Dim ack As Byte = 4
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing)
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData)
                If ItemData = "CANCEL" Then
                    Dim CommandID As String = ""
                    Dim findcst As Boolean = False
                    ack = 2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '2

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CommandID) 'cmdid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CommandID = CommandID Then
                            EventReportSendOb(EVENT_TransferCanselInitiated, CST(i))
                            If CST(i).TransferState = TransferState_Queued Then
                                CST(i).CommandID = ""
                                EventReportSendOb(EVENT_TransferCancelCompleted, CST(i))
                                ack = 0
                            End If
                            findcst = True
                            Exit For
                        End If
                    Next
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 9, SECSComm.BINARY_TYPE, "COMMANDID", DataItemOutLen)
                    ack = 0
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "ABORT" Then
                    Dim CommandID As String = ""
                    Dim findcst As Boolean = False
                    ack = 2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '2

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CommandID) 'cmdid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CommandID = CommandID Then
                            EventReportSendOb(EVENT_TransferAbortInitiated, CST(i))
                            If CST(i).CarrierState = CS_STOREDALTERMATE Or CST(i).CarrierState = CS_STOREDCOMPLETED Or CST(i).CarrierState = CS_BLOCKED Then

                                CST(i).CommandID = ""
                                '刪除STKC的傳送命令

                                EventReportSendOb(EVENT_TransferAbortCompleted, CST(i))
                                ack = 0
                            Else

                                ack = 2
                            End If
                            findcst = True
                            Exit For
                        End If
                    Next

                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 9, SECSComm.BINARY_TYPE, "COMMANDID", DataItemOutLen)
                    ack = 0
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "PAUSE" Then
                    'ok
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)

                ElseIf ItemData = "RESUME" Then
                    'ok
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "INSTALL" Then
                    Dim Cmd As Object = New Object
                    Dim findcst As Boolean = False
                    Dim CSTID As String = ""
                    Dim loc As String = ""
                    Dim csttype As String = ""
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '3

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CSTID) 'carrierid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CarrierID = CSTID Then
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, Cmd) ' 
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, loc) ' 
                            CST(i).SetValByName(Cmd, loc)
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, Cmd) ' 
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, csttype) ' 
                            CST(i).SetValByName(Cmd, csttype)
                            findcst = True
                            Exit For
                        End If
                    Next
                    If findcst = False Then
                        For i As Integer = 0 To CST.Length - 1
                            If CST(i).CarrierID = "" Then
                                CST(i).CarrierID = CSTID
                                CST(i).CarrierLoc = loc
                                CST(i).CarrierType = csttype
                                CST(i).InstallTime = gettime()
                                Exit For
                            End If
                        Next
                    End If

                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "REMOVE" Then

                    Dim CSTID As String = ""
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '3

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CSTID) 'carrierid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CarrierID = CSTID Then
                            CST(i).del()
                        End If
                    Next
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "PORTTYPCHG" Then
                    MsgBox("S2F41 Cmd No Define" + ItemData)
                ElseIf ItemData = "SCAN" Then
                    Dim CARRIERID As String = ""
                    Dim CARRIERLOC As String = ""
                    Dim findcst As Boolean = False
                    ack = 0
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CARRIERID) 'CARRIERID 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CARRIERLOC) 'CARRIERLOC 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CarrierID = CARRIERID And CST(i).CarrierLoc = CARRIERLOC Then


                            findcst = True
                            Exit For
                        End If
                    Next
                    If findcst = False Then
                        ack = 87
                    End If
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 9, SECSComm.BINARY_TYPE, "CARRIERID", DataItemOutLen)
                    ack = 0
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 2, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 10, SECSComm.BINARY_TYPE, "CARRIERLOC", DataItemOutLen)
                    ack = 0
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "CARRIERTYPESET" Then
                    Dim Cmd As Object = New Object
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '3

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CarrierID = ItemData Then
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, Cmd) ' 
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) ' 
                            CST(i).SetValByName(Cmd, ItemData)
                            Exit For
                        End If
                    Next
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                ElseIf ItemData = "PRIORITYUPDATE" Then
                    Dim CmdID As Object = New Object
                    Dim PRIORITY As Object = New Object
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) '3

                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) 'carrierid 
                    lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, CmdID) 'carrierid 
                    For i As Integer = 0 To CST.Length - 1
                        If CST(i).CommandID = CmdID Then
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.ASCII_TYPE, lItemNum, ItemData) ' 
                            lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.UINT_2_TYPE, lItemNum, PRIORITY) ' 
                            CST(i).SetValByName(ItemData, PRIORITY)
                            Exit For
                        End If
                    Next
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                Else
                    MsgBox("S2F41 Cmd No Define!!!!!!!!!!!!!!!!!!!!!!!!!(" + ItemData + ")")

                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.LIST_TYPE, Nothing, DataItemOutLen)
                    DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, ack, DataItemOutLen)
                End If


                ' comQSWrapper.SendSECSIIMessage(S, F + 1, 0, ulSystemBytes, OutputRawData)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)


            ElseIf S = 2 And F = 49 And W_Bit = 1 Then


            ElseIf S = 5 And F = 1 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 5 And F = 2 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 5 And F = 3 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 5 And F = 5 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 6 And F = 11 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 6 And F = 15 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 6 And F = 19 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 1 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 3 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 5 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 7 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 9 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 9 And F = 11 And W_Bit = 1 Then
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            ElseIf S = 10 And F = 3 And W_Bit = 1 Then
                '顯示資訊給AGVC
                lOffset = 0
                Dim temp As Object = New Object

                'ItemData
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.LIST_TYPE, lItemNum, Nothing) 'L2
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.BINARY_TYPE, lItemNum, temp) 'L2
                lOffset = comQSWrapper.DataItemIn(RawData, lOffset, SECSComm.BINARY_TYPE, lItemNum, temp) 'L2
                MsgBox(temp)
                Ans(0) = 0
                DataItemOutLen = comQSWrapper.DataItemOut(OutputRawData, 1, SECSComm.BINARY_TYPE, Ans, DataItemOutLen)
                RaiseEvent QGEvent(1, S, F + 1, 0, ulSystemBytes, OutputRawData, DataItemOutLen)


            ElseIf S = 2 And F = 25 And W_Bit = 1 Then
                ' S2F26
                ' <B[10].
                MsgBox("S" + S.ToString + "F" + F.ToString + "No Define")
            End If
        ElseIf lMsgID = 2 Then
            ' settext(pEventText & vbNewLine)
            '  ShowSECSIIMessage(RawData)

        End If
    End Function
    Function SendTerminalMessage(ByVal Message As String) As Integer
        MsgBox("TerminalMessage:" + Message)
        SendTerminalMessage = 0
    End Function
    Function UpdateEC(ByVal ECID As Integer, ByRef Value As Object) As Integer
        For i As Integer = 0 To EqConstantList.Length - 1
            If EqConstantList(i).ECID = ECID Then
                EqConstantList(i).ECV = Value
                Return 0
            End If
        Next
        Return 1
    End Function
    Function UpdateSV(ByVal SVID As Integer, ByRef Value As Object) As Integer
        For i As Integer = 0 To SVList.Length - 1
            If SVList(i).vid = SVID Then
                SVList(i).val = Value
                Return 0
            End If
        Next
        Return 1
    End Function

End Class
