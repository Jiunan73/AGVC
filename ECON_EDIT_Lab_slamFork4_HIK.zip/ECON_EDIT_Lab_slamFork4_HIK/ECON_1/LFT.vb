﻿Imports System.Net.Sockets
Imports System.Threading
Module LFT
    Public Structure LFT_point
        Dim flag As Boolean
        Dim Connect_flag As Boolean
        Dim control_flag As Integer
        Dim EQ_ID As String

        Dim tagid As Integer
        Dim ipadress As String
        Dim port As Integer
        Dim tcp_client As TcpClient
        Dim TCPstream As NetworkStream
        Dim startDO As Integer
        Dim startDI As Integer
        Dim LFT_Pic As Label
        Dim To_LFT() As Integer
        Dim From_LFT_DI() As Integer
        Dim From_LFT_DO() As Integer
        Dim ReadOK As Boolean
        Dim open_sensor As Integer

        Dim From_FLOOR As Integer
        Dim TO_FLOOR As Integer
        Dim LFT_STEP_I As Integer
        Dim IR_sensor As Boolean

        Dim Pre_floor_no As Integer
        Dim Pre_open_sensor As Integer
        Dim retry As Integer
        Public Sub init(ByVal sflag As Boolean)
            flag = sflag
            EQ_ID = ""
            tagid = 0
            startDO = 0
            startDI = 0
            ipadress = "0.0.0.0"
            control_flag = -1
            port = 0
            ReDim To_LFT(15)
            ReDim From_LFT_DI(15)
            ReDim From_LFT_DO(15)
            ReadOK = False
            LFT_STEP_I = 0
            From_FLOOR = 0
            TO_FLOOR = 0
            open_sensor = 0
            retry = 0
        End Sub
        Function connect() As Boolean
            connect = False
            Connect_flag = False
            Try
                If (My.Computer.Network.Ping(ipadress)) Then
                   
                    tcp_client = New TcpClient

                    tcp_client.Connect(ipadress, port)
                    If tcp_client.Connected Then
                        TCPstream = tcp_client.GetStream
                        'TCPstream.WriteByte(80)
                        TCPstream.ReadTimeout = 1000
                        Connect_flag = True
                        connect = True
                        retry = 0
                    Else
                        MsgBox(" LFT　Ping  Error")
                    End If


                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End Function
        Function reconnect() As Boolean
            reconnect = False
            Connect_flag = False
            Try
                If (My.Computer.Network.Ping(ipadress)) Then

                    tcp_client.Close()

                    tcp_client = New TcpClient
                    tcp_client.Connect(ipadress, port)
                    If tcp_client.Connected Then
                        TCPstream = tcp_client.GetStream
                        'TCPstream.WriteByte(80)
                        TCPstream.ReadTimeout = 1000
                        Connect_flag = True
                        reconnect = True
                    Else
                        MsgBox(" LFT　Ping  Error")
                    End If


                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End Function
        Function read_DIO() As String
            Dim Wbyte(20) As Byte
            Dim Rbyte(100) As Byte
            read_DIO = ""
            Wbyte(0) = 0
            Wbyte(1) = 0
            Wbyte(2) = 0
            Wbyte(3) = 0
            Wbyte(4) = 0
            Wbyte(5) = 6
            Wbyte(6) = 1
            Wbyte(7) = 3
            Wbyte(8) = 0
            Wbyte(9) = 10
            Wbyte(10) = 0
            Wbyte(11) = 2
            TCPstream.Write(Wbyte, 0, 12)
            Thread.Sleep(300)
            '  Do
            Try
                If TCPstream.Read(Rbyte, 0, 100) = 13 Then
                    'Loop While Net_stream.DataAvailable
                    Dim n As Integer = Rbyte(9) * 256 + Rbyte(10)
                    For i As Integer = 0 To From_LFT_DI.Length - 1
                        From_LFT_DI(i) = (n Mod 2 ^ (i + 1)) \ 2 ^ (i)
                        n = n - (n Mod 2 ^ (i + 1))
                    Next
                    n = Rbyte(11) * 256 + Rbyte(12)
                    For i As Integer = 0 To From_LFT_DO.Length - 1
                        From_LFT_DO(i) = (n Mod 2 ^ (i + 1)) \ 2 ^ (i)
                        n = n - (n Mod 2 ^ (i + 1))
                    Next
                    ReadOK = True
                    retry = 0
                Else
                    ReadOK = False
                End If
            Catch ex As Exception
                read_DIO = ex.Message
                retry += 1
            End Try


        End Function
        Function write_do() As String
            write_do = ""
            Dim Wbyte(20) As Byte
            Dim Rbyte(100) As Byte
            Dim Write_D = 0
            For i As Integer = 0 To To_LFT.Length - 1
                Write_D += To_LFT(i) * 2 ^ i
            Next
            Wbyte(0) = 0
            Wbyte(1) = 0
            Wbyte(2) = 0
            Wbyte(3) = 0
            Wbyte(4) = 0
            Wbyte(5) = 9
            Wbyte(6) = 0
            Wbyte(7) = 16
            Wbyte(8) = 0
            Wbyte(9) = 11
            Wbyte(10) = 0
            Wbyte(11) = 1
            Wbyte(12) = 2
            Wbyte(13) = Write_D \ 256
            Wbyte(14) = Write_D Mod 256
            Try
                TCPstream.Write(Wbyte, 0, 15)
                Thread.Sleep(100)
                TCPstream.Read(Rbyte, 0, 100)
            Catch ex As Exception
                write_do = ex.Message + vbCrLf
                retry += 1
            End Try


        End Function
        Sub release()
            For i As Integer = 0 To 15
                To_LFT(i) = 0

            Next
            LFT_STEP_I = 0
            control_flag = -1
            write_do()

        End Sub
        Function LFT_Main(ByVal carfloor As Integer, ByVal To_Floor As Integer, ByVal car_tagid As Integer) As String
            Dim r_str As String = ""
            '專用,水平,
            LFT_Main = ""
            'LFT_Main = "LFT_STEP_I=" + LFT_STEP_I.ToString
            If car_tagid > 10000 Then
                car_tagid = car_tagid - 10000
            End If
            r_str = read_DIO()
            If Not r_str = "" Then
                LFT_Main += r_str + vbCrLf
            End If

            Thread.Sleep(100)
            If LFT_STEP_I > 0 Then
                LFT_Main += "LFT_STEP_I:" + LFT_STEP_I.ToString + vbCrLf
                LFT_Main += "carfloor:" + carfloor.ToString + ",To_Floor:" + To_Floor.ToString + ",car_tagid:" + car_tagid.ToString + vbCrLf
            End If

            Dim floor As Integer = From_LFT_DI(12) + From_LFT_DI(13) * 2 + From_LFT_DI(14) * 4 + From_LFT_DI(15) * 8
            If From_LFT_DI(4) = 1 And IR_sensor = True Then
                To_LFT(11) = 1
                To_LFT(12) = 0
            ElseIf carfloor <= 8 Or car_tagid = tagid Then
                Select Case LFT_STEP_I

                    Case 0

                        If (To_Floor > 0 And Not carfloor = To_Floor And From_LFT_DI(8) = 1 And From_LFT_DI(10) = 1) Then
                            LFT_STEP_I += 1
                            '  LFT_Main += "判斷電梯與車子是否相同樓層" + vbCrLf
                        Else
                            ' LFT_Main += "目的與車子相同樓層" + vbCrLf
                        End If
                    Case 1
                        '車廂不同樓層
                        To_LFT(0) = 1 '專用
                        If From_LFT_DI(0) = 1 Then
                            If car_tagid = tagid Then
                                To_LFT(0) = 1 '電梯專用
                                LFT_STEP_I = 6
                                LFT_Main += "車子已在電梯內"
                            ElseIf floor = carfloor Then
                                '車子與電梯 相同樓層
                                For i As Integer = 1 To 8
                                    To_LFT(i) = 0
                                Next
                                If carfloor > 0 Then
                                    To_LFT(carfloor) = 1 '樓層
                                End If

                                LFT_Main += "電梯相同樓層" + vbCrLf + "電梯開門"
                                To_LFT(11) = 1 '開門ON
                                To_LFT(12) = 0 '關門OFF
                                LFT_STEP_I = 5
                            Else
                                LFT_Main += "電梯不同樓層" + vbCrLf + "電梯關門移動"
                                To_LFT(11) = 0 '開門OFF
                                To_LFT(12) = 1 '關門ON     
                                For i As Integer = 1 To 8
                                    To_LFT(i) = 0
                                Next
                                If carfloor > 0 Then
                                    To_LFT(carfloor) = 1 '樓層
                                End If
                                LFT_STEP_I = 2

                            End If
                        End If


                    Case 2
                        To_LFT(0) = 1 '專用
                        If From_LFT_DI(8) = 1 And From_LFT_DI(10) = 1 Then
                            LFT_Main += "電梯移動中" + vbCrLf + "關門訊號OFF，等待電梯到達該樓層"
                            To_LFT(11) = 0 '開門 OFF 
                            To_LFT(12) = 0 '關門 OFF 
                            For i As Integer = 1 To 8
                                To_LFT(i) = 0
                            Next
                            If carfloor > 0 Then
                                To_LFT(carfloor) = 1 '樓層
                            End If
                            LFT_STEP_I += 1
                        Else
                            To_LFT(11) = 0 '開門OFF
                            To_LFT(12) = 1 '關門 OFF 

                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 3
                        To_LFT(0) = 1 '專用
                        If floor = carfloor Then
                            '電梯作動中
                            LFT_Main += "電梯移動到出發樓層" + vbCrLf + "開門"

                            To_LFT(11) = 1 '開門 ON
                            To_LFT(12) = 0 '關門 OFF
                            For i As Integer = 1 To 8
                                To_LFT(i) = 0
                            Next

                            If carfloor > 0 Then
                                To_LFT(carfloor) = 0 '樓層叫車關閉
                            End If

                            LFT_STEP_I = 5
                        ElseIf car_tagid = tagid Then
                            LFT_STEP_I = 6
                        Else
                            To_LFT(11) = 0 '開門 OFF
                            To_LFT(12) = 1 '關門 ON
                            LFT_STEP_I = 2
                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 5
                        '電梯到達該樓層開門
                        To_LFT(0) = 1 '電梯專用
                        To_LFT(11) = 1 '開門
                        To_LFT(12) = 0 '關門 OFF
                        If floor = carfloor Then
                            If From_LFT_DI(2) = 1 And From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 Then
                                LFT_Main += "電梯到達車子樓層" + vbCrLf + "判斷CAR進入否"
                                open_sensor = floor
                                LFT_STEP_I += 1
                            End If
                        Else
                            To_LFT(11) = 0 '開門
                            To_LFT(12) = 1 '關門 OFF
                            LFT_STEP_I = 2
                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 6
                        To_LFT(0) = 1 '專用
                        If car_tagid = tagid Then
                            '判斷CAR車子到達電梯中心
                            LFT_Main += "車子抵達電梯" + vbCrLf + "關門電梯前往目的樓層"


                            To_LFT(0) = 1 '電梯專用                  
                            For i As Integer = 1 To 8
                                To_LFT(i) = 0
                            Next

                            If carfloor > 0 Then
                                To_LFT(carfloor) = 0 '樓層叫車關閉
                            Else
                                LFT_Main += LFT_STEP_I.ToString + ":carfloor=" + To_Floor.ToString
                            End If
                            If To_Floor > 0 Then
                                To_LFT(To_Floor) = 1 '叫車  
                            Else
                                LFT_Main += LFT_STEP_I.ToString + ":To_Floor=" + To_Floor.ToString

                            End If

                            LFT_Main += "To_Floor:" + To_Floor.ToString + vbCrLf
                            To_LFT(11) = 0 '開門 OFF
                            To_LFT(12) = 1 '關門 
                            LFT_STEP_I += 1
                            open_sensor = 0
                        ElseIf Not carfloor = floor Then
                            To_LFT(11) = 0 '開門 OFF
                            To_LFT(12) = 1 '關門 
                            LFT_STEP_I = 1
                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 7

                        If From_LFT_DI(8) = 1 And From_LFT_DI(10) = 1 Then
                            '關門訊號
                            LFT_Main += "關門訊號觸發" + vbCrLf + "電梯前往目的樓層"
                            To_LFT(11) = 0 '開門 OFF
                            To_LFT(12) = 0 '關門 OFF 
                            LFT_STEP_I += 1
                        End If
                        If From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 Then
                            LFT_STEP_I = 6
                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 8
                        To_LFT(0) = 1 '電梯專用
                        To_LFT(12) = 0 '關門 OFF
                        If floor = To_Floor Then
                            '電梯作動中
                            LFT_Main += "電梯移動中" + vbCrLf + "關門訊號OFF，等待電梯到達該樓層"
                            To_LFT(12) = 0 '關門 OFF
                            To_LFT(11) = 1 '開門 OFF
                            To_LFT(To_Floor) = 0 '叫車關閉
                            LFT_STEP_I += 1
                        ElseIf From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 And Not floor = To_Floor Then '開門 
                            LFT_STEP_I = 6


                        End If
                        To_LFT(0) = 1 '電梯專用
                    Case 9
                        To_LFT(0) = 1 '專用
                        To_LFT(11) = 1 '開門
                        If From_LFT_DI(0) = 1 And From_LFT_DI(2) = 1 And From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 And floor = To_Floor Then
                            LFT_Main += "電梯到達" + vbCrLf + "等待車子離開電梯" + vbCrLf
                            open_sensor = floor
                            LFT_STEP_I += 1
                        ElseIf From_LFT_DI(0) = 1 And From_LFT_DI(2) = 1 And From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 Then
                            LFT_STEP_I = 6
                        End If
                        To_LFT(0) = 1 '電梯專用
                        'If Not (From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 And floor = To_Floor) Then
                        '    '
                        '    LFT_STEP_I = 6
                        'End If
                    Case 10
                        '判斷車子離開電梯
                        If From_LFT_DI(0) = 1 And From_LFT_DI(2) = 1 And From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 And floor = To_Floor Then
                            LFT_Main += "電梯到達" + vbCrLf + "等待車子離開電梯" + vbCrLf
                            open_sensor = floor
                        End If


                        If Not car_tagid = tagid Then
                            '釋放電梯 
                            LFT_Main += "車子離開電梯" + vbCrLf + "釋放電梯控制權"
                            For i As Integer = 1 To 12
                                To_LFT(i) = 0
                            Next
                            release()
                            LFT_STEP_I += 1
                        End If

                    Case Else

                        LFT_STEP_I = 0
                End Select

                'If From_LFT_DI(4) = 1 And IR_sensor = True Then
                '    To_LFT(11) = 1 '開門 ON
                '    To_LFT(12) = 0 '關門 OFF
                'End If



            End If
            r_str = write_do()
            If Not r_str = "" Then
                LFT_Main += r_str + vbCrLf
            End If
            If ReadOK = True And From_LFT_DI(0) = 1 And From_LFT_DI(0) = 1 And From_LFT_DI(7) = 1 And From_LFT_DI(9) = 1 Then
                'open_sensor = floor
            Else
                open_sensor = 0
            End If
        End Function


    End Structure
End Module
