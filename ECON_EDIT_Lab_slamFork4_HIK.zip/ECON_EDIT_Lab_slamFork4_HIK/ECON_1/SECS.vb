﻿Imports System.Net.Sockets
Imports System.Net
Imports System.Threading
Module SECS
    Public Class SECSComm
        Public Const LIST_TYPE As Integer = &O0
        Public Const BINARY_TYPE As Integer = &O10
        Public Const BOOLEAN_TYPE As Integer = &O11
        Public Const ASCII_TYPE As Integer = &O20
        Public Const JIS_TYPE As Integer = &O21
        Public Const CHAR_2_TYPE As Integer = &O22
        Public Const INT_8_TYPE As Integer = &O30
        Public Const INT_1_TYPE As Integer = &O31
        Public Const INT_2_TYPE As Integer = &O32
        Public Const INT_4_TYPE As Integer = &O34
        Public Const FT_8_TYPE As Integer = &O40
        Public Const FT_4_TYPE As Integer = &O44
        Public Const UINT_8_TYPE As Integer = &O50
        Public Const UINT_1_TYPE As Integer = &O51
        Public Const UINT_2_TYPE As Integer = &O52
        Public Const UINT_4_TYPE As Integer = &O54
        Property T1 As Single
        Property T2 As Single
        Property T3 As Integer
        Property T4 As Integer
        Property T5 As Integer
        Property T6 As Integer
        Property T7 As Integer
        Property T8 As Integer
        Property szLocalIP As String

        Property nLocalPort As Integer
        Property lDeviceID As Integer
        Event QSEvent(lID As Integer, lMsgID As Integer, S As Integer, F As Integer, W_Bit As Integer, ulSystemBytes As UInteger, RawData As Object, Head As Object, pEventText As String)
        Private socket1 As Socket
        Private tcpsocket As Socket
        Private connect_idx As Long
        Private Pre_connect_idx As Long
        'Public DataItemOut_idx As Integer



        Public SoftName As String
        Public Ver As String
        Public CommType As Integer = 0
        Public Lport As Integer = 5002
        Dim systembyte As UInt32 = 1

        Function Initialize() As Integer
            Initialize = 0
            SoftName = "AGVC"
            Ver = "1.01"


        End Function
        Function Start(Optional McsPort As Integer = 5001) As Integer
            Start = 0
            Lport = McsPort
            Dim hostEndPoint As IPEndPoint
            Dim ip(3) As Byte
            Dim ByteGet(9) As Byte
            Dim selectreq(13) As Byte
            Dim conPort As Integer = McsPort


            socket1 = New Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
            If CommType = 0 Then

                Dim ListenThread1 As New Thread(AddressOf StartListen)
                ListenThread1.IsBackground = True
                ListenThread1.Start()

            Else

                ip(0) = 127
                ip(1) = 0
                ip(2) = 0
                ip(3) = 1
                selectreq(0) = &H0
                selectreq(1) = &H0
                selectreq(2) = &H0
                selectreq(3) = &HA
                selectreq(4) = &HFF
                selectreq(5) = &HFF
                selectreq(6) = &H0
                selectreq(7) = &H0
                selectreq(8) = &H0
                selectreq(9) = &H1
                selectreq(10) = &H0
                selectreq(11) = &H0
                selectreq(12) = &H0
                selectreq(13) = &H1


                Dim hostAddress As IPAddress = New IPAddress(ip)
                Dim temp(10) As Byte
                hostEndPoint = New IPEndPoint(hostAddress, conPort)
                Try
                    socket1.Connect(hostEndPoint)
                Catch ex As Exception

                End Try

                If socket1.Connected Then
                    socket1.Send(selectreq, selectreq.Length, 0)
                    Thread.Sleep(100)
                    'len = socket1.Receive(ByteGet)
                    ' MsgBox(byte2str(ByteGet, 0, len))
                    'socket1.Close()
                    Dim recivethread As New Thread(AddressOf reciveData)
                    recivethread.IsBackground = True
                    tcpsocket = socket1
                    recivethread.Start()
                    Start = 0
                    RaiseEvent QSEvent(2, 3, 0, 0, 0, 0, temp, "", "")
                Else
                    Start = 1
                End If
            End If



        End Function
        Public Sub StartListen()
            Dim icount As Integer = 0
            Dim ep As New IPEndPoint(IPAddress.Any, Lport)
            socket1.Bind(ep)
            socket1.Listen(Lport)

            Do
                tcpsocket = socket1.Accept
                If tcpsocket.Connected Then
                    connect_idx = Now.Ticks
                    Pre_connect_idx = connect_idx
                    Dim ReceiveThread As New Thread(AddressOf reciveData)
                    ReceiveThread.IsBackground = True
                    ReceiveThread.Start()

                    icount += 1
                End If
            Loop
            MsgBox(1)
        End Sub
        Sub reciveData()
            Dim myRawData(10000) As Byte
            Dim client_stream As NetworkStream = New NetworkStream(tcpsocket)
            Dim systembyte(3) As Byte
            Dim reply(2000) As Byte
            Dim s, f, w As Integer
            Dim ReviceLen As Integer
            Dim timeTick As Long = Now.Ticks

            Try
                While (Pre_connect_idx = connect_idx)


            
                    If ReviceLen > 0 And Now.Ticks - timeTick > 40000000 Then
                        RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "timeout:" + (Now.Ticks - timeTick).ToString)
                        ReviceLen = 0
                        timeTick = Now.Ticks
                    End If
                    If client_stream.DataAvailable Or ReviceLen > 0 Then
                        timeTick = Now.Ticks
                        client_stream.ReadTimeout = 100
                        Dim temp(10000) As Byte
                        Dim thisLen As Integer = 0

                        If ReviceLen = 0 Then
                            thisLen = client_stream.Read(myRawData, ReviceLen, 5000)
                            Array.Copy(myRawData, ReviceLen, temp, 0, thisLen)
                            RaiseEvent QSEvent(3, 1, 0, 0, 0, thisLen, temp, "", "")
                        ElseIf ReviceLen > 0 Then

                            RaiseEvent QSEvent(3, 2, 0, 0, 0, 0, myRawData, "", "")
                        Else
                            ReviceLen = 0
                            RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "Len<0")

                        End If




                        ReviceLen += thisLen


                        'settext("收到:" + byte2str(myRawData, 0, ReviceLen))
                        Array.Copy(myRawData, 10, systembyte, 0, 4)
                        If myRawData(0) = 0 And myRawData(1) = 0 And myRawData(2) = 0 And myRawData(3) = &HA And myRawData(4) = &HFF And myRawData(5) = &HFF Then
                            If myRawData(9) = 1 Then
                                '系統byte   

                                Array.Copy(myRawData, reply, 14)
                                reply(9) = 2
                                tcpsocket.Send(reply, 0, 14, SocketFlags.None)
                                RaiseEvent QSEvent(2, 3, 0, 0, 0, 0, Nothing, "", "")
                            ElseIf myRawData(9) = 5 Then
                                '連線測試
                                Array.Copy(myRawData, reply, 14)
                                reply(9) = 6
                                tcpsocket.Send(reply, 0, 14, SocketFlags.None)
                                Dim replysystembytes(3) As Byte
                                Array.Copy(myRawData, 10, replysystembytes, 0, 4)
                                Array.Reverse(replysystembytes)
                                Dim systemid As UInt32 = BitConverter.ToUInt32(replysystembytes, 0)
                                RaiseEvent QSEvent(2, 15, 0, 0, 0, systemid, Nothing, "", "")
                            ElseIf myRawData(9) = 9 Then
                                '連線測試
                                tcpsocket.Close()
                                client_stream.Close()
                                RaiseEvent QSEvent(2, 4, 0, 0, 0, 0, Nothing, "", "")
                            End If

                            For i As Integer = 0 To ReviceLen - 14 - 1
                                myRawData(i) = myRawData(14 + i)
                            Next

                            ReviceLen -= 14

                        ElseIf myRawData(0) * 256 * 256 * 256 + myRawData(1) * 256 * 256 + myRawData(2) * 256 + myRawData(3) = ReviceLen - 4 Then
                            '開始解析
                            '紀錄system id 
                            Dim replysystembytes(3) As Byte
                            w = myRawData(6) >> 7
                            s = myRawData(6) Mod 128
                            f = myRawData(7)

                            Array.Copy(myRawData, 10, replysystembytes, 0, 4)
                            Array.Reverse(replysystembytes)
                            Dim systemid As UInt32 = BitConverter.ToUInt32(replysystembytes, 0)
                            Dim RawData(ReviceLen - 1 - 14) As Byte
                            Array.Copy(myRawData, 14, RawData, 0, ReviceLen - 14)
                            RaiseEvent QSEvent(1, 1, s, f, w, systemid, RawData, "", "")
                            ' settext("recive:S" + s.ToString + "F" + f.ToString + " Len:" + ReviceLen.ToString)
                            ReviceLen = 0
                        ElseIf myRawData(0) * 256 * 256 * 256 + myRawData(1) * 256 * 256 + myRawData(2) * 256 + myRawData(3) < ReviceLen - 4 Then
                            Try
                                Dim replysystembytes(3) As Byte
                                Dim strlen As UInteger = myRawData(0) * 256 * 256 * 256 + myRawData(1) * 256 * 256 + myRawData(2) * 256 + myRawData(3)
                                w = myRawData(6) >> 7
                                s = myRawData(6) Mod 128
                                f = myRawData(7)
                                Array.Copy(myRawData, 10, replysystembytes, 0, 4)
                                Array.Reverse(replysystembytes)
                                Dim systemid As UInt32 = BitConverter.ToUInt32(replysystembytes, 0)
                                Dim RawData(strlen - 1 - 10) As Byte
                                Array.Copy(myRawData, 14, RawData, 0, strlen - 10)
                                For i As Integer = 0 To ReviceLen - 4 - strlen - 1
                                    myRawData(i) = myRawData(4 + strlen + i)
                                Next

                                RaiseEvent QSEvent(1, 16, s, f, w, systemid, RawData, "", "")
                                ' settext("recive:S" + s.ToString + "F" + f.ToString + " Len:" + ReviceLen.ToString)
                                ReviceLen = ReviceLen - 4 - strlen
                            Catch ex As Exception
                                Try
                                    RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "CutErr:" + ex.Message)
                                Catch ex1 As Exception

                                End Try


                                ReviceLen = 0

                            End Try


                        End If
                    End If
                    Thread.Sleep(1)
                End While
            Catch ex As Exception
                RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "LoopErr:" + ex.Message)
            End Try
            Try
                client_stream.Close()
                client_stream.Dispose()
                RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "close client_stream")
            Catch ex As Exception

            End Try

            Try
                tcpsocket.Close()
                tcpsocket.Dispose()
                RaiseEvent QSEvent(4, 2, 0, 0, w, 0, myRawData, "", "close tcp")
            Catch ex As Exception

            End Try
        End Sub
        Function Encode(ByVal S As Byte, ByVal F As Byte, ByVal wBit As Byte, ByVal ulSystemBytes As Long, ByVal rawdata() As Byte, ByRef refData() As Byte) As Long
            Dim temp(3) As Byte
            Encode = 10 + rawdata.Length
            temp = BitConverter.GetBytes(Encode)
            For i As Integer = 0 To 3
                refData(i) = temp(3 - i)
            Next
            refData(4) = 0
            refData(5) = 0
            refData(6) = (wBit << 7) + S
            refData(7) = F
            refData(8) = 0
            refData(9) = 0

            temp = BitConverter.GetBytes(ulSystemBytes)
            For i As Integer = 0 To 3
                refData(10 + i) = temp(3 - i)
            Next

            For i As Integer = 0 To rawdata.Length - 1
                refData(14 + i) = rawdata(i)
            Next

        End Function

        Function [Stop]() As Integer
            Return 0

        End Function
        Function GetDataItemType(ByRef pRawData As Object, lCurOffset As Integer) As Integer
            Dim RawData() As Byte = CType(pRawData, Byte())
            Return RawData(lCurOffset) >> 2
        End Function
        Function DataItemOut(ByRef pRawData As Object, ByVal lLen As Integer, ByVal lType As Integer, ByRef pData As Object, ByVal offset As Integer) As Integer

            'Function DataItemout(ByRef pRawData As Object, lCurOffset As Integer, lType As Integer, ByRef pLen As Integer, ByRef pData As Object) As ULong
            DataItemOut = offset
            Try

                Dim formatbyte As Byte = 0
                Dim lenByte As Byte = 0
                Dim DataLen As Integer = 0

                Dim data() As Byte = CType(pRawData, Byte())

                Dim unitlen As Integer = GetTypeLen(lType)

                DataItemOut += 1


                If lType = 0 Then
                    DataLen = lLen
                Else
                    DataLen = lLen * unitlen
                End If

                If DataLen > (2 ^ 16) - 1 Then
                    lenByte = 3
                    Array.Resize(data, offset + 1 + lenByte + lLen * unitlen)
                    data(offset + 1) = DataLen >> 16
                    data(offset + 2) = (DataLen >> 8) Mod 256
                    data(offset + 3) = DataLen Mod 256
                    DataItemOut += 3
                ElseIf DataLen > (2 ^ 8) - 1 Then
                    lenByte = 2
                    Array.Resize(data, offset + 1 + lenByte + lLen * unitlen)
                    data(offset + 1) = (DataLen >> 8) Mod 256
                    data(offset + 2) = DataLen Mod 256
                    DataItemOut += 2
                Else
                    lenByte = 1
                    Array.Resize(data, offset + 1 + lenByte + lLen * unitlen)
                    data(offset + 1) = DataLen Mod 256
                    DataItemOut += 1
                End If
                formatbyte = (lType << 2) + lenByte
                data(offset) = formatbyte
                Dim a(unitlen - 1) As Byte
                'Dim temp() As UInt16 = pData
                If Not lType = 0 Then

                    For i As Integer = 0 To lLen - 1
                        '如果只有一個值就直接取值
                        If lLen = 1 And Not lType = SECSComm.ASCII_TYPE And Not IsArray(pData) Then
                            a = BitConverter.GetBytes(pData)
                        Else
                            a = BitConverter.GetBytes(pData(i))
                        End If


                        For j As Integer = 0 To unitlen - 1
                            data(DataItemOut + i + j) = a(unitlen - 1 - j)
                        Next
                    Next
                End If

                pRawData = data
                DataItemOut += lLen * unitlen
            Catch ex As Exception
                RaiseEvent QSEvent(4, 1, 0, 0, 0, lLen, pData, "", "")
            End Try
        End Function
        Function GetTypeLen(ByVal ltype As Integer)
            GetTypeLen = 0
            Select Case ltype
                Case LIST_TYPE  '00 list
                    GetTypeLen = 0
                Case BINARY_TYPE  '10 binary
                    GetTypeLen = 1
                Case BOOLEAN_TYPE  '11 Boolean
                    GetTypeLen = 1
                Case 16 '20 ASCii
                    GetTypeLen = 1
                Case JIS_TYPE  '21 JIS-8
                    GetTypeLen = 0
                Case CHAR_2_TYPE  '22 2-byte character
                    GetTypeLen = 2
                Case INT_8_TYPE  '30 8-byte integer (signed)
                    GetTypeLen = 8
                Case INT_1_TYPE  '31 1-byte integer (signed)
                    GetTypeLen = 1
                Case INT_2_TYPE  '32 2-byte integer (signed)
                    GetTypeLen = 2
                Case INT_4_TYPE  '34 4-byte integer (signed)
                    GetTypeLen = 4
                Case FT_8_TYPE  '40 8-byte floating point
                    GetTypeLen = 8
                Case FT_4_TYPE  '44 4-byte floating point
                    GetTypeLen = 4
                Case UINT_8_TYPE  '50 8-byte integer (unsigned)
                    GetTypeLen = 8
                Case UINT_1_TYPE  '51 1-byte integer (unsigned)
                    GetTypeLen = 1
                Case UINT_2_TYPE  '52 2-byte integer (unsigned)
                    GetTypeLen = 2
                Case UINT_4_TYPE  '54 4-byte integer (unsigned)
                    GetTypeLen = 4
            End Select
        End Function
        Function DataItemIn(ByRef pRawData As Object, lCurOffset As Integer, lType As Integer, ByRef pLen As Integer, ByRef pData As Object) As Integer
            DataItemIn = 0
            Dim RawData() As Byte = CType(pRawData, Byte())
            Dim formatbyte As Byte = 0
            Dim lenByte As Byte = 0
            Dim dataLen As Integer = 0
            lenByte = RawData(lCurOffset) Mod 4
            lType = RawData(lCurOffset) >> 2
            dataLen = RawData(lCurOffset + 1)
            Select Case lType
                Case 0 '00 list
                    'NullData
                    pLen = dataLen

                    DataItemIn = lCurOffset + 2
                Case 8 '10 binary
                    Dim data(dataLen - 1) As Byte
                    Array.Copy(RawData, lCurOffset + 2, data, 0, dataLen)
                    pData = data
                    pLen = dataLen
                Case 9 '11 Boolean
                    Dim data(dataLen - 1) As Byte
                    Array.Copy(RawData, lCurOffset + 2, data, 0, dataLen)
                    pData = data
                    pLen = dataLen
                Case 16 '20 ASCii

                    Dim str As String
                    str = System.Text.Encoding.UTF8.GetString(RawData, lCurOffset + 2, dataLen)
                    pData = str
                    pLen = dataLen
                Case 17 '21 JIS-8
                Case 18 '22 2-byte character
                Case 24 '30 8-byte integer (signed)
                    Dim unit As Integer = 8
                    Dim intval(dataLen / unit - 1) As Long
                    Dim temp(unit - 1) As Byte
                    For i As Integer = 0 To dataLen - 1 Step unit
                        Array.Copy(RawData, lCurOffset + i + 2, temp, 0, unit)
                        Array.Reverse(temp)
                        intval(i / unit) = BitConverter.ToInt64(temp, 0)
                    Next
                    pData = intval
                    pLen = dataLen / unit
                Case 25 '31 1-byte integer (signed)
                    Dim I1(dataLen - 1) As Integer
                    For i As Integer = 0 To dataLen - 1 Step 1
                        If RawData(lCurOffset + i + 2) Then
                            I1(i) = RawData(lCurOffset + i + 2)
                        End If
                        If I1(i) > 128 Then
                            I1(i) = I1(i) - 256
                        End If
                    Next
                    pData = I1
                    pLen = dataLen
                Case 26 '32 2-byte integer (signed)
                    Dim unit As Integer = 2
                    Dim intval(dataLen / unit - 1) As Long
                    Dim temp(unit - 1) As Byte
                    For i As Integer = 0 To dataLen - 1 Step unit
                        Array.Copy(RawData, lCurOffset + i + 2, temp, 0, unit)
                        Array.Reverse(temp)
                        intval(i / unit) = BitConverter.ToInt16(temp, 0)
                    Next
                    pData = intval
                    pLen = dataLen / unit
                Case 28 '34 4-byte integer (signed)
                    Dim unit As Integer = 4
                    Dim intval(dataLen / unit - 1) As Long
                    Dim temp(unit - 1) As Byte
                    For i As Integer = 0 To dataLen - 1 Step unit
                        Array.Copy(RawData, lCurOffset + i + 2, temp, 0, unit)
                        Array.Reverse(temp)
                        intval(i / unit) = BitConverter.ToInt32(temp, 0)
                    Next
                    pData = intval
                    pLen = dataLen / unit
                Case 32 '40 8-byte floating point
                    Dim f8(dataLen / 8 - 1) As Double
                    Dim fbyte(7) As Byte
                    For i As Integer = 0 To dataLen - 1 Step 8
                        Array.Copy(RawData, lCurOffset + i + 2, fbyte, 0, 8)
                        Array.Reverse(fbyte)
                        f8(i / 4) = BitConverter.ToSingle(fbyte, 0)
                    Next
                    pData = f8
                    pLen = dataLen / 8
                Case 36 '44 4-byte floating point
                    Dim f4(dataLen / 4 - 1) As Single
                    Dim fbyte(3) As Byte
                    For i As Integer = 0 To dataLen - 1 Step 4

                        Array.Copy(RawData, lCurOffset + i + 2, fbyte, 0, 4)
                        Array.Reverse(fbyte)
                        'For j As Integer = 0 To 3
                        'fbyte(j) = RawData(lCurOffset + i + 2 + 3 - j)
                        'Next

                        f4(i / 4) = BitConverter.ToSingle(fbyte, 0)
                        'f4(i / 4) = BitConverter.ToSingle(RawData, lCurOffset + i + 2)
                    Next
                    pData = f4
                    pLen = dataLen / 4
                Case 40 '50 8-byte integer (unsigned) long 
                    Dim U8(dataLen / 8 - 1) As Long
                    For i As Integer = 0 To dataLen - 1 Step 8
                        U8(i / 8) = 0
                        For j As Integer = 0 To 7
                            U8(i / 8) += RawData(lCurOffset + i + 2) * (256 ^ j)
                        Next
                    Next
                    pData = U8
                    pLen = dataLen / 8
                Case 41 '51 1-byte integer (unsigned) uint
                    Dim u1(dataLen - 1) As UInteger
                    For i As Integer = 0 To dataLen - 1
                        u1(i) = RawData(lCurOffset + i + 2)
                    Next
                    pData = u1
                    pLen = dataLen
                Case 42 '52 2-byte integer (unsigned) uint
                    Dim u2(dataLen / 2 - 1) As UInteger
                    For i As Integer = 0 To dataLen - 1 Step 2
                        u2(i / 2) += RawData(lCurOffset + i + 2) * 256
                        u2(i / 2) += RawData(lCurOffset + i + 3)

                    Next
                    pData = u2
                    pLen = dataLen / 2
                Case 44 '54 4-byte integer (unsigned) uint 
                    Dim u4(dataLen / 4 - 1) As UInteger
                    For i As Integer = 0 To dataLen - 1 Step 4
                        Try
                            u4(i / 4) = RawData(lCurOffset + i + 2) * 256 * 256 * 256
                            u4(i / 4) += RawData(lCurOffset + i + 3) * 256 * 256
                            u4(i / 4) += RawData(lCurOffset + i + 4) * 256
                            u4(i / 4) += RawData(lCurOffset + i + 5)
                        Catch ex As Exception

                        End Try

                    Next
                    pData = u4
                    pLen = dataLen / 4
            End Select
            If lType = 0 Then
                DataItemIn = lCurOffset + 2
            Else
                DataItemIn = lCurOffset + 2 + dataLen
            End If

        End Function
        Sub SendSECSIIMessage(ByVal S As Integer, ByVal F As Integer, ByVal W_Bit As Integer, ByRef ulSystemBytes As UInt32, ByVal RawData() As Byte, ByVal DataLen As Integer)
            Dim temp(3) As Byte
            Dim refData(10000) As Byte

            Dim len As Integer
            If RawData Is Nothing Then
                Exit Sub
            End If
            Try
                If DataLen = 0 Then
                    len = 10
                Else
                    len = 10 + RawData.Length
                End If
            Catch ex As Exception
                DataLen = 0
                Exit Sub
            End Try



            Dim SendCnt As Integer = 0
            'Encode = 10 + RawData.Length
            If ulSystemBytes = 0 Then
                ulSystemBytes = systembyte
                systembyte += 1
                If systembyte > 100000 Then
                    systembyte = 1

                End If
            End If


            temp = BitConverter.GetBytes(len)
            For i As Integer = 0 To 3
                refData(i) = temp(3 - i)
            Next
            refData(4) = 0
            refData(5) = 0
            refData(6) = (W_Bit << 7) + S
            refData(7) = F
            refData(8) = 0
            refData(9) = 0

            temp = BitConverter.GetBytes(ulSystemBytes)
            For i As Integer = 0 To 3
                refData(10 + i) = temp(3 - i)
            Next
            If DataLen > 0 Then


                For i As Integer = 0 To RawData.Length - 1
                    refData(14 + i) = RawData(i)
                Next
            End If
            Try



                SendCnt = tcpsocket.Send(refData, 4 + len, SocketFlags.None)
                RaiseEvent QSEvent(2, 5, 0, 0, 0, 4 + len, refData, "", "")

            Catch ex As Exception

                RaiseEvent QSEvent(2, 4, 0, 0, 0, 0, Nothing, "", "")
            End Try


            'MsgBox(SendCnt)
        End Sub
        Sub TestLink()
            Dim Testreq(13) As Byte
            Dim ulSystemBytes As UInt32 = systembyte
            systembyte += 1

            Dim temp(3) As Byte
            Testreq(0) = &H0
            Testreq(1) = &H0
            Testreq(2) = &H0
            Testreq(3) = &HA
            Testreq(4) = &HFF
            Testreq(5) = &HFF
            Testreq(6) = &H0
            Testreq(7) = &H0
            Testreq(8) = &H0
            Testreq(9) = &H5
            Testreq(10) = &H0
            Testreq(11) = &H0
            Testreq(12) = &H0
            Testreq(13) = &H1
            temp = BitConverter.GetBytes(ulSystemBytes)
            For i As Integer = 0 To 3
                Testreq(10 + i) = temp(3 - i)
            Next
            Try
                tcpsocket.Send(Testreq, 14, SocketFlags.None)
            Catch ex As Exception

            End Try

        End Sub
    End Class


End Module
