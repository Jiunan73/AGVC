﻿Module STKC
    Public Const QS_EVENT_RECV_MSG = 1
    Public Const QS_EVENT_SEND_MSG = 2
    Public Const QS_EVENT_CONNECTED = 3
    Public Const QS_EVENT_DISCONNECTED = 4
    Public Const QS_EVENT_REPLY_TIMEOUT = 5

    'ECV's:
    'GEM-Stander:


    'Non GEM-Stander:


    ' SV's:
    'GEM-Stander:

    'Non GEM-Stander:
    Public Const GEM_CONTROL_STATE = 6           'U2        GemControlState '1 = Offline/Equipment Offline 2 = Offline/Attempt Online 3 = Offline/Host Offline 4 = Online/Local 5 = Online/Remote
    Public Const GEM_SC_STATE = 79       'U2        GemEstabCommDelay


    ' DVVAL's:
    'GEM-Stander:

    'Non-GEM-Stander:

    'Event ID:
    'GEM-Stander:
    'event list 

    Public Structure CmdPwt
        Dim CarIdx As Integer
        Dim CstIdx As Integer
        Dim Pwt As Integer
        Dim EQPwt As Integer
        Dim mcstime As Long
        Dim distance As Integer
        Dim total As Long
    End Structure
End Module
