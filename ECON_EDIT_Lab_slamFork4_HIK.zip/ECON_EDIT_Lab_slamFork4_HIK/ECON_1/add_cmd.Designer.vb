﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class add_cmd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.From_cb = New System.Windows.Forms.ComboBox()
        Me.To_cb = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtCar = New System.Windows.Forms.TextBox()
        Me.sql_str = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(32, 153)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "派貨"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'From_cb
        '
        Me.From_cb.FormattingEnabled = True
        Me.From_cb.Items.AddRange(New Object() {"1:往前一格", "-1往後一格", "2:頂PIN上升", "3:頂PIN下降"})
        Me.From_cb.Location = New System.Drawing.Point(90, 60)
        Me.From_cb.Name = "From_cb"
        Me.From_cb.Size = New System.Drawing.Size(121, 20)
        Me.From_cb.TabIndex = 103
        Me.From_cb.Text = "10"
        '
        'To_cb
        '
        Me.To_cb.FormattingEnabled = True
        Me.To_cb.Items.AddRange(New Object() {"1:往前一格", "-1往後一格", "2:頂PIN上升", "3:頂PIN下降"})
        Me.To_cb.Location = New System.Drawing.Point(90, 86)
        Me.To_cb.Name = "To_cb"
        Me.To_cb.Size = New System.Drawing.Size(121, 20)
        Me.To_cb.TabIndex = 102
        Me.To_cb.Text = "40"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 12)
        Me.Label1.TabIndex = 105
        Me.Label1.Text = "AGV"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 12)
        Me.Label2.TabIndex = 106
        Me.Label2.Text = "From"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(18, 12)
        Me.Label3.TabIndex = 107
        Me.Label3.Text = "To"
        '
        'txtCar
        '
        Me.txtCar.Location = New System.Drawing.Point(90, 26)
        Me.txtCar.Name = "txtCar"
        Me.txtCar.Size = New System.Drawing.Size(100, 22)
        Me.txtCar.TabIndex = 108
        '
        'sql_str
        '
        Me.sql_str.Location = New System.Drawing.Point(32, 182)
        Me.sql_str.Name = "sql_str"
        Me.sql_str.Size = New System.Drawing.Size(179, 22)
        Me.sql_str.TabIndex = 109
        '
        'add_cmd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(235, 208)
        Me.Controls.Add(Me.sql_str)
        Me.Controls.Add(Me.txtCar)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.From_cb)
        Me.Controls.Add(Me.To_cb)
        Me.Controls.Add(Me.Button1)
        Me.Name = "add_cmd"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents From_cb As System.Windows.Forms.ComboBox
    Friend WithEvents To_cb As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtCar As System.Windows.Forms.TextBox
    Friend WithEvents sql_str As System.Windows.Forms.TextBox
End Class
