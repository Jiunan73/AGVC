﻿Imports MySql.Data.MySqlClient
Public Class add_cmd

 
    Dim Mysql_str As String = "charset=utf8 ;Database=agv; Data Source=127.0.0.1;User id=agvc;Password=FA$admin01; Allow Zero Datetime=True;"
    Dim s As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim ans As Integer = 0
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        Dim from_str As String = Me.From_cb.Text.Split(":")(0)
        Dim To_str As String = Me.To_cb.Text.Split(":")(0)
        Try
            If (CInt(from_str) < 10) Then
                Dim Query As String = "INSERT INTO `agv_cmd_list` ( AGVNo,`CmdFrom`, `CmdTo`, `Pri_Wt`,RequestTime, `Requestor`) VALUES ('" + txtCar.Text + "','" + from_str + "', '" + To_str + "', '50','" + Now.ToString("yyyy-MM-dd HH:mm:ss") + "', 'AGVC');"
                sqlCommand.CommandText = Query
                ans = sqlCommand.ExecuteNonQuery()
            Else
                Dim Query As String = "insert into  `agv_cmd_list`(`AGVNo`,`CmdFrom`,`CmdTo`,`Pri_Wt`,`Requestor`,`Shelf_Car_No`,`Shelf_Car_type`,`Shelf_Car_Size`) select '" + txtCar.Text + "' as AGVNo,'" + from_str + "','" + To_str + "',50,'AGVC',Shelf_Car_No,`Shelf_Car_type`,`Shelf_Car_Size` from `shelf_car` where LOCATION='" + Me.From_cb.Text + "' "
                sqlCommand.CommandText = Query
                ans = sqlCommand.ExecuteNonQuery()
            End If

        Catch ex As Exception
            MsgBox("派貨失敗" + ex.Message)
        End Try
        If (Not ans = 1) Then
            MsgBox("派貨失敗:來源無架台或目的端有架台")
        End If
        oConn.Close()
        oConn.Dispose()
        Me.Hide()
    End Sub


    Private Sub add_cmd_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim mReader As MySqlDataReader
        Dim Query As String = "SELECT Tag_ID,X,Y,tag_type,Tag_name FROM `point` where Tag_ID between 0 and 9999  order by Tag_ID ASC"
        sql_str.Hide()

        Mysql_str = sql_str.Text
        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        sqlCommand.CommandText = Query
        mReader = sqlCommand.ExecuteReader()
        While (mReader.Read)
            Me.From_cb.Items.Add(mReader.Item(0).ToString + ":" + mReader.Item(4).ToString)
            Me.To_cb.Items.Add(mReader.Item(0).ToString + ":" + mReader.Item(4).ToString)
        End While
        mReader.Close()
        oConn.Close()
    End Sub
End Class