﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class shelfForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ZONE_NAME = New System.Windows.Forms.ComboBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CarrierIDTxt = New System.Windows.Forms.TextBox()
        Me.listView = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Tag_ID = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.AXIS_X = New System.Windows.Forms.TextBox()
        Me.SHELF_STATUS = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.AXIS_Y = New System.Windows.Forms.TextBox()
        Me.SHELF_STN_NO = New System.Windows.Forms.TextBox()
        Me.SHELF_LOC = New System.Windows.Forms.TextBox()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ZONE_NAME
        '
        Me.ZONE_NAME.FormattingEnabled = True
        Me.ZONE_NAME.Location = New System.Drawing.Point(429, 21)
        Me.ZONE_NAME.Name = "ZONE_NAME"
        Me.ZONE_NAME.Size = New System.Drawing.Size(121, 20)
        Me.ZONE_NAME.TabIndex = 375
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(758, 126)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 379
        Me.Button5.Text = "修改"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(554, 25)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 16)
        Me.Label3.TabIndex = 383
        Me.Label3.Text = "SHELF_LOC"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(361, 25)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 16)
        Me.Label2.TabIndex = 382
        Me.Label2.Text = "ZONENAME"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(189, 25)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 16)
        Me.Label1.TabIndex = 381
        Me.Label1.Text = "CarrierID"
        '
        'CarrierIDTxt
        '
        Me.CarrierIDTxt.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.CarrierIDTxt.Location = New System.Drawing.Point(246, 18)
        Me.CarrierIDTxt.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.CarrierIDTxt.Name = "CarrierIDTxt"
        Me.CarrierIDTxt.Size = New System.Drawing.Size(114, 23)
        Me.CarrierIDTxt.TabIndex = 374
        '
        'listView
        '
        Me.listView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8})
        Me.listView.Location = New System.Drawing.Point(14, 97)
        Me.listView.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.listView.Name = "listView"
        Me.listView.Size = New System.Drawing.Size(736, 523)
        Me.listView.TabIndex = 380
        Me.listView.UseCompatibleStateImageBehavior = False
        Me.listView.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Tag = "A"
        Me.ColumnHeader1.Text = "TagID"
        Me.ColumnHeader1.Width = 79
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Tag = "B"
        Me.ColumnHeader2.Text = "CarrierID"
        Me.ColumnHeader2.Width = 169
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "ZoneName"
        Me.ColumnHeader3.Width = 80
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Shelf_Loc"
        Me.ColumnHeader4.Width = 80
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(13, 28)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 16)
        Me.Label4.TabIndex = 385
        Me.Label4.Text = "TagId"
        '
        'Tag_ID
        '
        Me.Tag_ID.Enabled = False
        Me.Tag_ID.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Tag_ID.Location = New System.Drawing.Point(70, 21)
        Me.Tag_ID.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Tag_ID.Name = "Tag_ID"
        Me.Tag_ID.Size = New System.Drawing.Size(114, 23)
        Me.Tag_ID.TabIndex = 384
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 62)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 16)
        Me.Label5.TabIndex = 393
        Me.Label5.Text = "AXIS_X"
        '
        'AXIS_X
        '
        Me.AXIS_X.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.AXIS_X.Location = New System.Drawing.Point(70, 55)
        Me.AXIS_X.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.AXIS_X.Name = "AXIS_X"
        Me.AXIS_X.Size = New System.Drawing.Size(114, 23)
        Me.AXIS_X.TabIndex = 392
        '
        'SHELF_STATUS
        '
        Me.SHELF_STATUS.FormattingEnabled = True
        Me.SHELF_STATUS.Location = New System.Drawing.Point(632, 55)
        Me.SHELF_STATUS.Name = "SHELF_STATUS"
        Me.SHELF_STATUS.Size = New System.Drawing.Size(121, 20)
        Me.SHELF_STATUS.TabIndex = 388
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(554, 59)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 16)
        Me.Label6.TabIndex = 391
        Me.Label6.Text = "STATUS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label7.Location = New System.Drawing.Point(361, 59)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 16)
        Me.Label7.TabIndex = 390
        Me.Label7.Text = "SHELF_NO"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label8.Location = New System.Drawing.Point(189, 59)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 16)
        Me.Label8.TabIndex = 389
        Me.Label8.Text = "AXIS_Y"
        '
        'AXIS_Y
        '
        Me.AXIS_Y.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.AXIS_Y.Location = New System.Drawing.Point(246, 52)
        Me.AXIS_Y.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.AXIS_Y.Name = "AXIS_Y"
        Me.AXIS_Y.Size = New System.Drawing.Size(114, 23)
        Me.AXIS_Y.TabIndex = 386
        '
        'SHELF_STN_NO
        '
        Me.SHELF_STN_NO.AcceptsReturn = True
        Me.SHELF_STN_NO.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SHELF_STN_NO.Location = New System.Drawing.Point(429, 55)
        Me.SHELF_STN_NO.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.SHELF_STN_NO.Name = "SHELF_STN_NO"
        Me.SHELF_STN_NO.Size = New System.Drawing.Size(121, 23)
        Me.SHELF_STN_NO.TabIndex = 394
        '
        'SHELF_LOC
        '
        Me.SHELF_LOC.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SHELF_LOC.Location = New System.Drawing.Point(636, 22)
        Me.SHELF_LOC.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.SHELF_LOC.Name = "SHELF_LOC"
        Me.SHELF_LOC.Size = New System.Drawing.Size(114, 23)
        Me.SHELF_LOC.TabIndex = 395
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "AZIS_X"
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "AZIS_Y"
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "SHELF_NO"
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "STATUS"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(758, 97)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 377
        Me.Button2.Text = "refresh"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'shelfForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(851, 633)
        Me.Controls.Add(Me.SHELF_LOC)
        Me.Controls.Add(Me.SHELF_STN_NO)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.AXIS_X)
        Me.Controls.Add(Me.SHELF_STATUS)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.AXIS_Y)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Tag_ID)
        Me.Controls.Add(Me.ZONE_NAME)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CarrierIDTxt)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.listView)
        Me.Name = "shelfForm"
        Me.Text = "SHELF"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ZONE_NAME As System.Windows.Forms.ComboBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CarrierIDTxt As System.Windows.Forms.TextBox
    Friend WithEvents listView As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Tag_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents AXIS_X As System.Windows.Forms.TextBox
    Friend WithEvents SHELF_STATUS As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents AXIS_Y As System.Windows.Forms.TextBox
    Friend WithEvents SHELF_STN_NO As System.Windows.Forms.TextBox
    Friend WithEvents SHELF_LOC As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
