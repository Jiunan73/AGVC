﻿Public Class shelfForm

    Private Sub Carrier_list_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listView.SelectedIndexChanged
        If listView.SelectedItems.Count > 0 Then
            Tag_ID.Text = listView.SelectedItems(0).SubItems(0).Text.ToString
            CarrierIDTxt.Text = listView.SelectedItems(0).SubItems(1).Text.ToString
            ZONE_NAME.Text = listView.SelectedItems(0).SubItems(2).Text.ToString
            SHELF_LOC.Text = listView.SelectedItems(0).SubItems(3).Text.ToString
            AXIS_X.Text = listView.SelectedItems(0).SubItems(4).Text.ToString
            AXIS_Y.Text = listView.SelectedItems(0).SubItems(5).Text.ToString
            SHELF_STN_NO.Text = listView.SelectedItems(0).SubItems(6).Text.ToString
            SHELF_STATUS.Text = listView.SelectedItems(0).SubItems(7).Text.ToString
        End If

    End Sub

    Private Sub shelfForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Button2_Click(sender, e)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        listView.Items.Clear()

        For i As Integer = 0 To Form1.comQGWrapper.ShelfData.Length - 1
            Dim item As New ListViewItem()
            item.Text = Form1.comQGWrapper.ShelfData(i).tag_id
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).CarrierID)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).Zone_Name)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).Shelf_Loc)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).AXIS_X.ToString)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).AXIS_Y.ToString)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).SHELF_STN_NO.ToString)
            item.SubItems.Add(Form1.comQGWrapper.ShelfData(i).Shelf_Status.ToString)
            listView.Items.Add(item)
        Next
    End Sub
End Class