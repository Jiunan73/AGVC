﻿Imports MySql.Data.MySqlClient
Public Class transfer
    Public Mysql_str As String
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim oConn As MySqlConnection
        Dim sqlCommand As New MySqlCommand
        Dim Query As String = ""
        Dim mReader As MySqlDataReader

        oConn = New MySqlConnection(Mysql_str)
        oConn.Open()
        sqlCommand.Connection = oConn
        Query = "select a.CmdKey '編號', a.AGVNo 'AGV',if( b.Tag_name is null,a.CmdFrom,b.Tag_name) '從', c.Tag_name '到', a.RequestTime '命令時間', " + _
       " a.Start_Time '開始時間', a.End_Time '結束時間', if(d.Name is NULL,a.Requestor,d.Name) '操作員' ,if(a.T1<0,0,a.T1) as T1,a.T2,a.T3,a.T4 " +
       " from `agv_cmd_history` a left join `point` b on a.CmdFrom = b.Tag_ID  " + _
       "left join `point` c on a.CmdTo = c.Tag_ID " + _
       "left join `agv`.`uac_user` d on a.Requestor = d.UserID " + _
       " where (a.RequestTime)>='" + DateTimePicker1.Text.ToString + "' " + _
       " and (a.RequestTime)<='" + DateTimePicker2.Text.ToString + "' " + _
       " order by a.Shelf_Car_No, a.RequestTime "

        sqlCommand.CommandText = Query
        mReader = sqlCommand.ExecuteReader()
        alarm_list.Items.Clear()
        While mReader.Read
            Dim item As New ListViewItem()
            item.Text = mReader.Item(0)
            For i As Integer = 1 To 11
                item.SubItems.Add(mReader.Item(i).ToString)
            Next
            alarm_list.Items.Add(item)

        End While
        mReader.Close()
        oConn.Close()
        oConn.Dispose()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs)


        Dim s As Date = CDate(DateTimePicker1.Text)
        MsgBox(s.ToString("yyyy-MM-dd HH:mm:ss"))
    End Sub

    Private Sub transfer_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        DateTimePicker1.Value = Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss")
        DateTimePicker2.Value = Now.ToString("yyyy-MM-dd HH:mm:ss")
    End Sub
End Class