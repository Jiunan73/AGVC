﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Button9 = New System.Windows.Forms.Button()
        Me.EQ = New System.Windows.Forms.Timer(Me.components)
        Me.AGV_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Amp = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SOC = New System.Windows.Forms.TextBox()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Econ_49 = New System.Windows.Forms.TextBox()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Econ_48 = New System.Windows.Forms.TextBox()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Econ_47 = New System.Windows.Forms.TextBox()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Econ_46 = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Econ_45 = New System.Windows.Forms.TextBox()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Econ_44 = New System.Windows.Forms.TextBox()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Econ_43 = New System.Windows.Forms.TextBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Econ_42 = New System.Windows.Forms.TextBox()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Econ_41 = New System.Windows.Forms.TextBox()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Econ_40 = New System.Windows.Forms.TextBox()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Econ_39 = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Econ_38 = New System.Windows.Forms.TextBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Econ_37 = New System.Windows.Forms.TextBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Econ_36 = New System.Windows.Forms.TextBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Econ_35 = New System.Windows.Forms.TextBox()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Econ_34 = New System.Windows.Forms.TextBox()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Econ_33 = New System.Windows.Forms.TextBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Econ_32 = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Econ_31 = New System.Windows.Forms.TextBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Econ_30 = New System.Windows.Forms.TextBox()
        Me.Econ_29 = New System.Windows.Forms.TextBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Econ_28 = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Econ_27 = New System.Windows.Forms.TextBox()
        Me.Econ_26 = New System.Windows.Forms.TextBox()
        Me.Econ_25 = New System.Windows.Forms.TextBox()
        Me.Econ_24 = New System.Windows.Forms.TextBox()
        Me.Econ_23 = New System.Windows.Forms.TextBox()
        Me.Econ_22 = New System.Windows.Forms.TextBox()
        Me.Econ_21 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Econ_19 = New System.Windows.Forms.TextBox()
        Me.Econ_18 = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtToAGV20 = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtToAGV18 = New System.Windows.Forms.TextBox()
        Me.txtToAGV19 = New System.Windows.Forms.TextBox()
        Me.txtToAGV17 = New System.Windows.Forms.TextBox()
        Me.txtToAGV16 = New System.Windows.Forms.TextBox()
        Me.txtToAGV15 = New System.Windows.Forms.TextBox()
        Me.txtToAGV13 = New System.Windows.Forms.TextBox()
        Me.txtToAGV14 = New System.Windows.Forms.TextBox()
        Me.txtToAGV12 = New System.Windows.Forms.TextBox()
        Me.txtToAGV11 = New System.Windows.Forms.TextBox()
        Me.txtToAGV10 = New System.Windows.Forms.TextBox()
        Me.txtToAGV9 = New System.Windows.Forms.TextBox()
        Me.txtToAGV0 = New System.Windows.Forms.TextBox()
        Me.txtToAGV8 = New System.Windows.Forms.TextBox()
        Me.txtToAGV7 = New System.Windows.Forms.TextBox()
        Me.txtToAGV6 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Econ_17 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtToAGV4 = New System.Windows.Forms.TextBox()
        Me.txtToAGV5 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtToAGV3 = New System.Windows.Forms.TextBox()
        Me.txtToAGV2 = New System.Windows.Forms.TextBox()
        Me.txtToAGV1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Econ_20 = New System.Windows.Forms.TextBox()
        Me.Econ_16 = New System.Windows.Forms.TextBox()
        Me.Econ_15 = New System.Windows.Forms.TextBox()
        Me.Econ_14 = New System.Windows.Forms.TextBox()
        Me.Econ_13 = New System.Windows.Forms.TextBox()
        Me.Econ_12 = New System.Windows.Forms.TextBox()
        Me.Econ_11 = New System.Windows.Forms.TextBox()
        Me.Econ_10 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Econ_9 = New System.Windows.Forms.TextBox()
        Me.Econ_8 = New System.Windows.Forms.TextBox()
        Me.Econ_7 = New System.Windows.Forms.TextBox()
        Me.Econ_6 = New System.Windows.Forms.TextBox()
        Me.Econ_5 = New System.Windows.Forms.TextBox()
        Me.Econ_4 = New System.Windows.Forms.TextBox()
        Me.Econ_3 = New System.Windows.Forms.TextBox()
        Me.Econ_2 = New System.Windows.Forms.TextBox()
        Me.Econ_1 = New System.Windows.Forms.TextBox()
        Me.Econ_0 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.EQ_BG = New System.ComponentModel.BackgroundWorker()
        Me.AGV_BG = New System.ComponentModel.BackgroundWorker()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(150, 131)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(62, 12)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "UnLoadReq"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(34, 131)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 12)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Loadreq"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(36, 31)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 42)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "連線"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(117, 310)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 12
        Me.Button3.Text = "CV3 滾"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 200
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(36, 310)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 21
        Me.Button9.Text = "CV1 滾"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'EQ
        '
        Me.EQ.Interval = 1000
        '
        'AGV_Timer
        '
        Me.AGV_Timer.Interval = 1000
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(36, 180)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 22)
        Me.TextBox4.TabIndex = 30
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(36, 223)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 22)
        Me.TextBox5.TabIndex = 31
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(152, 180)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 22)
        Me.TextBox6.TabIndex = 32
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(198, 310)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "206=0"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(36, 281)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 34
        Me.Button4.Text = "到CV1"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(117, 281)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 35
        Me.Button5.Text = "到CV3"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label12.Location = New System.Drawing.Point(870, 69)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 16)
        Me.Label12.TabIndex = 501
        Me.Label12.Text = "電流"
        '
        'Amp
        '
        Me.Amp.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Amp.Location = New System.Drawing.Point(938, 66)
        Me.Amp.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Amp.Name = "Amp"
        Me.Amp.Size = New System.Drawing.Size(46, 23)
        Me.Amp.TabIndex = 500
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label11.Location = New System.Drawing.Point(753, 69)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(33, 16)
        Me.Label11.TabIndex = 499
        Me.Label11.Text = "SOC"
        '
        'SOC
        '
        Me.SOC.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.SOC.Location = New System.Drawing.Point(812, 66)
        Me.SOC.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.SOC.Name = "SOC"
        Me.SOC.Size = New System.Drawing.Size(46, 23)
        Me.SOC.TabIndex = 498
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label89.Location = New System.Drawing.Point(1185, 448)
        Me.Label89.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(32, 16)
        Me.Label89.TabIndex = 497
        Me.Label89.Text = "保留"
        '
        'Econ_49
        '
        Me.Econ_49.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_49.Location = New System.Drawing.Point(1248, 441)
        Me.Econ_49.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_49.Name = "Econ_49"
        Me.Econ_49.Size = New System.Drawing.Size(46, 23)
        Me.Econ_49.TabIndex = 496
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label90.Location = New System.Drawing.Point(1185, 411)
        Me.Label90.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(32, 16)
        Me.Label90.TabIndex = 495
        Me.Label90.Text = "保留"
        '
        'Econ_48
        '
        Me.Econ_48.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_48.Location = New System.Drawing.Point(1248, 403)
        Me.Econ_48.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_48.Name = "Econ_48"
        Me.Econ_48.Size = New System.Drawing.Size(46, 23)
        Me.Econ_48.TabIndex = 494
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label91.Location = New System.Drawing.Point(1183, 373)
        Me.Label91.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(32, 16)
        Me.Label91.TabIndex = 493
        Me.Label91.Text = "保留"
        '
        'Econ_47
        '
        Me.Econ_47.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_47.Location = New System.Drawing.Point(1248, 365)
        Me.Econ_47.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_47.Name = "Econ_47"
        Me.Econ_47.Size = New System.Drawing.Size(46, 23)
        Me.Econ_47.TabIndex = 492
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label93.Location = New System.Drawing.Point(1183, 335)
        Me.Label93.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(32, 16)
        Me.Label93.TabIndex = 491
        Me.Label93.Text = "保留"
        '
        'Econ_46
        '
        Me.Econ_46.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_46.Location = New System.Drawing.Point(1248, 328)
        Me.Econ_46.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_46.Name = "Econ_46"
        Me.Econ_46.Size = New System.Drawing.Size(46, 23)
        Me.Econ_46.TabIndex = 490
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label94.Location = New System.Drawing.Point(1185, 298)
        Me.Label94.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(32, 16)
        Me.Label94.TabIndex = 489
        Me.Label94.Text = "保留"
        '
        'Econ_45
        '
        Me.Econ_45.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_45.Location = New System.Drawing.Point(1248, 290)
        Me.Econ_45.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_45.Name = "Econ_45"
        Me.Econ_45.Size = New System.Drawing.Size(46, 23)
        Me.Econ_45.TabIndex = 488
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label95.Location = New System.Drawing.Point(1183, 261)
        Me.Label95.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(32, 16)
        Me.Label95.TabIndex = 487
        Me.Label95.Text = "保留"
        '
        'Econ_44
        '
        Me.Econ_44.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_44.Location = New System.Drawing.Point(1248, 253)
        Me.Econ_44.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_44.Name = "Econ_44"
        Me.Econ_44.Size = New System.Drawing.Size(46, 23)
        Me.Econ_44.TabIndex = 486
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label96.Location = New System.Drawing.Point(1183, 223)
        Me.Label96.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(32, 16)
        Me.Label96.TabIndex = 485
        Me.Label96.Text = "輸出"
        '
        'Econ_43
        '
        Me.Econ_43.AcceptsReturn = True
        Me.Econ_43.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_43.Location = New System.Drawing.Point(1248, 216)
        Me.Econ_43.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_43.Name = "Econ_43"
        Me.Econ_43.Size = New System.Drawing.Size(46, 23)
        Me.Econ_43.TabIndex = 484
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label97.Location = New System.Drawing.Point(1183, 185)
        Me.Label97.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(41, 16)
        Me.Label97.TabIndex = 483
        Me.Label97.Text = "IL誤差"
        '
        'Econ_42
        '
        Me.Econ_42.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_42.Location = New System.Drawing.Point(1248, 178)
        Me.Econ_42.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_42.Name = "Econ_42"
        Me.Econ_42.Size = New System.Drawing.Size(46, 23)
        Me.Econ_42.TabIndex = 482
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label98.Location = New System.Drawing.Point(1183, 148)
        Me.Label98.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(55, 16)
        Me.Label98.TabIndex = 481
        Me.Label98.Text = "BCR誤差"
        '
        'Econ_41
        '
        Me.Econ_41.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_41.Location = New System.Drawing.Point(1248, 141)
        Me.Econ_41.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_41.Name = "Econ_41"
        Me.Econ_41.Size = New System.Drawing.Size(46, 23)
        Me.Econ_41.TabIndex = 480
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label99.Location = New System.Drawing.Point(1183, 110)
        Me.Label99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(55, 16)
        Me.Label99.TabIndex = 479
        Me.Label99.Text = "BCR誤差"
        '
        'Econ_40
        '
        Me.Econ_40.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_40.Location = New System.Drawing.Point(1248, 103)
        Me.Econ_40.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_40.Name = "Econ_40"
        Me.Econ_40.Size = New System.Drawing.Size(46, 23)
        Me.Econ_40.TabIndex = 478
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label87.Location = New System.Drawing.Point(1080, 448)
        Me.Label87.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(41, 16)
        Me.Label87.TabIndex = 477
        Me.Label87.Text = "右側IL"
        '
        'Econ_39
        '
        Me.Econ_39.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_39.Location = New System.Drawing.Point(1129, 441)
        Me.Econ_39.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_39.Name = "Econ_39"
        Me.Econ_39.Size = New System.Drawing.Size(46, 23)
        Me.Econ_39.TabIndex = 476
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label86.Location = New System.Drawing.Point(1080, 411)
        Me.Label86.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(41, 16)
        Me.Label86.TabIndex = 475
        Me.Label86.Text = "右側IL"
        '
        'Econ_38
        '
        Me.Econ_38.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_38.Location = New System.Drawing.Point(1129, 403)
        Me.Econ_38.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_38.Name = "Econ_38"
        Me.Econ_38.Size = New System.Drawing.Size(46, 23)
        Me.Econ_38.TabIndex = 474
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label85.Location = New System.Drawing.Point(1080, 373)
        Me.Label85.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(41, 16)
        Me.Label85.TabIndex = 473
        Me.Label85.Text = "左側IL"
        '
        'Econ_37
        '
        Me.Econ_37.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_37.Location = New System.Drawing.Point(1129, 365)
        Me.Econ_37.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_37.Name = "Econ_37"
        Me.Econ_37.Size = New System.Drawing.Size(46, 23)
        Me.Econ_37.TabIndex = 472
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label84.Location = New System.Drawing.Point(1080, 335)
        Me.Label84.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(41, 16)
        Me.Label84.TabIndex = 471
        Me.Label84.Text = "左側IL"
        '
        'Econ_36
        '
        Me.Econ_36.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_36.Location = New System.Drawing.Point(1129, 328)
        Me.Econ_36.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_36.Name = "Econ_36"
        Me.Econ_36.Size = New System.Drawing.Size(46, 23)
        Me.Econ_36.TabIndex = 470
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label83.Location = New System.Drawing.Point(1080, 298)
        Me.Label83.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(38, 16)
        Me.Label83.TabIndex = 469
        Me.Label83.Text = "BCRY"
        '
        'Econ_35
        '
        Me.Econ_35.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_35.Location = New System.Drawing.Point(1129, 290)
        Me.Econ_35.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_35.Name = "Econ_35"
        Me.Econ_35.Size = New System.Drawing.Size(46, 23)
        Me.Econ_35.TabIndex = 468
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label82.Location = New System.Drawing.Point(1080, 261)
        Me.Label82.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(39, 16)
        Me.Label82.TabIndex = 467
        Me.Label82.Text = "BCRX"
        '
        'Econ_34
        '
        Me.Econ_34.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_34.Location = New System.Drawing.Point(1129, 253)
        Me.Econ_34.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_34.Name = "Econ_34"
        Me.Econ_34.Size = New System.Drawing.Size(46, 23)
        Me.Econ_34.TabIndex = 466
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label81.Location = New System.Drawing.Point(1080, 223)
        Me.Label81.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(32, 16)
        Me.Label81.TabIndex = 465
        Me.Label81.Text = "輸出"
        '
        'Econ_33
        '
        Me.Econ_33.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_33.Location = New System.Drawing.Point(1129, 216)
        Me.Econ_33.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_33.Name = "Econ_33"
        Me.Econ_33.Size = New System.Drawing.Size(46, 23)
        Me.Econ_33.TabIndex = 464
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label64.Location = New System.Drawing.Point(1080, 185)
        Me.Label64.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(39, 16)
        Me.Label64.TabIndex = 463
        Me.Label64.Text = "輸入3"
        '
        'Econ_32
        '
        Me.Econ_32.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_32.Location = New System.Drawing.Point(1129, 178)
        Me.Econ_32.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_32.Name = "Econ_32"
        Me.Econ_32.Size = New System.Drawing.Size(46, 23)
        Me.Econ_32.TabIndex = 462
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label60.Location = New System.Drawing.Point(1080, 148)
        Me.Label60.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(39, 16)
        Me.Label60.TabIndex = 461
        Me.Label60.Text = "輸入2"
        '
        'Econ_31
        '
        Me.Econ_31.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_31.Location = New System.Drawing.Point(1129, 141)
        Me.Econ_31.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_31.Name = "Econ_31"
        Me.Econ_31.Size = New System.Drawing.Size(46, 23)
        Me.Econ_31.TabIndex = 460
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label69.Location = New System.Drawing.Point(1080, 110)
        Me.Label69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(39, 16)
        Me.Label69.TabIndex = 459
        Me.Label69.Text = "輸入1"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label70.Location = New System.Drawing.Point(994, 448)
        Me.Label70.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(30, 16)
        Me.Label70.TabIndex = 458
        Me.Label70.Text = "CST"
        '
        'Econ_30
        '
        Me.Econ_30.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_30.Location = New System.Drawing.Point(1129, 103)
        Me.Econ_30.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_30.Name = "Econ_30"
        Me.Econ_30.Size = New System.Drawing.Size(46, 23)
        Me.Econ_30.TabIndex = 457
        '
        'Econ_29
        '
        Me.Econ_29.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_29.Location = New System.Drawing.Point(1029, 441)
        Me.Econ_29.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_29.Name = "Econ_29"
        Me.Econ_29.Size = New System.Drawing.Size(46, 23)
        Me.Econ_29.TabIndex = 456
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label71.Location = New System.Drawing.Point(994, 411)
        Me.Label71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(30, 16)
        Me.Label71.TabIndex = 455
        Me.Label71.Text = "CST"
        '
        'Econ_28
        '
        Me.Econ_28.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_28.Location = New System.Drawing.Point(1029, 403)
        Me.Econ_28.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_28.Name = "Econ_28"
        Me.Econ_28.Size = New System.Drawing.Size(46, 23)
        Me.Econ_28.TabIndex = 454
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label73.Location = New System.Drawing.Point(994, 373)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(30, 16)
        Me.Label73.TabIndex = 453
        Me.Label73.Text = "CST"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label74.Location = New System.Drawing.Point(994, 335)
        Me.Label74.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(30, 16)
        Me.Label74.TabIndex = 452
        Me.Label74.Text = "CST"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label75.Location = New System.Drawing.Point(994, 298)
        Me.Label75.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(19, 16)
        Me.Label75.TabIndex = 451
        Me.Label75.Text = "th"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label76.Location = New System.Drawing.Point(994, 261)
        Me.Label76.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(15, 16)
        Me.Label76.TabIndex = 450
        Me.Label76.Text = "Y"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label77.Location = New System.Drawing.Point(994, 223)
        Me.Label77.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(16, 16)
        Me.Label77.TabIndex = 449
        Me.Label77.Text = "X"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label78.Location = New System.Drawing.Point(994, 185)
        Me.Label78.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(32, 16)
        Me.Label78.TabIndex = 448
        Me.Label78.Text = "保留"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label79.Location = New System.Drawing.Point(994, 148)
        Me.Label79.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(32, 16)
        Me.Label79.TabIndex = 447
        Me.Label79.Text = "保留"
        '
        'Econ_27
        '
        Me.Econ_27.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_27.Location = New System.Drawing.Point(1029, 365)
        Me.Econ_27.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_27.Name = "Econ_27"
        Me.Econ_27.Size = New System.Drawing.Size(46, 23)
        Me.Econ_27.TabIndex = 446
        '
        'Econ_26
        '
        Me.Econ_26.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_26.Location = New System.Drawing.Point(1029, 328)
        Me.Econ_26.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_26.Name = "Econ_26"
        Me.Econ_26.Size = New System.Drawing.Size(46, 23)
        Me.Econ_26.TabIndex = 445
        '
        'Econ_25
        '
        Me.Econ_25.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_25.Location = New System.Drawing.Point(1029, 290)
        Me.Econ_25.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_25.Name = "Econ_25"
        Me.Econ_25.Size = New System.Drawing.Size(46, 23)
        Me.Econ_25.TabIndex = 444
        '
        'Econ_24
        '
        Me.Econ_24.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_24.Location = New System.Drawing.Point(1029, 253)
        Me.Econ_24.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_24.Name = "Econ_24"
        Me.Econ_24.Size = New System.Drawing.Size(46, 23)
        Me.Econ_24.TabIndex = 443
        '
        'Econ_23
        '
        Me.Econ_23.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_23.Location = New System.Drawing.Point(1029, 216)
        Me.Econ_23.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_23.Name = "Econ_23"
        Me.Econ_23.Size = New System.Drawing.Size(46, 23)
        Me.Econ_23.TabIndex = 442
        '
        'Econ_22
        '
        Me.Econ_22.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_22.Location = New System.Drawing.Point(1029, 178)
        Me.Econ_22.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_22.Name = "Econ_22"
        Me.Econ_22.Size = New System.Drawing.Size(46, 23)
        Me.Econ_22.TabIndex = 441
        '
        'Econ_21
        '
        Me.Econ_21.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_21.Location = New System.Drawing.Point(1029, 141)
        Me.Econ_21.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_21.Name = "Econ_21"
        Me.Econ_21.Size = New System.Drawing.Size(46, 23)
        Me.Econ_21.TabIndex = 440
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label55.Location = New System.Drawing.Point(870, 448)
        Me.Label55.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(57, 16)
        Me.Label55.TabIndex = 439
        Me.Label55.Text = "AGV警報"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label54.Location = New System.Drawing.Point(870, 411)
        Me.Label54.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(56, 16)
        Me.Label54.TabIndex = 438
        Me.Label54.Text = "上位異常"
        '
        'Econ_19
        '
        Me.Econ_19.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_19.Location = New System.Drawing.Point(938, 441)
        Me.Econ_19.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_19.Name = "Econ_19"
        Me.Econ_19.Size = New System.Drawing.Size(46, 23)
        Me.Econ_19.TabIndex = 437
        '
        'Econ_18
        '
        Me.Econ_18.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_18.Location = New System.Drawing.Point(938, 403)
        Me.Econ_18.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_18.Name = "Econ_18"
        Me.Econ_18.Size = New System.Drawing.Size(46, 23)
        Me.Econ_18.TabIndex = 436
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label50.Location = New System.Drawing.Point(1440, 482)
        Me.Label50.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(56, 16)
        Me.Label50.TabIndex = 435
        Me.Label50.Text = "上位異常"
        '
        'txtToAGV20
        '
        Me.txtToAGV20.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV20.Location = New System.Drawing.Point(1510, 475)
        Me.txtToAGV20.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV20.Name = "txtToAGV20"
        Me.txtToAGV20.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV20.TabIndex = 434
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label41.Location = New System.Drawing.Point(1440, 448)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(56, 16)
        Me.Label41.TabIndex = 433
        Me.Label41.Text = "手動後進"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label42.Location = New System.Drawing.Point(1440, 411)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(56, 16)
        Me.Label42.TabIndex = 432
        Me.Label42.Text = "手動前進"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label43.Location = New System.Drawing.Point(1440, 373)
        Me.Label43.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(32, 16)
        Me.Label43.TabIndex = 431
        Me.Label43.Text = "保留"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label44.Location = New System.Drawing.Point(1440, 335)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(32, 16)
        Me.Label44.TabIndex = 430
        Me.Label44.Text = "保留"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label45.Location = New System.Drawing.Point(1440, 298)
        Me.Label45.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(57, 16)
        Me.Label45.TabIndex = 429
        Me.Label45.Text = "命令AGV"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label36.Location = New System.Drawing.Point(1440, 261)
        Me.Label36.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(56, 16)
        Me.Label36.TabIndex = 428
        Me.Label36.Text = "下達路徑"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label37.Location = New System.Drawing.Point(1440, 223)
        Me.Label37.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(56, 16)
        Me.Label37.TabIndex = 427
        Me.Label37.Text = "路徑地圖"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label38.Location = New System.Drawing.Point(1440, 185)
        Me.Label38.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(32, 16)
        Me.Label38.TabIndex = 426
        Me.Label38.Text = "保留"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label39.Location = New System.Drawing.Point(1440, 148)
        Me.Label39.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(32, 16)
        Me.Label39.TabIndex = 425
        Me.Label39.Text = "保留"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label40.Location = New System.Drawing.Point(1440, 110)
        Me.Label40.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(32, 16)
        Me.Label40.TabIndex = 424
        Me.Label40.Text = "保留"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label25.Location = New System.Drawing.Point(1307, 448)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(32, 16)
        Me.Label25.TabIndex = 423
        Me.Label25.Text = "保留"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label26.Location = New System.Drawing.Point(1307, 411)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(32, 16)
        Me.Label26.TabIndex = 422
        Me.Label26.Text = "保留"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label33.Location = New System.Drawing.Point(1307, 373)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(32, 16)
        Me.Label33.TabIndex = 421
        Me.Label33.Text = "保留"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label34.Location = New System.Drawing.Point(1307, 335)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(56, 16)
        Me.Label34.TabIndex = 420
        Me.Label34.Text = "搬送命令"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label35.Location = New System.Drawing.Point(1307, 298)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(61, 16)
        Me.Label35.TabIndex = 419
        Me.Label35.Text = "自動/手動"
        '
        'txtToAGV18
        '
        Me.txtToAGV18.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV18.Location = New System.Drawing.Point(1505, 403)
        Me.txtToAGV18.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV18.Name = "txtToAGV18"
        Me.txtToAGV18.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV18.TabIndex = 418
        '
        'txtToAGV19
        '
        Me.txtToAGV19.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV19.Location = New System.Drawing.Point(1505, 441)
        Me.txtToAGV19.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV19.Name = "txtToAGV19"
        Me.txtToAGV19.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV19.TabIndex = 417
        '
        'txtToAGV17
        '
        Me.txtToAGV17.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV17.Location = New System.Drawing.Point(1505, 365)
        Me.txtToAGV17.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV17.Name = "txtToAGV17"
        Me.txtToAGV17.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV17.TabIndex = 416
        '
        'txtToAGV16
        '
        Me.txtToAGV16.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV16.Location = New System.Drawing.Point(1505, 328)
        Me.txtToAGV16.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV16.Name = "txtToAGV16"
        Me.txtToAGV16.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV16.TabIndex = 415
        '
        'txtToAGV15
        '
        Me.txtToAGV15.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV15.Location = New System.Drawing.Point(1505, 290)
        Me.txtToAGV15.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV15.Name = "txtToAGV15"
        Me.txtToAGV15.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV15.TabIndex = 414
        '
        'txtToAGV13
        '
        Me.txtToAGV13.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV13.Location = New System.Drawing.Point(1505, 216)
        Me.txtToAGV13.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV13.Name = "txtToAGV13"
        Me.txtToAGV13.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV13.TabIndex = 413
        '
        'txtToAGV14
        '
        Me.txtToAGV14.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV14.Location = New System.Drawing.Point(1505, 253)
        Me.txtToAGV14.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV14.Name = "txtToAGV14"
        Me.txtToAGV14.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV14.TabIndex = 412
        '
        'txtToAGV12
        '
        Me.txtToAGV12.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV12.Location = New System.Drawing.Point(1505, 178)
        Me.txtToAGV12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV12.Name = "txtToAGV12"
        Me.txtToAGV12.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV12.TabIndex = 411
        '
        'txtToAGV11
        '
        Me.txtToAGV11.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV11.Location = New System.Drawing.Point(1505, 141)
        Me.txtToAGV11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV11.Name = "txtToAGV11"
        Me.txtToAGV11.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV11.TabIndex = 410
        '
        'txtToAGV10
        '
        Me.txtToAGV10.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV10.Location = New System.Drawing.Point(1505, 103)
        Me.txtToAGV10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV10.Name = "txtToAGV10"
        Me.txtToAGV10.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV10.TabIndex = 409
        '
        'txtToAGV9
        '
        Me.txtToAGV9.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV9.Location = New System.Drawing.Point(1379, 441)
        Me.txtToAGV9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV9.Name = "txtToAGV9"
        Me.txtToAGV9.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV9.TabIndex = 408
        '
        'txtToAGV0
        '
        Me.txtToAGV0.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV0.Location = New System.Drawing.Point(1379, 103)
        Me.txtToAGV0.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV0.Name = "txtToAGV0"
        Me.txtToAGV0.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV0.TabIndex = 407
        '
        'txtToAGV8
        '
        Me.txtToAGV8.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV8.Location = New System.Drawing.Point(1379, 403)
        Me.txtToAGV8.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV8.Name = "txtToAGV8"
        Me.txtToAGV8.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV8.TabIndex = 406
        '
        'txtToAGV7
        '
        Me.txtToAGV7.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV7.Location = New System.Drawing.Point(1379, 365)
        Me.txtToAGV7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV7.Name = "txtToAGV7"
        Me.txtToAGV7.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV7.TabIndex = 405
        '
        'txtToAGV6
        '
        Me.txtToAGV6.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV6.Location = New System.Drawing.Point(1379, 328)
        Me.txtToAGV6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV6.Name = "txtToAGV6"
        Me.txtToAGV6.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV6.TabIndex = 404
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label32.Location = New System.Drawing.Point(870, 373)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(56, 16)
        Me.Label32.TabIndex = 403
        Me.Label32.Text = "架台編號"
        '
        'Econ_17
        '
        Me.Econ_17.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_17.Location = New System.Drawing.Point(938, 365)
        Me.Econ_17.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_17.Name = "Econ_17"
        Me.Econ_17.Size = New System.Drawing.Size(46, 23)
        Me.Econ_17.TabIndex = 402
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label27.Location = New System.Drawing.Point(1307, 261)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(32, 16)
        Me.Label27.TabIndex = 401
        Me.Label27.Text = "保留"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label28.Location = New System.Drawing.Point(1307, 223)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(32, 16)
        Me.Label28.TabIndex = 400
        Me.Label28.Text = "保留"
        '
        'txtToAGV4
        '
        Me.txtToAGV4.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV4.Location = New System.Drawing.Point(1379, 253)
        Me.txtToAGV4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV4.Name = "txtToAGV4"
        Me.txtToAGV4.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV4.TabIndex = 399
        '
        'txtToAGV5
        '
        Me.txtToAGV5.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV5.Location = New System.Drawing.Point(1379, 290)
        Me.txtToAGV5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV5.Name = "txtToAGV5"
        Me.txtToAGV5.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV5.TabIndex = 398
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label23.Location = New System.Drawing.Point(1307, 185)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 16)
        Me.Label23.TabIndex = 397
        Me.Label23.Text = "保留"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label22.Location = New System.Drawing.Point(1307, 148)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(32, 16)
        Me.Label22.TabIndex = 396
        Me.Label22.Text = "保留"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label21.Location = New System.Drawing.Point(1307, 110)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(50, 16)
        Me.Label21.TabIndex = 395
        Me.Label21.Text = "Hart bit"
        '
        'txtToAGV3
        '
        Me.txtToAGV3.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV3.Location = New System.Drawing.Point(1379, 216)
        Me.txtToAGV3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV3.Name = "txtToAGV3"
        Me.txtToAGV3.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV3.TabIndex = 394
        '
        'txtToAGV2
        '
        Me.txtToAGV2.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV2.Location = New System.Drawing.Point(1379, 178)
        Me.txtToAGV2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV2.Name = "txtToAGV2"
        Me.txtToAGV2.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV2.TabIndex = 393
        '
        'txtToAGV1
        '
        Me.txtToAGV1.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.txtToAGV1.Location = New System.Drawing.Point(1379, 141)
        Me.txtToAGV1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.txtToAGV1.Name = "txtToAGV1"
        Me.txtToAGV1.Size = New System.Drawing.Size(46, 23)
        Me.txtToAGV1.TabIndex = 392
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label13.Location = New System.Drawing.Point(994, 110)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(32, 16)
        Me.Label13.TabIndex = 391
        Me.Label13.Text = "異常"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label14.Location = New System.Drawing.Point(870, 335)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 16)
        Me.Label14.TabIndex = 390
        Me.Label14.Text = "目前位置"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label15.Location = New System.Drawing.Point(870, 298)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 16)
        Me.Label15.TabIndex = 389
        Me.Label15.Text = "AGV狀態"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label16.Location = New System.Drawing.Point(870, 261)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(56, 16)
        Me.Label16.TabIndex = 388
        Me.Label16.Text = "目前命令"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label17.Location = New System.Drawing.Point(870, 223)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(56, 16)
        Me.Label17.TabIndex = 387
        Me.Label17.Text = "地圖傳送"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label18.Location = New System.Drawing.Point(870, 185)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(32, 16)
        Me.Label18.TabIndex = 386
        Me.Label18.Text = "保留"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label19.Location = New System.Drawing.Point(870, 148)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(32, 16)
        Me.Label19.TabIndex = 385
        Me.Label19.Text = "保留"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label20.Location = New System.Drawing.Point(870, 110)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(56, 16)
        Me.Label20.TabIndex = 384
        Me.Label20.Text = "電池電壓"
        '
        'Econ_20
        '
        Me.Econ_20.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_20.Location = New System.Drawing.Point(1029, 103)
        Me.Econ_20.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_20.Name = "Econ_20"
        Me.Econ_20.Size = New System.Drawing.Size(46, 23)
        Me.Econ_20.TabIndex = 383
        '
        'Econ_16
        '
        Me.Econ_16.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_16.Location = New System.Drawing.Point(938, 328)
        Me.Econ_16.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_16.Name = "Econ_16"
        Me.Econ_16.Size = New System.Drawing.Size(46, 23)
        Me.Econ_16.TabIndex = 382
        '
        'Econ_15
        '
        Me.Econ_15.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_15.Location = New System.Drawing.Point(938, 290)
        Me.Econ_15.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_15.Name = "Econ_15"
        Me.Econ_15.Size = New System.Drawing.Size(46, 23)
        Me.Econ_15.TabIndex = 381
        '
        'Econ_14
        '
        Me.Econ_14.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_14.Location = New System.Drawing.Point(938, 253)
        Me.Econ_14.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_14.Name = "Econ_14"
        Me.Econ_14.Size = New System.Drawing.Size(46, 23)
        Me.Econ_14.TabIndex = 380
        '
        'Econ_13
        '
        Me.Econ_13.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_13.Location = New System.Drawing.Point(938, 216)
        Me.Econ_13.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_13.Name = "Econ_13"
        Me.Econ_13.Size = New System.Drawing.Size(46, 23)
        Me.Econ_13.TabIndex = 379
        '
        'Econ_12
        '
        Me.Econ_12.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_12.Location = New System.Drawing.Point(938, 178)
        Me.Econ_12.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_12.Name = "Econ_12"
        Me.Econ_12.Size = New System.Drawing.Size(46, 23)
        Me.Econ_12.TabIndex = 378
        '
        'Econ_11
        '
        Me.Econ_11.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_11.Location = New System.Drawing.Point(938, 141)
        Me.Econ_11.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_11.Name = "Econ_11"
        Me.Econ_11.Size = New System.Drawing.Size(46, 23)
        Me.Econ_11.TabIndex = 377
        '
        'Econ_10
        '
        Me.Econ_10.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_10.Location = New System.Drawing.Point(938, 103)
        Me.Econ_10.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_10.Name = "Econ_10"
        Me.Econ_10.Size = New System.Drawing.Size(46, 23)
        Me.Econ_10.TabIndex = 376
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label10.Location = New System.Drawing.Point(742, 448)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 16)
        Me.Label10.TabIndex = 375
        Me.Label10.Text = "交握"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label9.Location = New System.Drawing.Point(742, 411)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 16)
        Me.Label9.TabIndex = 374
        Me.Label9.Text = "頂PIN"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label5.Location = New System.Drawing.Point(742, 373)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 373
        Me.Label5.Text = "物料感應"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label6.Location = New System.Drawing.Point(742, 335)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 16)
        Me.Label6.TabIndex = 372
        Me.Label6.Text = "搬送命令"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.Location = New System.Drawing.Point(742, 298)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 16)
        Me.Label1.TabIndex = 371
        Me.Label1.Text = "自動/手動"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label2.Location = New System.Drawing.Point(742, 261)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 16)
        Me.Label2.TabIndex = 370
        Me.Label2.Text = "障礙物"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(742, 223)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 16)
        Me.Label4.TabIndex = 369
        Me.Label4.Text = "走行速度"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(742, 185)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 368
        Me.Label3.Text = "走行動作"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label24.Location = New System.Drawing.Point(742, 148)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 16)
        Me.Label24.TabIndex = 367
        Me.Label24.Text = "走行方向"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label29.Location = New System.Drawing.Point(742, 110)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(50, 16)
        Me.Label29.TabIndex = 366
        Me.Label29.Text = "Hart bit"
        '
        'Econ_9
        '
        Me.Econ_9.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_9.Location = New System.Drawing.Point(812, 441)
        Me.Econ_9.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_9.Name = "Econ_9"
        Me.Econ_9.Size = New System.Drawing.Size(46, 23)
        Me.Econ_9.TabIndex = 365
        '
        'Econ_8
        '
        Me.Econ_8.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_8.Location = New System.Drawing.Point(812, 403)
        Me.Econ_8.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_8.Name = "Econ_8"
        Me.Econ_8.Size = New System.Drawing.Size(46, 23)
        Me.Econ_8.TabIndex = 364
        '
        'Econ_7
        '
        Me.Econ_7.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_7.Location = New System.Drawing.Point(812, 365)
        Me.Econ_7.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_7.Name = "Econ_7"
        Me.Econ_7.Size = New System.Drawing.Size(46, 23)
        Me.Econ_7.TabIndex = 363
        '
        'Econ_6
        '
        Me.Econ_6.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_6.Location = New System.Drawing.Point(812, 328)
        Me.Econ_6.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_6.Name = "Econ_6"
        Me.Econ_6.Size = New System.Drawing.Size(46, 23)
        Me.Econ_6.TabIndex = 362
        '
        'Econ_5
        '
        Me.Econ_5.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_5.Location = New System.Drawing.Point(812, 290)
        Me.Econ_5.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_5.Name = "Econ_5"
        Me.Econ_5.Size = New System.Drawing.Size(46, 23)
        Me.Econ_5.TabIndex = 361
        '
        'Econ_4
        '
        Me.Econ_4.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_4.Location = New System.Drawing.Point(812, 253)
        Me.Econ_4.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_4.Name = "Econ_4"
        Me.Econ_4.Size = New System.Drawing.Size(46, 23)
        Me.Econ_4.TabIndex = 360
        '
        'Econ_3
        '
        Me.Econ_3.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_3.Location = New System.Drawing.Point(812, 216)
        Me.Econ_3.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_3.Name = "Econ_3"
        Me.Econ_3.Size = New System.Drawing.Size(46, 23)
        Me.Econ_3.TabIndex = 359
        '
        'Econ_2
        '
        Me.Econ_2.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_2.Location = New System.Drawing.Point(812, 178)
        Me.Econ_2.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_2.Name = "Econ_2"
        Me.Econ_2.Size = New System.Drawing.Size(46, 23)
        Me.Econ_2.TabIndex = 358
        '
        'Econ_1
        '
        Me.Econ_1.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_1.Location = New System.Drawing.Point(812, 141)
        Me.Econ_1.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_1.Name = "Econ_1"
        Me.Econ_1.Size = New System.Drawing.Size(46, 23)
        Me.Econ_1.TabIndex = 357
        '
        'Econ_0
        '
        Me.Econ_0.Font = New System.Drawing.Font("Microsoft JhengHei", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Econ_0.Location = New System.Drawing.Point(812, 103)
        Me.Econ_0.Margin = New System.Windows.Forms.Padding(2, 4, 2, 4)
        Me.Econ_0.Name = "Econ_0"
        Me.Econ_0.Size = New System.Drawing.Size(46, 23)
        Me.Econ_0.TabIndex = 356
        Me.Econ_0.Text = "-1"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Location = New System.Drawing.Point(374, 373)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(301, 169)
        Me.GroupBox1.TabIndex = 502
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "電池資訊"
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(6, 18)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(289, 134)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "Label30"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(374, 12)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(301, 149)
        Me.TextBox1.TabIndex = 503
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(374, 173)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(301, 149)
        Me.TextBox2.TabIndex = 504
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(374, 328)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(301, 22)
        Me.TextBox3.TabIndex = 505
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(34, 103)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(25, 12)
        Me.Label31.TabIndex = 506
        Me.Label31.Text = "Step"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(152, 100)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 22)
        Me.TextBox7.TabIndex = 507
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(152, 31)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(102, 42)
        Me.Button6.TabIndex = 508
        Me.Button6.Text = "RESET"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(198, 286)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(25, 12)
        Me.Label46.TabIndex = 509
        Me.Label46.Text = "Step"
        '
        'EQ_BG
        '
        '
        'AGV_BG
        '
        '
        'Timer2
        '
        Me.Timer2.Interval = 2000
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(36, 384)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(102, 42)
        Me.Button7.TabIndex = 510
        Me.Button7.Text = "暫停"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(152, 385)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(102, 42)
        Me.Button8.TabIndex = 511
        Me.Button8.Text = "繼續"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(36, 432)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(102, 42)
        Me.Button10.TabIndex = 512
        Me.Button10.Text = "充電"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(152, 432)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(102, 42)
        Me.Button11.TabIndex = 513
        Me.Button11.Text = "停止充電"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(374, 548)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(301, 149)
        Me.TextBox8.TabIndex = 514
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(36, 480)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(102, 42)
        Me.Button12.TabIndex = 515
        Me.Button12.Text = "封鎖"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(152, 480)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(102, 42)
        Me.Button13.TabIndex = 516
        Me.Button13.Text = "解封"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(36, 528)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(102, 42)
        Me.Button14.TabIndex = 517
        Me.Button14.Text = "停止"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(152, 528)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(102, 42)
        Me.Button15.TabIndex = 518
        Me.Button15.Text = "恢復"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(708, 548)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(482, 149)
        Me.TextBox9.TabIndex = 519
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(1046, 12)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(75, 23)
        Me.Button16.TabIndex = 520
        Me.Button16.Text = "測試"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(1204, 471)
        Me.TextBox10.Multiline = True
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(301, 149)
        Me.TextBox10.TabIndex = 521
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1558, 769)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Amp)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.SOC)
        Me.Controls.Add(Me.Label89)
        Me.Controls.Add(Me.Econ_49)
        Me.Controls.Add(Me.Label90)
        Me.Controls.Add(Me.Econ_48)
        Me.Controls.Add(Me.Label91)
        Me.Controls.Add(Me.Econ_47)
        Me.Controls.Add(Me.Label93)
        Me.Controls.Add(Me.Econ_46)
        Me.Controls.Add(Me.Label94)
        Me.Controls.Add(Me.Econ_45)
        Me.Controls.Add(Me.Label95)
        Me.Controls.Add(Me.Econ_44)
        Me.Controls.Add(Me.Label96)
        Me.Controls.Add(Me.Econ_43)
        Me.Controls.Add(Me.Label97)
        Me.Controls.Add(Me.Econ_42)
        Me.Controls.Add(Me.Label98)
        Me.Controls.Add(Me.Econ_41)
        Me.Controls.Add(Me.Label99)
        Me.Controls.Add(Me.Econ_40)
        Me.Controls.Add(Me.Label87)
        Me.Controls.Add(Me.Econ_39)
        Me.Controls.Add(Me.Label86)
        Me.Controls.Add(Me.Econ_38)
        Me.Controls.Add(Me.Label85)
        Me.Controls.Add(Me.Econ_37)
        Me.Controls.Add(Me.Label84)
        Me.Controls.Add(Me.Econ_36)
        Me.Controls.Add(Me.Label83)
        Me.Controls.Add(Me.Econ_35)
        Me.Controls.Add(Me.Label82)
        Me.Controls.Add(Me.Econ_34)
        Me.Controls.Add(Me.Label81)
        Me.Controls.Add(Me.Econ_33)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Econ_32)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Econ_31)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.Label70)
        Me.Controls.Add(Me.Econ_30)
        Me.Controls.Add(Me.Econ_29)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Econ_28)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.Label76)
        Me.Controls.Add(Me.Label77)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.Label79)
        Me.Controls.Add(Me.Econ_27)
        Me.Controls.Add(Me.Econ_26)
        Me.Controls.Add(Me.Econ_25)
        Me.Controls.Add(Me.Econ_24)
        Me.Controls.Add(Me.Econ_23)
        Me.Controls.Add(Me.Econ_22)
        Me.Controls.Add(Me.Econ_21)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Econ_19)
        Me.Controls.Add(Me.Econ_18)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.txtToAGV20)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.txtToAGV18)
        Me.Controls.Add(Me.txtToAGV19)
        Me.Controls.Add(Me.txtToAGV17)
        Me.Controls.Add(Me.txtToAGV16)
        Me.Controls.Add(Me.txtToAGV15)
        Me.Controls.Add(Me.txtToAGV13)
        Me.Controls.Add(Me.txtToAGV14)
        Me.Controls.Add(Me.txtToAGV12)
        Me.Controls.Add(Me.txtToAGV11)
        Me.Controls.Add(Me.txtToAGV10)
        Me.Controls.Add(Me.txtToAGV9)
        Me.Controls.Add(Me.txtToAGV0)
        Me.Controls.Add(Me.txtToAGV8)
        Me.Controls.Add(Me.txtToAGV7)
        Me.Controls.Add(Me.txtToAGV6)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Econ_17)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.txtToAGV4)
        Me.Controls.Add(Me.txtToAGV5)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.txtToAGV3)
        Me.Controls.Add(Me.txtToAGV2)
        Me.Controls.Add(Me.txtToAGV1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Econ_20)
        Me.Controls.Add(Me.Econ_16)
        Me.Controls.Add(Me.Econ_15)
        Me.Controls.Add(Me.Econ_14)
        Me.Controls.Add(Me.Econ_13)
        Me.Controls.Add(Me.Econ_12)
        Me.Controls.Add(Me.Econ_11)
        Me.Controls.Add(Me.Econ_10)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Econ_9)
        Me.Controls.Add(Me.Econ_8)
        Me.Controls.Add(Me.Econ_7)
        Me.Controls.Add(Me.Econ_6)
        Me.Controls.Add(Me.Econ_5)
        Me.Controls.Add(Me.Econ_4)
        Me.Controls.Add(Me.Econ_3)
        Me.Controls.Add(Me.Econ_2)
        Me.Controls.Add(Me.Econ_1)
        Me.Controls.Add(Me.Econ_0)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Name = "Form1"
        Me.Text = "Form1_V1.02"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents EQ As System.Windows.Forms.Timer
    Friend WithEvents AGV_Timer As System.Windows.Forms.Timer
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Amp As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents SOC As System.Windows.Forms.TextBox
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Econ_49 As System.Windows.Forms.TextBox
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Econ_48 As System.Windows.Forms.TextBox
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Econ_47 As System.Windows.Forms.TextBox
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Econ_46 As System.Windows.Forms.TextBox
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Econ_45 As System.Windows.Forms.TextBox
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Econ_44 As System.Windows.Forms.TextBox
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents Econ_43 As System.Windows.Forms.TextBox
    Friend WithEvents Label97 As System.Windows.Forms.Label
    Friend WithEvents Econ_42 As System.Windows.Forms.TextBox
    Friend WithEvents Label98 As System.Windows.Forms.Label
    Friend WithEvents Econ_41 As System.Windows.Forms.TextBox
    Friend WithEvents Label99 As System.Windows.Forms.Label
    Friend WithEvents Econ_40 As System.Windows.Forms.TextBox
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Econ_39 As System.Windows.Forms.TextBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Econ_38 As System.Windows.Forms.TextBox
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Econ_37 As System.Windows.Forms.TextBox
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Econ_36 As System.Windows.Forms.TextBox
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Econ_35 As System.Windows.Forms.TextBox
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Econ_34 As System.Windows.Forms.TextBox
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Econ_33 As System.Windows.Forms.TextBox
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Econ_32 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Econ_31 As System.Windows.Forms.TextBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Econ_30 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_29 As System.Windows.Forms.TextBox
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Econ_28 As System.Windows.Forms.TextBox
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Econ_27 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_26 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_25 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_24 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_23 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_22 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_21 As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Econ_19 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_18 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV20 As System.Windows.Forms.TextBox
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV18 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV19 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV17 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV16 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV15 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV13 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV14 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV12 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV11 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV10 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV9 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV0 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV8 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV7 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV6 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Econ_17 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV4 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV5 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtToAGV3 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV2 As System.Windows.Forms.TextBox
    Friend WithEvents txtToAGV1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Econ_20 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_16 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_15 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_14 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_13 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_12 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_11 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_10 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Econ_9 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_8 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_7 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_6 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_5 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_4 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_3 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_2 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_1 As System.Windows.Forms.TextBox
    Friend WithEvents Econ_0 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents EQ_BG As System.ComponentModel.BackgroundWorker
    Friend WithEvents AGV_BG As System.ComponentModel.BackgroundWorker
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox

End Class
