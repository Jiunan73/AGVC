﻿Module Module1
    Structure agvcar
        Dim Position As Integer
        Dim Cmd_cnt As Integer
    End Structure
End Module
